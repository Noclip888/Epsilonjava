package platform.inject.accessors;


import net.minecraft.class_2653;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_2653.class})
public interface ScreenHandlerSlotUpdateS2CPacketAccessor {
    @Accessor("syncId")
    int getSyncId();

    @Accessor("slot")
    int getSlot();

    @Accessor("slot")
    @Mutable
    void setSlot(int i);
}
