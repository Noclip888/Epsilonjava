package platform.inject.accessors;


import net.minecraft.class_2561;
import net.minecraft.class_364;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_437.class})
public interface ScreenAccessor {
    @Invoker("addDrawableChild")
    <T extends class_364> T invokeAddDrawableChild(T t);

    @Accessor("width")
    int getWidth();

    @Accessor("height")
    int getHeight();

    @Accessor("title")
    class_2561 getTitle();
}
