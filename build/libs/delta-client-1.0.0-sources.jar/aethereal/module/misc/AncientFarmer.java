package aethereal.module.misc;

import platform.inject.invokers.MinecraftClientInvoker;
import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Interface;
import aethereal.core.InterfaceC0020Opcode;
import aethereal.core.Module;
import aethereal.util.ChatUtil;
import aethereal.render.ColorUtil;
import aethereal.util.InventoryUtil;
import aethereal.util.ServerUtil;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.DrawEvent;
import aethereal.event.TickEvent;
import aethereal.handler.InteractHandler;
import aethereal.module.misc.XRay;
import aethereal.util.Rotation;

import aethereal.util.CounterUtil;
import aethereal.setting.ModeSetting;
import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import baritone.api.pathing.goals.GoalBlock;
import baritone.api.pathing.goals.GoalRunAway;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.BooleanSupplier;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.StreamSupport;
import lombok.Generated;
import net.minecraft.class_1294;
import net.minecraft.class_1541;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1844;
import net.minecraft.class_1937;
import net.minecraft.class_1972;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2784;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_9334;

@ModuleRegister(a = "Ancient Farmer", b = "Автоматически фармит древние обломки в режиме полета", c = Category.Misc)
public class AncientFarmer extends Module {
    private final ModeSetting b = new ModeSetting("Режим поиска территории", "Поиск сверху", "Поиск сверху", "Поиск снизу");
    private final ExecutorService c = Executors.newSingleThreadExecutor();
    private final CounterUtil d = new CounterUtil();
    private Phase e = Phase.SEARCH;
    private class_2338 f;
    private class_238 g;

    enum Phase {
        SEARCH,
        TNT,
        RETREAT,
        MINE
    }

    @Override
    public void b() {
        super.b();
        d(true);
    }

    @Override
    public void c() {
        super.c();
        d(false);
    }

    public AncientFarmer() {
        a(this.b);
    }

    @EventTarget
    public void a(TickEvent event) {
        a missing = (AncientFarmer.a) Arrays.stream(AncientFarmer.a.values()).filter(requirement -> {
            return !requirement.a();
        }).findFirst().orElse(null);
        XRay xray = Delta.h().d().t().E();
        boolean work = missing == AncientFarmer.a.TNT && this.e != Phase.SEARCH;
        if (ServerUtil.a.d() == -1) {
        }
        if (missing != null && !work) {
            ChatUtil.a((Object) ("Для работы модуля " + missing.c() + "!"));
            a();
            return;
        }
        InteractHandler eat = Delta.h().d().v().k();
        int foodSlot = IntStream.range(0, 9).filter(slot -> {
            return aM_.field_1724.method_31548().method_5438(slot).method_57826(class_9334.field_50075);
        }).findFirst().orElse(-1);
        if (!eat.a() && aM_.field_1724.method_7344().method_7586() <= 17 && foodSlot != -1) {
            eat.a(foodSlot);
        }
        int potionSlot = IntStream.range(0, 9).filter(slot2 -> {
            return StreamSupport.stream(((class_1844) aM_.field_1724.method_31548().method_5438(slot2).method_57825(class_9334.field_49651, class_1844.field_49274)).method_57397().spliterator(), false).anyMatch(effect -> {
                return effect.method_5579() == class_1294.field_5918;
            });
        }).findFirst().orElse(-1);
        if (!eat.a() && potionSlot != -1 && (!aM_.field_1724.method_6059(class_1294.field_5918) || aM_.field_1724.method_6112(class_1294.field_5918).method_5584() <= 100)) {
            eat.a(potionSlot);
        }
        if (eat.a()) {
            BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().cancelEverything();
            return;
        }
        if (!xray.m()) {
            xray.a();
            return;
        }
        IBaritone baritone = BaritoneAPI.getProvider().getPrimaryBaritone();
        boolean near = this.g != null && aM_.field_1724.method_24515().method_19771(class_2338.method_49638(this.g.method_1005()), 2.5d);
        boolean primed = !aM_.field_1687.method_8390(class_1541.class, aM_.field_1724.method_5829().method_1014(8.0d), t -> {
            return true;
        }).isEmpty();
        this.f = null;
        switch (this.e) {
            case SEARCH:
                if (!xray.s().isEmpty()) {
                    ChatUtil.a((Object) "Вскапываем обломки найденные по пути");
                    this.e = Phase.MINE;
                } else if (this.g == null) {
                    this.c.execute(() -> {
                        if (this.g == null && aM_.field_1724.field_6012 > 20) {
                            ChatUtil.a((Object) "Переходим к поиску новой территории.");
                            this.g = q();
                        }
                    });
                } else if (near) {
                    BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().cancelEverything();
                    this.e = Phase.TNT;
                } else if (!baritone.getPathingBehavior().hasPath()) {
                    baritone.getCustomGoalProcess().setGoalAndPath(new GoalBlock(class_2338.method_49638(this.g.method_1005())));
                }
                break;
            case TNT:
                double reach = aM_.field_1724.method_55754();
                class_2338 tnt = (class_2338) class_2338.method_25998(aM_.field_1724.method_24515(), (int) reach, (int) reach, (int) reach).filter(pos2 -> {
                    return aM_.field_1687.method_8320(pos2).method_27852(class_2246.field_10375);
                }).map((v0) -> {
                    return v0.method_10062();
                }).findFirst().orElse(null);
                if (primed) {
                    this.e = Phase.RETREAT;
                    break;
                } else if (tnt != null) {
                    this.f = tnt;
                    int flint = InventoryUtil.a(class_1802.field_8884, true);
                    if (flint != -1) {
                        class_243 eye = aM_.field_1724.method_33571();
                        class_243 center = class_243.method_24953(tnt);
                        class_243 aim = (class_243) Arrays.stream(class_2350.values()).map(side -> {
                            return center.method_1031(((double) side.method_10148()) * 0.4499999185117763d, ((double) side.method_10164()) * 0.4499999185117763d, ((double) side.method_10165()) * 0.4499999185117763d);
                        }).filter(point -> {
                            return eye.method_1022(point) <= reach;
                        }).filter(point2 -> {
                            class_3965 trace = aM_.field_1687.method_17742(new class_3959(eye, point2, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, aM_.field_1724));
                            return trace.method_17783() == class_239.class_240.field_1332 && trace.method_17777().equals(tnt);
                        }).min((a2, b2) -> {
                            return Double.compare(eye.method_1025(a2), eye.method_1025(b2));
                        }).orElse(null);
                        if (aim != null) {
                            Delta.h().d().k().a(Rotation.a(eye, aim), 180.0f, 0, 1);
                            if (new Rotation(aM_.field_1724).a(Rotation.b()) < 1.0d && aM_.field_1724.field_6012 % 5 == 0) {
                                aM_.field_1724.method_31548().field_7545 = flint;
                                if (aM_.field_1765 instanceof class_3965 class_3965Var) {
                                    class_3965 hit = class_3965Var;
                                    if (hit.method_17783() == class_239.class_240.field_1332 && hit.method_17777().equals(tnt)) {
                                        ((platform.inject.invokers.MinecraftClientInvoker) aM_).invokeDoItemUse();
                                        break;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    class_243 eye2 = aM_.field_1724.method_33571();
                    class_2338 target = (class_2338) class_2338.method_25998(aM_.field_1724.method_24515(), (int) reach, (int) reach, (int) reach).filter(pos3 -> {
                        return aM_.field_1687.method_8320(pos3).method_45474();
                    }).filter(pos4 -> {
                        return aM_.field_1687.method_8320(pos4.method_10074()).method_26212(aM_.field_1687, pos4.method_10074());
                    }).filter(pos5 -> {
                        return !aM_.field_1724.method_5829().method_18804(aM_.field_1724.method_18798()).method_1014(0.10000001882007822d).method_994(new class_238(pos5));
                    }).filter(pos6 -> {
                        class_243 hitVec = new class_243(((double) pos6.method_10263()) + 0.5d, pos6.method_10264(), ((double) pos6.method_10260()) + 0.5d);
                        if (eye2.method_1022(hitVec) > reach || eye2.method_1020(hitVec).method_1029().field_1351 <= 0.0d) {
                            return false;
                        }
                        class_3965 hit2 = aM_.field_1687.method_17742(new class_3959(eye2, hitVec, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, aM_.field_1724));
                        return hit2.method_17783() != class_239.class_240.field_1332 || hit2.method_17777().equals(pos6.method_10074());
                    }).map((v0) -> {
                        return v0.method_10062();
                    }).min((a3, b3) -> {
                        return Double.compare(eye2.method_1025(a3.method_46558()), eye2.method_1025(b3.method_46558()));
                    }).orElse(null);
                    this.f = target;
                    int slot3 = InventoryUtil.a(class_1802.field_8626, true);
                    if (target != null) {
                        if (slot3 != -1) {
                            class_2338 support = target.method_10074();
                            Delta.h().d().k().a(Rotation.a(eye2, new class_243(((double) support.method_10263()) + 0.5d, support.method_10264() + 1, ((double) support.method_10260()) + 0.5d)), 180.0f, 0, 1);
                            if (new Rotation(aM_.field_1724).a(Rotation.b()) < 1.0d && aM_.field_1724.field_6012 % 5 == 0) {
                                if (aM_.field_1724.method_31548().field_7545 != slot3) {
                                    aM_.field_1724.method_31548().field_7545 = slot3;
                                }
                                if (aM_.field_1765 instanceof class_3965 class_3965Var2) {
                                    class_3965 hit2 = class_3965Var2;
                                    if (hit2.method_17783() == class_239.class_240.field_1332 && hit2.method_17777().equals(support) && hit2.method_17780() == class_2350.field_11036) {
                                        ((platform.inject.invokers.MinecraftClientInvoker) aM_).invokeDoItemUse();
                                        break;
                                    }
                                }
                            }
                        }
                    } else {
                        if (!baritone.getPathingBehavior().hasPath()) {
                            class_2338 feet = aM_.field_1724.method_24515();
                            class_2338 stand = (class_2338) class_2338.method_25998(feet, 16, 8, 16).filter(pos7 -> {
                                return !pos7.equals(feet);
                            }).filter(pos8 -> {
                                return aM_.field_1687.method_8320(pos8.method_10074()).method_26212(aM_.field_1687, pos8.method_10074());
                            }).filter(pos9 -> {
                                return aM_.field_1687.method_8320(pos9).method_45474() && aM_.field_1687.method_8320(pos9.method_10084()).method_45474();
                            }).filter(pos10 -> {
                                return aM_.field_1687.method_8320(pos10).method_26227().method_15769() && aM_.field_1687.method_8320(pos10.method_10084()).method_26227().method_15769();
                            }).map((v0) -> {
                                return v0.method_10062();
                            }).min((a4, b4) -> {
                                return Double.compare(feet.method_10262(a4), feet.method_10262(b4));
                            }).orElse(null);
                            if (stand != null) {
                                baritone.getCustomGoalProcess().setGoalAndPath(new GoalBlock(stand));
                            } else {
                                this.e = Phase.SEARCH;
                            }
                        }
                        break;
                    }
                }
                break;
            case RETREAT:
                List<class_1541> burning = aM_.field_1687.method_8390(class_1541.class, aM_.field_1724.method_5829().method_1014(32.0d), t2 -> {
                    return true;
                });
                if (burning.isEmpty()) {
                    ChatUtil.a((Object) "Ожидаем обломки, и начинаем вскапывать");
                    baritone.getPathingBehavior().cancelEverything();
                    this.g = null;
                    this.e = Phase.MINE;
                    this.d.b();
                } else if (!baritone.getPathingBehavior().hasPath()) {
                    baritone.getCustomGoalProcess().setGoalAndPath(new GoalRunAway(20.0d, (class_2338[]) burning.stream().map((v0) -> {
                        return v0.method_24515();
                    }).toArray(x$0 -> {
                        return new class_2338[x$0];
                    })));
                }
                break;
            case MINE:
                if (this.d.a(1000L)) {
                    if (!xray.s().isEmpty()) {
                        if (!baritone.getMineProcess().isActive()) {
                            baritone.getMineProcess().mine(class_2246.field_22109);
                            Delta.h().f().a(false, "telegram", "message", "⛏️ AncientFarmer — Найдены древние обломки!\n\n📍 Позиций для добычи: %s\n".formatted(Integer.valueOf(xray.s().size())));
                        }
                    } else if (!baritone.getMineProcess().isActive()) {
                        this.e = Phase.SEARCH;
                    }
                }
                break;
        }
    }

    @EventTarget
    public void a(DrawEvent draw) {
        if (draw.c() && this.f != null) {
            draw.e().a(draw.h(), new class_238(this.f), ColorUtil.a(230, 90, 70, InterfaceC0020Opcode.ap), 1.0f);
        }
    }

    private class_238 q() {
        class_2338 anchor;
        int reach = ((int) ((Math.sqrt(aM_.field_1687.method_2935().method_14151()) - 1.0d) / 2.0d)) * 16;
        class_2338 feet = aM_.field_1724.method_24515();
        class_2784 border = aM_.field_1687.method_8621();
        int bottom = this.b.l("Поиск сверху") ? 90 : 20;
        int top = this.b.l("Поиск сверху") ? InterfaceC0020Opcode.bN : 60;
        class_238 best = null;
        double bestScore = -1.0d;
        double bestFill = 0.0d;
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int x = feet.method_10263() - reach; x <= feet.method_10263() + reach; x += 8) {
            for (int z = feet.method_10260() - reach; z <= feet.method_10260() + reach; z += 8) {
                if (aM_.field_1687.method_2935().method_12123(x >> 4, z >> 4) && border.method_35317(x - 20, z - 20) && border.method_35317(x + 20, z + 20)) {
                    for (int y = bottom; y <= top; y += 8) {
                        int solid = 0;
                        int total = 0;
                        boolean badBiome = false;
                        for (int dx = -20; dx <= 20 && !badBiome; dx += 4) {
                            for (int dy = -20; dy <= 20 && !badBiome; dy += 4) {
                                for (int dz = -20; dz <= 20; dz += 4) {
                                    pos.method_10103(x + dx, y + dy, z + dz);
                                    if (aM_.field_1687.method_23753(pos).method_40225(class_1972.field_23859) || aM_.field_1687.method_23753(pos).method_40225(class_1972.field_22075)) {
                                        badBiome = true;
                                        break;
                                    }
                                    total++;
                                    if (!aM_.field_1687.method_8320(pos).method_26215() && aM_.field_1687.method_8320(pos).method_26227().method_15769()) {
                                        solid++;
                                    }
                                }
                            }
                        }
                        if (!badBiome && total > 0) {
                            double score = (((double) solid) / ((double) total)) - (feet.method_40081(x, y, z) * 9.99999555911002E-10d);
                            if (score > bestScore && (anchor = (class_2338) class_2338.method_25998(new class_2338(x, y, z), 20, 20, 20).filter(candidate -> {
                                return !aM_.field_1687.method_8320(candidate).method_26215() && aM_.field_1687.method_8320(candidate).method_26227().method_15769();
                            }).map((v0) -> {
                                return v0.method_10062();
                            }).findFirst().orElse(null)) != null) {
                                bestScore = score;
                                bestFill = ((double) solid) / ((double) total);
                                best = new class_238(anchor.method_10263() - 20, anchor.method_10264() - 20, anchor.method_10260() - 20, anchor.method_10263() + 20, anchor.method_10264() + 20, anchor.method_10260() + 20);
                            }
                        }
                    }
                }
            }
        }
        if (best != null) {
            long jRound = Math.round(bestFill * 100.0d);
            Math.round(Math.sqrt(feet.method_19770(best.method_1005())));
            ChatUtil.a((Object) ("Успешность: &c" + jRound + "%&7, до неё &c" + jRound + "&7 блоков"));
        }
        return best;
    }

    public void d(boolean status) {
        BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().cancelEverything();
        BaritoneAPI.getSettings().blockFreeLook.value = true;
        BaritoneAPI.getSettings().allowBreak.value = true;
        BaritoneAPI.getSettings().randomLooking.value = Double.valueOf(1.0d);
        BaritoneAPI.getSettings().randomLooking113.value = Double.valueOf(1.0d);
        this.g = null;
        this.e = Phase.SEARCH;
    }

    enum a {
        FLY("необходимо включить режим полёта (/fly)", () -> {
            return Interface.aM_.field_1724.method_31549().field_7478;
        }),
        NETHER("необходимо находиться в Незере", () -> {
            return Interface.aM_.field_1687.method_27983() == class_1937.field_25180;
        }),
        FOOD("в хотбаре должна быть еда", stack -> {
            return stack.method_57826(class_9334.field_50075);
        }),
        TNT("в хотбаре должен быть динамит", stack2 -> {
            return stack2.method_31574(class_1802.field_8626);
        }),
        FLINT_AND_STEEL("в хотбаре должно быть огниво", stack3 -> {
            return stack3.method_31574(class_1802.field_8884);
        }),
        PICKAXE("в хотбаре должна быть кирка с прочностью больше 5%", stack4 -> {
            return (stack4.method_7909() instanceof class_1810) && ((double) (stack4.method_7936() - stack4.method_7919())) > ((double) stack4.method_7936()) * 0.050000008964116646d;
        }),
        FIRE_RESISTANCE("в хотбаре должна быть огнестойкость", stack5 -> {
            return StreamSupport.stream(((class_1844) stack5.method_57825(class_9334.field_49651, class_1844.field_49274)).method_57397().spliterator(), false).anyMatch(effect -> {
                return effect.method_5579() == class_1294.field_5918;
            });
        });

        private final BooleanSupplier h;
        private final String i;

        @Generated
        public BooleanSupplier b() {
            return this.h;
        }

        @Generated
        public String c() {
            return this.i;
        }

        a(String description, BooleanSupplier condition) {
            this.i = description;
            this.h = condition;
        }

        a(String description, Predicate<class_1799> predicate) {
            this(description, () -> {
                return IntStream.range(0, 9).anyMatch(slot -> {
                    return predicate.test(Interface.aM_.field_1724.method_31548().method_5438(slot));
                });
            });
        }

        public boolean a() {
            return this.h.getAsBoolean();
        }
    }
}
