package aethereal.module.misc;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Module;
import aethereal.util.ChatUtil;
import aethereal.render.ColorUtil;
import aethereal.util.InventoryUtil;
import aethereal.util.ServerUtil;

import aethereal.config.DescriptionProcessor;
import aethereal.config.EnchantmentProcessor;
import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.core.ModuleRegister;
import aethereal.event.ContainerEvent;
import aethereal.event.PacketEvent;
import aethereal.event.TickEvent;
import aethereal.event.TooltipEvent;

import aethereal.render.AnimationUtil;
import aethereal.setting.BindSetting;
import aethereal.setting.BooleanSetting;
import aethereal.util.CounterUtil;
import aethereal.setting.ModeSetting;
import aethereal.setting.MultiModeSetting;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.SwitchBootstraps;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.ToIntFunction;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import lombok.Generated;
import net.minecraft.class_10192;
import net.minecraft.class_124;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1735;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1829;
import net.minecraft.class_1893;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2649;
import net.minecraft.class_2653;
import net.minecraft.class_2813;
import net.minecraft.class_476;
import net.minecraft.class_5250;
import net.minecraft.class_7439;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import platform.inject.accessors.ClickSlotC2SPacketAccessor;
import platform.inject.accessors.HandledScreenAccessor;
import platform.inject.accessors.ItemCooldownManagerAccessor;
import platform.inject.accessors.ScreenHandlerSlotUpdateS2CPacketAccessor;

@ModuleRegister(a = "Server Assistant", b = "Помощник, упрощающий работу с сервером и игровыми механиками", c = Category.Misc)
public class ServerAssistant extends Module implements Interface {
    private List<b> w;
    private final ModeSetting b = new ModeSetting("Целевой сервер помощи", "FunTime", "FunTime", "SpookyTime", "HolyWorld");
    private final MultiModeSetting c = (MultiModeSetting) new MultiModeSetting("Элементы помощи", new BooleanSetting("Аукционный ассистент", true), new BooleanSetting("Сортировать по цене", true)).a(() -> {
        return Boolean.valueOf(this.b.l("FunTime") || this.b.l("SpookyTime"));
    });
    final MultiModeSetting d = (MultiModeSetting) new MultiModeSetting("Фильтр брони по", new BooleanSetting("Защите", false), new BooleanSetting("Аншип", true), new BooleanSetting("Починке", true), new BooleanSetting("Подводной ходьбе", true)).a(() -> {
        return Boolean.valueOf(this.c.a("Аукционный ассистент").c().booleanValue() && (this.b.l("FunTime") || this.b.l("SpookyTime")));
    });
    final MultiModeSetting e = (MultiModeSetting) new MultiModeSetting("Фильтр меча по", new BooleanSetting("Остроте", false), new BooleanSetting("Детекции", true), new BooleanSetting("Вампиризму", true), new BooleanSetting("Окислению", true), new BooleanSetting("Яду", true)).a(() -> {
        return Boolean.valueOf(this.c.a("Аукционный ассистент").c().booleanValue() && (this.b.l("FunTime") || this.b.l("SpookyTime")));
    });
    final MultiModeSetting f = (MultiModeSetting) new MultiModeSetting("Фильтр кирки по", new BooleanSetting("Эффективности", false), new BooleanSetting("Удаче", true), new BooleanSetting("Магнит", true), new BooleanSetting("Починке", true)).a(() -> {
        return Boolean.valueOf(this.c.a("Аукционный ассистент").c().booleanValue() && (this.b.l("FunTime") || this.b.l("SpookyTime")));
    });
    private final BindSetting g = a("Трапка", class_1802.field_22021, "FunTime", "SpookyTime");
    private final BindSetting h = a("Снежок заморозка", class_1802.field_8543, "FunTime", "SpookyTime");
    private final BindSetting i = a("Пласт", class_1802.field_8551, "FunTime", "SpookyTime");
    private final BindSetting j = a("Дезориентация", class_1802.field_8449, "FunTime", "SpookyTime");
    private final BindSetting k = a("Явная пыль", class_1802.field_8479, "FunTime", "SpookyTime");
    private final BindSetting l = a("Заряд ветра", class_1802.field_49098, "FunTime", "SpookyTime");
    private final BindSetting m = a("Огненный заряд", class_1802.field_8814, "FunTime", "SpookyTime");
    private final BindSetting n = a("Божья аура", class_1802.field_8614, "FunTime", "SpookyTime");
    private final BindSetting o = a("Взрывная штучка", class_1802.field_8814, "HolyWorld");
    private final BindSetting p = a("Взрывная палочка", class_1802.field_8894, "HolyWorld");
    private final BindSetting q = a("Взрывная трапка", class_1802.field_8662, "HolyWorld");
    private final BindSetting r = a("Стан", class_1802.field_8137, "HolyWorld");
    private final BindSetting s = a("Ком снега", class_1802.field_8543, "HolyWorld");
    private final BooleanSetting t = (BooleanSetting) new BooleanSetting("Авто-божья аура", false).a(() -> {
        return Boolean.valueOf(this.b.l("FunTime") || this.b.l("SpookyTime"));
    });
    private final a u = new a();
    private final CounterUtil v = new CounterUtil();
    private class_1735 x = null;
    private int[] y = null;
    private int z = -1;

    @Generated
    public List<b> q() {
        return this.w;
    }

    public ServerAssistant() {
        a(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.m, this.l, this.n, this.o, this.p, this.q, this.r, this.s, this.t);
    }

    @EventTarget
    public void a(TickEvent event) {
        if (this.t.c().booleanValue()) {
            if (ServerUtil.a.a() || ServerUtil.d.a()) {
                boolean hasBadEffect = aM_.field_1724.method_6026().stream().anyMatch(effect -> {
                    return effect.method_5579() == class_1294.field_5911 && effect.method_5578() >= 1 && ((double) effect.method_5584()) / 20.0d >= 15.0d;
                });
                if (InventoryUtil.b(class_1802.field_8614) != -1 && hasBadEffect && !aM_.field_1724.method_7357().method_7904(class_1802.field_8614.method_7854()) && this.v.a(5000L) && aM_.field_1724.method_6067() <= 3.0f) {
                    Delta.h().d().v().b().a(class_1802.field_8614.method_7854());
                    this.v.b();
                }
            }
        }
    }

    @EventTarget
    public void a(TooltipEvent event) {
        class_1799 stack = event.b();
        int price = ServerUtil.a.a(stack);
        if (price > 0 && stack.method_7947() > 1) {
            List<class_2561> lines = event.c();
            for (int i = 0; i < lines.size(); i++) {
                if (ServerUtil.hasPriceMarker(lines.get(i).getString())) {
                    lines.add(i + 1, class_2561.method_43470("$").method_27692(class_124.field_1060).method_10852(class_2561.method_43470(" Цена за штуку: ").method_27692(class_124.field_1068)).method_10852(class_2561.method_43470(String.format(Locale.US, "%,d", Integer.valueOf(price))).method_27692(class_124.field_1060)));
                    return;
                }
            }
        }
    }

    @EventTarget
    public void a(ContainerEvent event) {
        HandledScreenAccessor handledScreenAccessorB = (HandledScreenAccessor) event.b();
        if (handledScreenAccessorB instanceof class_476) {
            HandledScreenAccessor handledScreenAccessor = (HandledScreenAccessor) (class_476) handledScreenAccessorB;
            ToIntFunction<class_1799> price = ServerUtil.a.a() ? ServerUtil.a::a : ServerUtil.d::a;
            if (event.h() == ContainerEvent.Phase.TITLE) {
                if (event.i().getString().contains("Хранилище")) {
                    long storage = handledScreenAccessor.getScreenHandler().field_7761.stream().mapToLong(slot -> {
                        return ((long) Math.max(price.applyAsInt(slot.method_7677()), 0)) * ((long) Math.max(slot.method_7677().method_7947(), 1));
                    }).sum();
                    String suffix = " - " + ((String) Stream.of(Map.entry(1000000000L, "ккк"), Map.entry(1000000L, "кк"), Map.entry(1000L, "к")).filter((Map.Entry<Long, String> unit) -> {
                        return storage >= ((Long) unit.getKey()).longValue();
                    }).map((Map.Entry<Long, String> unit2) -> {
                        return String.format(Locale.US, "%.0f%s", Double.valueOf(storage / ((Long) unit2.getKey()).longValue()), unit2.getValue());
                    }).findFirst().orElseGet(() -> {
                        return String.valueOf(storage);
                    }));
                    class_5250 title = class_2561.method_43473();
                    event.i().method_27658((style, part) -> {
                        title.method_10852(class_2561.method_43470(part).method_10862(style));
                        if (part.contains("Хранилище")) {
                            title.method_10852(class_2561.method_43470(suffix).method_10862(style));
                        }
                        return Optional.empty();
                    }, class_2583.field_24360);
                    event.a((class_2561) title);
                    return;
                }
                return;
            }
            if (handledScreenAccessor.getScreenHandler().field_7761.size() >= 90) {
                List<class_1735> containerSlots = new ArrayList<>(event.e().subList(0, event.e().size() - 36));
                boolean useFilter = containerSlots.stream().anyMatch(slot2 -> {
                    return price.applyAsInt(slot2.method_7677()) >= 0 && this.u.a(slot2.method_7677());
                });
                if (event.h() == ContainerEvent.Phase.POST && this.c.a("Аукционный ассистент").c().booleanValue()) {
                    if (this.x == null || this.x.method_7677().method_7960() || !containerSlots.contains(this.x)) {
                        class_1735 cheapest = null;
                        int minPrice = Integer.MAX_VALUE;
                        for (class_1735 slot3 : containerSlots) {
                            class_1799 stack = slot3.method_7677();
                            int value = price.applyAsInt(stack);
                            if (!useFilter || this.u.a(stack)) {
                                if (value >= 0 && value < minPrice) {
                                    minPrice = value;
                                    cheapest = slot3;
                                }
                            }
                        }
                        this.x = cheapest;
                    }
                    if (this.x != null) {
                        HandledScreenAccessor accessor = (HandledScreenAccessor) handledScreenAccessor;
                        float pulse = (float) ((Math.sin(((System.currentTimeMillis() % 100000) / 1000.0f) * 10.0f) + 1.0d) * 0.5d);
                        Delta.h().d().i().a(event.d(), accessor.getX() + ((class_1735) this.x).field_7873, accessor.getY() + ((class_1735) this.x).field_7872, 16.0f, 16.0f, ColorUtil.a(0, 255, 0, (int) (25.0f + (175.0f * pulse))));
                    }
                }
            }
        }
    }

    @EventTarget
    public void a(PacketEvent event) {
        if (event.c()) {
            if (event.d() instanceof class_7439 message) {
                if (ServerUtil.a.a() && message.comp_763().getString().equals("На этой анархии этот предмет не работает")) {
                    this.z = ServerUtil.a.d();
                }
            }
            if (event.d() instanceof class_2649 packet) {
                this.x = null;
                if (this.c.a("Сортировать по цене").c().booleanValue() && (ServerUtil.a.a() || ServerUtil.d.a())) {
                    List<class_1799> contents = packet.method_11441();
                    int chestSlots = contents.size() > 36 ? contents.size() - 36 : contents.size();
                    this.y = null;
                    if (chestSlots >= 44 && packet.method_11440() != 0) {
                        ToIntFunction<class_1799> price = ServerUtil.a.a() ? ServerUtil.a::a : ServerUtil.d::a;
                        boolean useFilter = contents.subList(0, chestSlots).stream().anyMatch(stack -> {
                            return price.applyAsInt(stack) >= 0 && this.u.a(stack);
                        });
                        int[] prices = new int[chestSlots];
                        for (int i = 0; i < chestSlots; i++) {
                            class_1799 stack2 = contents.get(i);
                            int value = (stack2.method_7960() || (useFilter && !this.u.a(stack2))) ? -1 : price.applyAsInt(stack2);
                            prices[i] = value < 0 ? Integer.MAX_VALUE : value;
                        }
                        Integer[] order = (Integer[]) IntStream.range(0, chestSlots).boxed().sorted(Comparator.comparingInt(i2 -> {
                            return prices[i2.intValue()];
                        })).toArray(x$0 -> {
                            return new Integer[x$0];
                        });
                        List<class_1799> original = new ArrayList<>(contents);
                        int[] mapping = new int[chestSlots];
                        for (int display = 0; display < chestSlots; display++) {
                            mapping[display] = order[display].intValue();
                            contents.set(display, original.get(mapping[display]));
                        }
                        this.y = mapping;
                    }
                }
            }
            if (event.d() instanceof class_2653 slotUpdate) {
                ScreenHandlerSlotUpdateS2CPacketAccessor screenHandlerSlotUpdateS2CPacketAccessor = (ScreenHandlerSlotUpdateS2CPacketAccessor) slotUpdate;
                if (this.y != null && screenHandlerSlotUpdateS2CPacketAccessor.getSyncId() != 0 && screenHandlerSlotUpdateS2CPacketAccessor.getSyncId() == aM_.field_1724.field_7512.field_7763 && screenHandlerSlotUpdateS2CPacketAccessor.getSlot() >= 0 && screenHandlerSlotUpdateS2CPacketAccessor.getSlot() < this.y.length) {
                    for (int display2 = 0; display2 < this.y.length; display2++) {
                        if (this.y[display2] == screenHandlerSlotUpdateS2CPacketAccessor.getSlot()) {
                            screenHandlerSlotUpdateS2CPacketAccessor.setSlot(display2);
                            break;
                        }
                    }
                }
                this.x = null;
            }
        }
        if (event.b()) {
            if (event.d() instanceof class_2813 clickSlot) {
                ClickSlotC2SPacketAccessor clickSlotC2SPacketAccessor = (ClickSlotC2SPacketAccessor) clickSlot;
                if (this.y != null && clickSlotC2SPacketAccessor.getSyncId() != 0 && clickSlotC2SPacketAccessor.getSyncId() == aM_.field_1724.field_7512.field_7763 && clickSlotC2SPacketAccessor.getSlot() >= 0 && clickSlotC2SPacketAccessor.getSlot() < this.y.length) {
                    clickSlotC2SPacketAccessor.setSlot(this.y[clickSlotC2SPacketAccessor.getSlot()]);
                }
            }
        }
    }

    private BindSetting a(String name, class_1792 item, String... servers) {
        BindSetting setting = (BindSetting) new BindSetting(name, -1).a(() -> {
            ItemCooldownManagerAccessor itemCooldownManagerAccessorMethod_7357 = (ItemCooldownManagerAccessor) (ItemCooldownManagerAccessor) aM_.field_1724.method_7357();
            if (((net.minecraft.class_1796) (Object) itemCooldownManagerAccessorMethod_7357).method_7904(item.method_7854())) {
                ItemCooldownManagerAccessor accessor = itemCooldownManagerAccessorMethod_7357;
                Object entry = accessor.getEntries().get(class_7923.field_41178.method_10221(item));
                Locale locale = Locale.US;
                Object[] objArr = new Object[1];
                objArr[0] = Float.valueOf(entry != null ? Math.max(((platform.inject.accessors.ItemCooldownEntryAccessor) entry).getEndTick() - accessor.getTick(), 0) / 20.0f : 0.0f);
                ChatUtil.a((Object) ("&c" + name + "&7 - имеет задержку &c" + String.format(locale, "%.1fс", objArr)));
                return;
            }
            if (InventoryUtil.b(item) == -1) {
                ChatUtil.a((Object) ("&c" + name + "&7 - нет в инвентаре"));
            } else {
                Delta.h().d().v().b().a(item.method_7854());
            }
        }).a(() -> {
            Stream stream = Arrays.stream(servers);
            ModeSetting modeSetting = this.b;
            Objects.requireNonNull(modeSetting);
            return Boolean.valueOf(Arrays.stream(servers).anyMatch(server -> modeSetting.l(server)));
        });
        if (this.w == null) {
            this.w = new ArrayList();
        }
        this.w.add(new b(new AnimationUtil(), setting, item));
        return setting;
    }

    public class a {
        public a() {
        }

        public boolean a(class_1799 stack) {
            class_1792 item = stack.method_7909();
            if (item instanceof class_1738) {
                return b(stack);
            }
            if (item instanceof class_1829) {
                return c(stack);
            }
            if (item instanceof class_1810) {
                return d(stack);
            }
            return true;
        }

        private boolean b(class_1799 stack) {
            if (stack.method_7909() instanceof class_1738) {
                EnchantmentProcessor enchament = new EnchantmentProcessor();
                if (ServerAssistant.this.d.a("Защите").c().booleanValue()) {
                    enchament.a(class_1893.field_9119, 4);
                    enchament.a(class_1893.field_9111, 5);
                }
                if (ServerAssistant.this.d.a("Аншип").c().booleanValue()) {
                    enchament.b(class_1893.field_9097);
                }
                if (ServerAssistant.this.d.a("Починке").c().booleanValue()) {
                    enchament.a(class_1893.field_9101, 1);
                }
                if (ServerAssistant.this.d.a("Подводной ходьбе").c().booleanValue() && stack.method_57824(class_9334.field_54196) != null && ((class_10192) stack.method_57824(class_9334.field_54196)).comp_3174() == class_1304.field_6166) {
                    enchament.a(class_1893.field_9128, 1);
                }
                return enchament.a(stack);
            }
            return true;
        }

        private boolean c(class_1799 stack) {
            if (stack.method_7909() instanceof class_1829) {
                EnchantmentProcessor enchantmentProcessor = new EnchantmentProcessor().b(class_1893.field_9121, 2);
                if (ServerAssistant.this.e.a("Остроте").c().booleanValue()) {
                    enchantmentProcessor.a(class_1893.field_9118, 6);
                }
                enchantmentProcessor.b(class_1893.field_9121, 1);
                if (enchantmentProcessor.a(stack)) {
                    DescriptionProcessor descriptionProcessor = new DescriptionProcessor();
                    descriptionProcessor.b("Нестабильность ");
                    descriptionProcessor.b("Нестабильный ");
                    if (ServerAssistant.this.e.a("Детекции").c().booleanValue()) {
                        descriptionProcessor.a("Детекция", 2);
                    }
                    if (ServerAssistant.this.e.a("Вампиризму").c().booleanValue()) {
                        descriptionProcessor.a("Вампиризм", 2);
                    }
                    if (ServerAssistant.this.e.a("Окислению").c().booleanValue()) {
                        descriptionProcessor.a("Окисление", 2);
                    }
                    if (ServerAssistant.this.e.a("Яду").c().booleanValue()) {
                        descriptionProcessor.a("Яд", 3);
                    }
                    return descriptionProcessor.a(stack);
                }
                return false;
            }
            return false;
        }

        private boolean d(class_1799 stack) {
            if (stack.method_7909() instanceof class_1810) {
                if (ServerAssistant.this.f.a("Починке").c().booleanValue() && !new EnchantmentProcessor().a(class_1893.field_9101, 1).a(stack)) {
                    return false;
                }
                DescriptionProcessor descriptionProcessor = new DescriptionProcessor();
                if (ServerAssistant.this.f.a("Удаче").c().booleanValue()) {
                    descriptionProcessor.a("Удача", 5);
                }
                if (ServerAssistant.this.f.a("Эффективности").c().booleanValue()) {
                    descriptionProcessor.a("Эффективность", 4);
                }
                if (ServerAssistant.this.f.a("Магнит").c().booleanValue()) {
                    descriptionProcessor.a("Магнит");
                }
                return descriptionProcessor.a(stack);
            }
            return false;
        }
    }

    public static final class b {
        private final AnimationUtil a;
        private final BindSetting b;
        private final class_1792 c;

        public b(AnimationUtil animationUtil, BindSetting bind, class_1792 item) {
            this.a = animationUtil;
            this.b = bind;
            this.c = item;
        }
public AnimationUtil a() {
            return this.a;
        }

        public BindSetting b() {
            return this.b;
        }

        public class_1792 c() {
            return this.c;
        }
    }
}
