package aethereal.module.combat;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Module;
import aethereal.util.InventoryUtil;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_9334;
import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.core.ModuleRegister;
import aethereal.event.TickEvent;

import aethereal.setting.BooleanSetting;
import aethereal.util.CounterUtil;
import aethereal.setting.MultiModeSetting;
import aethereal.setting.SliderSetting;

@ModuleRegister(a = "Auto Totem", b = "Берёт тотем бессмертия в руку при падении здоровья ниже заданного значения", c = Category.Combat)
public class AutoTotem extends Module implements Interface {
    private final SliderSetting c = new SliderSetting("Порог здоровья", 6.0f, 1.0f, 20.0f, 0.5f);
    private final MultiModeSetting d = new MultiModeSetting("Дополнительные опции", new BooleanSetting("Возвращать предмет", true), new BooleanSetting("Сначала обычные тотемы", true), new BooleanSetting("Не во время еды", false));
    private final BooleanSetting e = new BooleanSetting("Умное перемещение", true);
    private final CounterUtil f = new CounterUtil();
    private final float[] g = new float[20];
    private int h = -1;
    public boolean b;

    public AutoTotem() {
        a(this.c, this.d, this.e);
    }

    @Override
    public void b() {
        super.b();
        this.h = -1;
    }

    @Override
    public void c() {
        super.c();
        this.h = -1;
        this.b = false;
    }

    @EventTarget
    public void a(TickEvent event) {
        System.arraycopy(this.g, 0, this.g, 1, 19);
        this.g[0] = aM_.field_1724.method_6032() + (aM_.field_1724.method_6059(class_1294.field_5898) ? aM_.field_1724.method_6067() : 0.0f);
        if (this.d.a("Не во время еды").c().booleanValue() && t()) {
            return;
        }
        Boolean should = s();
        this.b = should != null ? should.booleanValue() : this.b;
        if (should != null) {
            if (should.booleanValue()) {
                if (!this.f.a(400L) || !q()) {
                    return;
                }
            } else if (!r()) {
                return;
            }
            this.f.b();
        }
    }

    private boolean q() {
        class_1799 offhand = aM_.field_1724.method_6079();
        boolean preferPlain = this.d.a("Сначала обычные тотемы").c().booleanValue();
        if (a(offhand) && (!preferPlain || !offhand.method_7958())) {
            return false;
        }
        int slot = preferPlain ? InventoryUtil.a(class_1802.field_8288, false, true) : -1;
        if (slot == -1 && !a(offhand)) {
            slot = InventoryUtil.b(class_1802.field_8288);
        }
        if (slot == -1) {
            return false;
        }
        if (this.d.a("Возвращать предмет").c().booleanValue() && this.h == -1 && !offhand.method_7960()) {
            this.h = slot;
        }
        Delta.h().d().v().a().a(slot, 40, 1);
        return true;
    }

    private boolean r() {
        class_1799 offhand = aM_.field_1724.method_6079();
        if (this.d.a("Возвращать предмет").c().booleanValue() && this.h != -1 && (offhand.method_7960() || a(offhand))) {
            Delta.h().d().v().a().a(this.h, 40, 1);
        }
        this.h = -1;
        return false;
    }

    private Boolean s() {
        if (aM_.field_1724.method_7357().method_7904(class_1802.field_8288.method_7854())) {
            return false;
        }
        class_1799 active = aM_.field_1724.method_6030();
        if (this.e.c().booleanValue() && t() && active.method_7909().method_7881(active, aM_.field_1724) > 5) {
            int left = aM_.field_1724.method_6014();
            if (left < 10) {
                return null;
            }
            if (left < 30 && ((this.g[19] - this.g[0]) / 20.0f) * left < this.g[0]) {
                return null;
            }
        }
        if (this.g[0] <= this.c.c().floatValue()) {
            return true;
        }
        return this.g[0] >= this.c.c().floatValue() + 0.5f ? false : null;
    }

    private boolean t() {
        class_1799 active = aM_.field_1724.method_6030();
        return (!aM_.field_1724.method_6115() || active.method_7960() || active.method_57824(class_9334.field_50075) == null) ? false : true;
    }

    private boolean a(class_1799 stack) {
        return !stack.method_7960() && stack.method_7909() == class_1802.field_8288;
    }
}
