package aethereal.module.combat;

import aethereal.module.combat.AuraUtil;
import aethereal.ui.screen.AssistantScreen;
import aethereal.ui.screen.GUIScreen;
import platform.inject.accessors.ClientPlayerEntityAccessor;
import platform.inject.invokers.MinecraftClientInvoker;
import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Module;
import aethereal.lib.log4j.LoggerFactory;
import aethereal.util.ChatUtil;
import aethereal.util.InventoryUtil;
import aethereal.util.Look;
import aethereal.util.MathUtil;
import aethereal.util.MoveUtil;
import aethereal.util.ServerUtil;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.GlobalEvent;
import aethereal.core.ModuleRegister;
import aethereal.event.InputEvent;
import aethereal.event.WillLandEvent;
import aethereal.util.Rotation;

import aethereal.setting.BooleanSetting;
import aethereal.lib.log4j.Logger_2;
import aethereal.setting.ModeSetting;
import aethereal.setting.MultiModeSetting;
import aethereal.setting.SliderSetting;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import lombok.Generated;
import net.minecraft.class_1268;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1307;
import net.minecraft.class_1309;
import net.minecraft.class_1421;
import net.minecraft.class_1427;
import net.minecraft.class_1510;
import net.minecraft.class_1588;
import net.minecraft.class_1621;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2848;
import net.minecraft.class_3532;
import net.minecraft.class_7298;

@ModuleRegister(a = "Aura", b = "Автоматически атакует цели рядом с вами", c = Category.Combat)
public class Aura extends Module {

    @Generated
    private static final Logger_2 g = LoggerFactory.a((Class<?>) Aura.class);
    private class_1309 t;
    boolean d;
    private final ModeSetting h = new ModeSetting("Выберите тип наведения", "ФанТайм", "ФанТайм", "ФанТайм ФОВ", "Легит");
    private final MultiModeSetting i = new MultiModeSetting("Цели для атаки", new BooleanSetting("Без брони", true), new BooleanSetting("Враждебные мобы", false), new BooleanSetting("Животные", false), new BooleanSetting("Друзья", false), new BooleanSetting("Игроки", true));
    private final SliderSetting j = new SliderSetting("Дистанция атаки", 3.0f, 0.1f, 6.0f, 0.1f);
    private final SliderSetting k = new SliderSetting("Дополнительная дистанция", 0.5f, 0.1f, 3.0f, 0.1f);
    private final BooleanSetting l = new BooleanSetting("Только критические удары", true);
    private final BooleanSetting m = (BooleanSetting) new BooleanSetting("Адаптивные удары", true).a(() -> {
        return this.l.c();
    });
    private final MultiModeSetting n = new MultiModeSetting("Не бить когда", new BooleanSetting("Используется предмет", true), new BooleanSetting("Открыт контейнер", true), new BooleanSetting("Враг за стеной", true));
    private final BooleanSetting o = new BooleanSetting("Пробитие щита", true);
    private final BooleanSetting p = new BooleanSetting("Умный спринт", false);
    private final ModeSetting q = new ModeSetting("Приоритет цели", "Прицел", "Прицел", "Дистанция", "ХП");
    private final ModeSetting r = new ModeSetting("Коррекция движения", "Фокус", "Фокус", "Свободно");
    private final ModeSetting s = new ModeSetting("Визуализация цели", "Сферы", "Сферы", "Круг", "Тест");
    public int b = 0;
    float[] c = {-1.0f, -1.0f, -1.0f, -1.0f, 0.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f};
    private final float[] u = new float[30];
    int[] e = {-1, -1};
    boolean f = false;

    @Generated
    public ModeSetting r() {
        return this.s;
    }

    @Generated
    public class_1309 s() {
        return this.t;
    }

    public Aura() {
        a(this.j, this.k, this.h, this.r, this.s, this.q, this.i, this.n, this.l, this.m, this.o, this.p);
    }

    @Override
    public void b() {
        if (this.c[9] == -1.0f) {
            this.c[9] = (int) MathUtil.a(9.0f, 13.0f);
        }
        super.b();
        this.c[8] = 2.0f;
        this.c[10] = 0.0f;
        this.c[11] = 0.0f;
        Arrays.fill(this.u, aM_.field_1724 != null ? aM_.field_1724.method_36455() : 0.0f);
        this.t = null;
    }

    @Override
    public void c() {
        super.c();
        this.c[10] = 0.0f;
        this.t = null;
    }

    @EventTarget
    public void a(InputEvent e) {
        if (this.t != null) {
            MoveUtil.a(e, !this.r.l("Фокус") ? Look.b() : this.c[1], 2);
        }
        if (this.c[0] > 0.0f && this.t != null && AuraUtil.a(this.t, this.j.c().floatValue())) {
            e.a(0.0f);
            e.b(0.0f);
            float[] fArr = this.c;
            fArr[0] = fArr[0] - 1.0f;
        }
    }

    @EventTarget
    public void a(GlobalEvent e) {
        if (this.t == null || !b(this.t) || (MaceUtil.a() && !this.d && !aM_.field_1724.method_7357().method_7904(class_1802.field_49814.method_7854()))) {
            class_1309 prev = this.t;
            boolean fresh = prev == null || !b(prev);
            this.t = (fresh && this.n.a("Враг за стеной").c().booleanValue()) ? d(false).or(() -> {
                return d(true);
            }).orElse(null) : v().orElse(null);
            if (this.t != prev && this.t != null) {
                this.c[10] = 0.0f;
                this.c[11] = 0.0f;
                Arrays.fill(this.u, aM_.field_1724 != null ? aM_.field_1724.method_36455() : 0.0f);
            }
        }
        t();
        if (this.t != null) {
            u();
            w();
            u();
            return;
        }
        this.c[8] = 1.0f;
    }

    @EventTarget
    public void a(WillLandEvent e) {
        this.d = e.b() && !aM_.field_1724.method_24828();
    }

    private int a(int from, int to) {
        for (int i = from; i < to; i++) {
            if (aM_.field_1724.method_31548().method_5438(i).method_7909() instanceof class_1743) {
                return i;
            }
        }
        return -1;
    }

    private void t() {
        if (this.o.c().booleanValue() && this.t != null && this.t.method_6039()) {
            return;
        }
        if (this.e[0] != -1) {
            aM_.field_1724.method_31548().field_7545 = this.e[0];
            this.e[0] = -1;
        }
        if (this.e[1] != -1 && Delta.h().d().v().a().a().isEmpty()) {
            Delta.h().d().v().a().a(aM_.field_1724.method_31548().field_7545, this.e[1], 1);
            this.e[1] = -1;
        }
    }

    private void u() {
        if (!AuraUtil.a(aM_.field_1724.method_36454(), aM_.field_1724.method_36455(), this.j.c().floatValue(), this.t, !this.n.a("Враг за стеной").c().booleanValue())) {
            return;
        }
        if (this.o.c().booleanValue() && this.t.method_6039()) {
            if (aM_.field_1724.method_6047().method_7909() instanceof class_1743) {
                aM_.field_1761.method_2918(aM_.field_1724, this.t);
                aM_.field_1724.method_6104(class_1268.field_5808);
            }
            int hotbar = a(0, 9);
            if (hotbar != -1) {
                if (aM_.field_1724.method_31548().field_7545 != hotbar) {
                    if (this.e[0] == -1) {
                        this.e[0] = aM_.field_1724.method_31548().field_7545;
                    }
                    aM_.field_1724.method_31548().field_7545 = hotbar;
                }
            } else {
                int inventory = a(9, 36);
                if (inventory != -1 && this.e[1] == -1 && Delta.h().d().v().a().a().isEmpty()) {
                    this.e[1] = inventory;
                    Delta.h().d().v().a().a(inventory, aM_.field_1724.method_31548().field_7545, 1);
                }
            }
        }
        if (q()) {
            boolean skip = false;
            if ((Delta.h().d().t().H().e || (aM_.field_1724.field_6017 > 2.0f && Delta.h().d().t().H().c.c().booleanValue())) && InventoryUtil.b(class_1802.field_49814) != -1) {
                if (aM_.field_1724.field_6017 < 1.5f) {
                    return;
                }
                double landDist = ((Double) MaceUtil.a(aM_.field_1724, (class_1937) aM_.field_1687).map(pos -> {
                    return Double.valueOf(pos.method_1022(this.t.method_19538()));
                }).orElse(Double.valueOf(33.0d))).doubleValue();
                boolean hitNow = landDist > 2.0d;
                if ((!this.d && !MaceUtil.b() && Delta.h().d().t().H().b.c().booleanValue() && !hitNow) || !MaceUtil.a() || aM_.field_1724.method_6128()) {
                    return;
                } else {
                    skip = true;
                }
            }
            if (((platform.inject.accessors.ClientPlayerEntityAccessor) aM_.field_1724).getWasSprinting() && !aM_.field_1724.method_5799() && !aM_.field_1724.method_5771() && !aM_.field_1724.method_5681() && !aM_.field_1724.method_24828() && !skip) {
                if (!this.p.c().booleanValue()) {
                    ((platform.inject.accessors.ClientPlayerEntityAccessor) aM_.field_1724).setWasSprinting(false);
                    aM_.field_1724.method_5728(false);
                    aM_.field_1724.field_3944.method_52787(new class_2848(aM_.field_1724, class_2848.class_2849.field_12985));
                    this.c[0] = 1.0f;
                } else {
                    this.c[0] = 1.0f;
                    if (((platform.inject.accessors.ClientPlayerEntityAccessor) aM_.field_1724).getWasSprinting()) {
                        return;
                    }
                }
            }
            if (aM_.field_1761 != null) {
                this.c[3] = 0.0f;
                aM_.field_1761.method_2918(aM_.field_1724, this.t);
                aM_.field_1724.method_6104(class_1268.field_5808);
                this.b = 0;
                this.c[5] = MathUtil.a(8.0f, 10.0f);
                this.c[9] = (int) MathUtil.a(9.0f, 13.0f);
                if (this.c[2] == -1.0f) {
                    this.c[4] = (int) MathUtil.a(30.0f, 35.0f);
                }
                float[] fArr = this.c;
                fArr[2] = fArr[2] + 1.0f;
            }
        }
    }

    public boolean q() {
        if (this.n.a("Используется предмет") != null && this.n.a("Используется предмет").c().booleanValue() && aM_.field_1724.method_6115() && aM_.field_1724.method_6014() > 0 && this.b >= 8) {
            this.b = 8;
            return false;
        }
        if ((this.n.a("Открыт контейнер") != null && this.n.a("Открыт контейнер").c().booleanValue() && aM_.field_1755 != null && !(aM_.field_1755 instanceof GUIScreen) && !(aM_.field_1755 instanceof AssistantScreen)) || !AuraUtil.a(this.t, this.j.c().floatValue())) {
            return false;
        }
        if (Delta.h().d().t().H().e) {
            if (aM_.field_1724.method_7357().method_7904(aM_.field_1724.method_6047())) {
                return false;
            }
        } else if (aM_.field_1724.field_6017 > 1.5f) {
            if (aM_.field_1724.method_7357().method_7904(aM_.field_1724.method_6047()) || this.b <= 3) {
                return false;
            }
        } else if (MaceUtil.a()) {
            if (aM_.field_1724.method_7357().method_7904(aM_.field_1724.method_6047()) || aM_.field_1724.method_7261(0.5f) < 0.9f) {
                return false;
            }
        } else if (aM_.field_1724.method_7261(0.5f) < 0.9f || this.b < 10) {
            return false;
        }
        return AuraUtil.c() || (this.m.c().booleanValue() && aM_.field_1724.method_24828() && !aM_.field_1724.field_3913.field_54155.comp_3163()) || !AuraUtil.b();
    }

    private boolean a(class_1309 entity) {
        if (Delta.h().d().t().G().m() && aM_.field_1724.method_6128()) {
            return true;
        }
        return AuraUtil.a((class_1297) entity, ((double) (this.j.c().floatValue() + this.k.c().floatValue())) + (aM_.field_1724.method_18798().method_1033() * 3.0d) + ((double) ((InventoryUtil.b(class_1802.field_49814) == -1 || ((double) aM_.field_1724.field_6017) <= 1.5d) ? 0.0f : 1.5f)) + ((double) ((Delta.h().d().t().H().m() && InventoryUtil.b(class_1802.field_49814) != -1 && ((Boolean) MaceUtil.a(aM_.field_1724, (class_1937) aM_.field_1687).map(p -> {
            return Boolean.valueOf(aM_.field_1724.method_23318() - p.method_10214() > 2.0d);
        }).orElse(false)).booleanValue()) ? 10 : 0)));
    }

    private Optional<class_1309> v() {
        return d(true);
    }

    private Optional<class_1309> d(boolean allowBehindWalls) {
        Comparator<class_1309> comparatorComparingDouble;
        Comparator<class_1309> order;
        if (aM_.field_1687 == null || aM_.field_1724 == null) {
            return Optional.empty();
        }
        class_243 eye = aM_.field_1724.method_33571();
        double reach = this.j.c().floatValue() + this.k.c().floatValue();
        if (MaceUtil.a()) {
            class_243 landing = MaceUtil.a(aM_.field_1724, (class_1937) aM_.field_1687).orElse(null);
            class_243 landingEye = landing != null ? landing.method_1031(0.0d, aM_.field_1724.method_5751(), 0.0d) : null;
            order = Comparator.comparing((class_1309 e) ->
                Boolean.valueOf(!AuraUtil.a(eye, e, reach) && (landingEye == null || !AuraUtil.a(landingEye, e, reach)))
            ).thenComparing((class_1309 e2) ->
                Boolean.valueOf(aM_.field_1724.field_6017 > 1.0f && !c(e2))
            ).thenComparingDouble((class_1309 v0) -> AuraUtil.a(v0));
        } else {
            switch (this.q.c()) {
                case "Дистанция":
                    comparatorComparingDouble = Comparator.comparingDouble((v0) -> {
                        return AuraUtil.a(v0);
                    });
                    break;
                case "ХП":
                    comparatorComparingDouble = Comparator.comparingDouble((v0) -> {
                        return v0.method_6032();
                    });
                    break;
                default:
                    comparatorComparingDouble = Comparator.comparingDouble(e3 -> {
                        return Math.acos(class_3532.method_15350(class_243.method_1030(aM_.field_1724.method_36455(), aM_.field_1724.method_36454()).method_1026(e3.method_5829().method_1005().method_1020(eye).method_1029()), -1.0d, 1.0d));
                    });
                    break;
            }
            order = comparatorComparingDouble;
        }
        Stream<class_1309> stream2 = StreamSupport.stream(aM_.field_1687.method_18112().spliterator(), false)
                .filter(class_1309.class::isInstance)
                .map(class_1309.class::cast)
                .filter(e4 -> e4 != aM_.field_1724 && e4.method_5805())
                .filter(this::a)
                .filter(this::b);
        if (!allowBehindWalls) {
            stream2 = stream2.filter(e5 -> {
                return AuraUtil.a(eye, e5, reach);
            });
        }
        return stream2.min(order);
    }

    private boolean b(class_1309 entity) {
        if (entity == null || !entity.method_5805() || !a(entity)) {
            return false;
        }
        if (entity instanceof class_1657) {
            boolean isFriend = Delta.h().d().e().d(entity.method_5477().getString());
            boolean naked = Stream.of(class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166).noneMatch(slot -> {
                return entity.method_6118(slot).method_7909() instanceof class_1738;
            });
            if (!a("Игроки")) {
                return false;
            }
            if (isFriend) {
                return a("Друзья");
            }
            return !naked || a("Без брони");
        }
        if ((entity instanceof class_1588) || (entity instanceof class_1621) || (entity instanceof class_1307) || (entity instanceof class_1510)) {
            return a("Враждебные мобы");
        }
        if ((entity instanceof class_1296) || (entity instanceof class_1427) || (entity instanceof class_7298) || (entity instanceof class_1421)) {
            return a("Животные");
        }
        return false;
    }

    private boolean a(String name) {
        BooleanSetting setting = this.i.a(name);
        return setting != null && setting.c().booleanValue();
    }

    private boolean c(class_1309 entity) {
        return Stream.of(class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166).anyMatch(s -> {
            return entity.method_6118(s).method_7909() instanceof class_1738;
        });
    }

    private void w() {
        class_243 class_243VarMethod_33571 = aM_.field_1724.method_33571();
        class_1309 class_1309Var = this.t;
        double dFloatValue = this.j.c().floatValue();
        boolean z = this.h.c().contains("ФанТайм") || !this.n.a("Враг за стеной").c().booleanValue();
        class_243 targetPosition = AuraUtil.a(class_243VarMethod_33571, class_1309Var, dFloatValue, z);
        float yawToTarget = targetPosition == class_243.field_1353 ? Look.b() : (float) class_3532.method_15338(Math.toDegrees(Math.atan2(targetPosition.field_1350, targetPosition.field_1352)) - 90.0d);
        float pitchToTarget = targetPosition == class_243.field_1353 ? Look.c() : (float) (-Math.toDegrees(Math.atan2(targetPosition.field_1351, Math.hypot(targetPosition.field_1352, targetPosition.field_1350))));
        System.arraycopy(this.u, 0, this.u, 1, 29);
        this.u[0] = pitchToTarget;
        if (this.t != null && this.b >= 2 && ((ServerUtil.a.a(this.t) > 6.0f || this.c[2] > 43.0f) && this.c[2] >= 33.0f && ((this.b == 4 || Math.random() > 0.5d) && (!this.f || !AuraUtil.a(aM_.field_1724.method_36454(), aM_.field_1724.method_36455(), 3.0d, this.t, false))))) {
            ((platform.inject.invokers.MinecraftClientInvoker) aM_).invokeDoAttack();
            ChatUtil.a(Boolean.valueOf(this.f));
            if (Math.random() > 0.5d) {
                this.f = !this.f;
            }
            this.c[2] = (int) MathUtil.a(-10.0f, 10.0f);
        }
        boolean skip = (this.n.a("Используется предмет").c().booleanValue() && aM_.field_1724.method_6115() && aM_.field_1724.method_6014() > 0 && this.b >= 8) || !(this.n.a("Открыт контейнер") == null || !this.n.a("Открыт контейнер").c().booleanValue() || aM_.field_1755 == null || (aM_.field_1755 instanceof GUIScreen) || (aM_.field_1755 instanceof AssistantScreen));
        if ((this.c[3] <= 0.0f && q()) || AuraUtil.a(this.b, this.t, skip)) {
            this.c[3] = 1.0f;
            if (!aM_.field_1724.method_5799() && this.p.c().booleanValue() && !aM_.field_1724.method_24828()) {
                this.c[0] = 1.0f;
            }
        }
        if (Delta.h().d().t().F().m() && q() && AuraUtil.a(this.t, 3.0d) && aM_.field_1724.method_6128()) {
            Delta.h().d().k().a(new Rotation(yawToTarget, pitchToTarget), 180.0f, 0, 3);
        }
        if (!this.h.c().contains("ФанТайм") && (InventoryUtil.b(class_1802.field_49814) != -1 || (Delta.h().d().t().H().e && aM_.field_1724.field_6017 > 3.0f && ((Double) MaceUtil.a(aM_.field_1724, (class_1937) aM_.field_1687).map(pos -> {
            return Double.valueOf(pos.method_1022(aM_.field_1724.method_19538()));
        }).orElse(Double.valueOf(0.0d))).doubleValue() > 2.0d && AuraUtil.a(this.t, 4.0d + (aM_.field_1724.method_18798().method_1033() * 3.0d))))) {
            float t = aM_.field_1724.field_6012 + aM_.method_61966().method_60637(false);
            float smoothW = ((float) ((((Math.sin(t * 0.31f) * 0.5d) + (Math.sin((t * 0.73f) + 1.1f) * 0.3000000314327426d)) + (Math.sin((t * 1.7f) + 2.6f) * 0.2000000098386085d)) * 8.0d)) / 8.0f;
            float finalYaw = AuraUtil.a(aM_.field_1724.method_36454(), yawToTarget, 0.8f);
            float finalPitch = AuraUtil.a(aM_.field_1724.method_36455(), pitchToTarget, 0.8f);
            Delta.h().d().k().a(new Rotation(finalYaw + smoothW, finalPitch + smoothW), 180.0f, 1, 2);
        }
        switch (this.h.c()) {
            case "ФанТайм":
            case "ФанТайм ФОВ":
                a(yawToTarget, pitchToTarget, targetPosition);
                break;
            case "Легит":
                b(yawToTarget, pitchToTarget, targetPosition);
                break;
        }
        float[] fArr = this.c;
        fArr[3] = fArr[3] - 1.0f;
        float[] fArr2 = this.c;
        fArr2[5] = fArr2[5] - 1.0f;
        float[] fArr3 = this.c;
        fArr3[8] = fArr3[8] - 1.0f;
        this.c[1] = (float) class_3532.method_15338(Math.toDegrees(Math.atan2(this.t.method_23321() - aM_.field_1724.method_23321(), this.t.method_23317() - aM_.field_1724.method_23317())) - 90.0d);
    }

    private void a(float yawToTarget, float pitchToTarget, class_243 vec3d) {
        float t = aM_.field_1724.field_6012 + aM_.method_61966().method_60637(false);
        float smoothW = (float) ((Math.sin(((double) t) * 0.4000000008323731d) * 3.0d) + (Math.sin((((double) t) * 0.9500002390239708d) + 1.4000004888461306d) * 2.0d));
        float smoothH = (float) ((Math.cos((((double) t) * 0.5d) + 0.7000001555309916d) * 0.5d) + (Math.cos((((double) t) * 0.7800000620494261d) + 3.10000031689524d) * 1.5d));
        float finalPitch = AuraUtil.a(aM_.field_1724.method_36455(), this.u[class_3532.method_15340(10 - this.b, 0, 29)] + (smoothH * 1.5f), MathUtil.a(0.1f, 0.5f));
        float finalYaw = AuraUtil.a(aM_.field_1724.method_36454(), yawToTarget + smoothW, MathUtil.a(0.1f, 0.4f));
        if (this.c[3] >= 0.0f) {
            if (!AuraUtil.a(aM_.field_1724.method_36454(), aM_.field_1724.method_36455(), this.j.c().floatValue(), this.t, true) && this.c[8] <= 0.0f) {
                finalYaw = yawToTarget;
            }
            if (!AuraUtil.a(yawToTarget, finalPitch, this.j.c().floatValue(), this.t, true) && this.c[8] <= 0.0f) {
                finalPitch = pitchToTarget;
            }
            if (!AuraUtil.a(aM_.field_1724.method_36454() + smoothW, aM_.field_1724.method_36454() + smoothH, this.j.c().floatValue(), this.t, true) && AuraUtil.a(aM_.field_1724.method_36454(), aM_.field_1724.method_36455(), this.j.c().floatValue(), this.t, true)) {
                smoothW = class_3532.method_15363(smoothW, -0.05f, 0.05f);
                smoothH = class_3532.method_15363(smoothH, -0.05f, 0.05f);
            }
        }
        if (this.b <= 4 && this.c[2] % 2.0f == 0.0f) {
            finalYaw = aM_.field_1724.method_36454();
        }
        Delta.h().d().k().a(new Rotation(finalYaw + smoothW, (this.h.c().equals("ФанТайм") ? finalPitch : Look.c()) + smoothH), 220.0f, 1, 1);
    }

    private void b(float yawToTarget, float pitchToTarget, class_243 vec3d) {
        float t = aM_.field_1724.field_6012 + aM_.method_61966().method_60637(false);
        float fSin = ((float) (((Math.sin(t * 0.31f) * 0.5d) + (Math.sin((t * 1.7f) + 2.6f) * 0.2000000098386085d)) * 8.0d)) / 4.0f;
        float smoothW = fSin;
        float smoothH = fSin;
        float finalYaw = AuraUtil.a(aM_.field_1724.method_36454(), yawToTarget, MathUtil.a(0.2f, 0.35f));
        float finalPitch = AuraUtil.a(aM_.field_1724.method_36455(), pitchToTarget, MathUtil.a(0.15f, 0.25f));
        if (this.c[3] >= 0.0f) {
            finalPitch = AuraUtil.a(aM_.field_1724.method_36455(), pitchToTarget, 0.35f);
            smoothH /= 3.0f;
            smoothW /= 3.0f;
            if (!AuraUtil.a(aM_.field_1724.method_36454(), aM_.field_1724.method_36455(), this.j.c().floatValue(), this.t, true)) {
                finalYaw = AuraUtil.a(aM_.field_1724.method_36454(), yawToTarget, MathUtil.a(0.7f, 1.0f));
            }
        }
        if (!AuraUtil.a(finalYaw + smoothW, finalPitch + smoothH, this.j.c().floatValue(), this.t, true) && AuraUtil.a(yawToTarget, pitchToTarget, this.j.c().floatValue(), this.t, true)) {
            smoothW = class_3532.method_15363(smoothW, -0.15f, 0.15f);
            smoothH = class_3532.method_15363(smoothH, -0.15f, 0.15f);
        }
        if (this.c[5] >= 0.0f) {
            smoothW *= 8.0f;
            if (this.b >= 1 && this.c[2] % 5.0f == 0.0f) {
                finalPitch = AuraUtil.a(aM_.field_1724.method_36455(), -pitchToTarget, 0.05f);
            }
        }
        Delta.h().d().k().a(new Rotation(finalYaw + smoothW, finalPitch + smoothH), 180.0f, 1, 1);
    }
}
