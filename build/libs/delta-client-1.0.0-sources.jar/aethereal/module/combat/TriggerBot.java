package aethereal.module.combat;

import aethereal.module.combat.AuraUtil;
import aethereal.ui.screen.AssistantScreen;
import aethereal.ui.screen.GUIScreen;
import platform.inject.accessors.ClientPlayerEntityAccessor;
import platform.inject.invokers.MinecraftClientInvoker;
import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Module;
import aethereal.util.InventoryUtil;
import aethereal.util.Look;
import aethereal.util.MathUtil;
import aethereal.util.MoveUtil;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.InputEvent;
import aethereal.event.TickEvent;
import aethereal.event.WillLandEvent;

import aethereal.setting.BooleanSetting;
import aethereal.util.CounterUtil;
import aethereal.setting.ModeSetting;
import aethereal.setting.MultiModeSetting;
import java.util.Comparator;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import lombok.Generated;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2848;
import net.minecraft.class_3532;

@ModuleRegister(a = "Trigger Bot", b = "Автоматически наносит удар при наведении прицела на цель", c = Category.Combat)
public class TriggerBot extends Module {
    private int l;
    boolean c;
    public int d;
    private int m;
    private float n;
    private class_1309 o;
    private final MultiModeSetting f = new MultiModeSetting("Цели для атаки", new BooleanSetting("Игроки", true), new BooleanSetting("Животные", false), new BooleanSetting("Мобы", false), new BooleanSetting("Друзья", true));
    private final MultiModeSetting g = new MultiModeSetting("Дополнительно", new BooleanSetting("Только критические удары", true), new BooleanSetting("Адаптивные удары", true), new BooleanSetting("Случайные промахи", true));
    private final MultiModeSetting h = new MultiModeSetting("Не бить когда", new BooleanSetting("Используется предмет", true), new BooleanSetting("Открыт контейнер", true), new BooleanSetting("Враг за стеной", false));
    private final ModeSetting i = new ModeSetting("Сброс спринта", "Легитный", "Легитный", "Рейдж");
    private final ModeSetting j = new ModeSetting("Выбор таргета", "Свободный", "Свободный", "Фиксирующий");
    BooleanSetting b = new BooleanSetting("Преследование цели", false);
    private final CounterUtil k = new CounterUtil();
    boolean e = false;

    @Generated
    public int r() {
        return this.d;
    }

    @Generated
    public class_1309 s() {
        return this.o;
    }

    public TriggerBot() {
        a(this.f, this.g, this.h, this.i, this.j, this.b);
    }

    @Override
    public void c() {
        super.c();
        this.o = null;
        this.l = 0;
        this.d = 0;
        this.k.b();
    }

    @EventTarget
    public void a(InputEvent e) {
        if (this.b.c().booleanValue() && this.o != null) {
            MoveUtil.a(e, this.n, 3);
        }
        if (this.o != null) {
            class_243 targetPosition = AuraUtil.a(aM_.field_1724.method_33571(), this.o, 3.0d, true);
            this.n = targetPosition == class_243.field_1353 ? Look.b() : (float) class_3532.method_15338(Math.toDegrees(Math.atan2(targetPosition.field_1350, targetPosition.field_1352)) - 90.0d);
        }
        if (this.i.l("Легитный") && this.l > 0) {
            e.a(0.0f);
            e.b(0.0f);
            this.l--;
        }
    }

    @EventTarget
    public void a(TickEvent event) {
        t();
    }

    @EventTarget
    public void a(WillLandEvent e) {
        this.c = e.b() && !aM_.field_1724.method_24828();
    }

    private void t() {
        this.d++;
        v();
        if (this.o != null && this.g.a("Случайные промахи").c().booleanValue() && this.d >= 2 && this.m >= 30 && (((Math.random() > 0.5d && this.d >= 1) || this.d == 4) && (!this.e || !AuraUtil.a(aM_.field_1724.method_36454(), aM_.field_1724.method_36455(), 3.0d, this.o, false)))) {
            ((platform.inject.invokers.MinecraftClientInvoker) aM_).invokeDoAttack();
            this.e = !this.e;
            this.m = (int) MathUtil.a(-10.0f, 10.0f);
        }
        if (this.o != null && AuraUtil.a(this.d, this.o, false)) {
            this.l = 1;
        }
        u();
    }

    private void u() {
        if (this.o == null || !q()) {
            return;
        }
        if (!AuraUtil.a(aM_.field_1724.method_36454(), aM_.field_1724.method_36455(), 3.0d, this.o, !this.h.a("Враг за стеной").c().booleanValue())) {
            return;
        }
        boolean skip = false;
        if ((Delta.h().d().t().H().e || (aM_.field_1724.field_6017 > 2.0f && Delta.h().d().t().H().c.c().booleanValue())) && InventoryUtil.b(class_1802.field_49814) != -1) {
            if (aM_.field_1724.field_6017 < 1.5f) {
                return;
            }
            double landDist = ((Double) MaceUtil.a(aM_.field_1724, (class_1937) aM_.field_1687).map(pos -> {
                return Double.valueOf(pos.method_1022(this.o.method_19538()));
            }).orElse(Double.valueOf(33.0d))).doubleValue();
            boolean hitNow = landDist > 2.0d;
            if ((!this.c && !MaceUtil.b() && Delta.h().d().t().H().b.c().booleanValue() && !hitNow) || !MaceUtil.a() || aM_.field_1724.method_6128()) {
                return;
            } else {
                skip = true;
            }
        }
        if (skip || !w()) {
            aM_.field_1761.method_2918(aM_.field_1724, this.o);
            aM_.field_1724.method_6104(class_1268.field_5808);
            if (Math.random() <= 0.899999737739563d) {
                this.m++;
            }
            this.d = 0;
        }
    }

    private void v() {
        if (this.j.l("Фиксирующий")) {
            if (!a(this.o) || (MaceUtil.a() && !this.c && !aM_.field_1724.method_7357().method_7904(class_1802.field_49814.method_7854()))) {
                this.o = d(false);
                return;
            }
            return;
        }
        class_1309 aimed = d(true);
        if (aimed != null) {
            this.o = aimed;
            this.k.b();
        } else if (this.o != null && this.k.a(1000L)) {
            this.o = null;
        }
    }

    private boolean a(class_1309 entity) {
        return entity != null && entity.method_5805() && !entity.method_7325() && entity != aM_.field_1724 && b(entity) && d(entity);
    }

    private boolean b(class_1309 entity) {
        if (Delta.h().d().t().G().m() && aM_.field_1724.method_6128()) {
            return true;
        }
        return AuraUtil.a((class_1297) entity, 4.0d + (aM_.field_1724.method_18798().method_1033() * 3.0d) + ((double) ((InventoryUtil.b(class_1802.field_49814) == -1 || ((double) aM_.field_1724.field_6017) <= 1.5d) ? 0.0f : 1.5f)) + ((double) ((Delta.h().d().t().H().m() && InventoryUtil.b(class_1802.field_49814) != -1 && ((Boolean) MaceUtil.a(aM_.field_1724, (class_1937) aM_.field_1687).map(p -> {
            return Boolean.valueOf(aM_.field_1724.method_23318() - p.method_10214() > 2.0d);
        }).orElse(false)).booleanValue()) ? 10 : 0)));
    }

    private boolean c(class_1309 entity) {
        return Stream.of(class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166).anyMatch(s -> {
            return entity.method_6118(s).method_7909() instanceof class_1738;
        });
    }

    private boolean w() {
        if (!((platform.inject.accessors.ClientPlayerEntityAccessor) aM_.field_1724).getWasSprinting() || aM_.field_1724.method_5799() || aM_.field_1724.method_5771() || aM_.field_1724.method_5681() || aM_.field_1724.method_24828()) {
            return false;
        }
        if (this.i.l("Рейдж")) {
            ((platform.inject.accessors.ClientPlayerEntityAccessor) aM_.field_1724).setWasSprinting(false);
            aM_.field_1724.method_5728(false);
            aM_.field_1724.field_3944.method_52787(new class_2848(aM_.field_1724, class_2848.class_2849.field_12985));
            this.l = 1;
            return false;
        }
        this.l = 1;
        return ((platform.inject.accessors.ClientPlayerEntityAccessor) aM_.field_1724).getWasSprinting();
    }

    public boolean q() {
        if (this.h.a("Используется предмет") != null && this.h.a("Используется предмет").c().booleanValue() && aM_.field_1724.method_6115() && aM_.field_1724.method_6014() > 0 && this.d >= 8) {
            this.d = 8;
            return false;
        }
        if ((this.h.a("Открыт контейнер") != null && this.h.a("Открыт контейнер").c().booleanValue() && aM_.field_1755 != null && !(aM_.field_1755 instanceof GUIScreen) && !(aM_.field_1755 instanceof AssistantScreen)) || !AuraUtil.a(this.o, 3.0d)) {
            return false;
        }
        if (Delta.h().d().t().H().e) {
            if (aM_.field_1724.method_7357().method_7904(aM_.field_1724.method_6047())) {
                return false;
            }
        } else if (aM_.field_1724.field_6017 > 1.5f) {
            if (aM_.field_1724.method_7357().method_7904(aM_.field_1724.method_6047()) || this.d <= 3) {
                return false;
            }
        } else if (MaceUtil.a()) {
            if (aM_.field_1724.method_7357().method_7904(aM_.field_1724.method_6047()) || aM_.field_1724.method_7261(0.5f) < 0.9f) {
                return false;
            }
        } else if (aM_.field_1724.method_7261(0.5f) < 0.9f || this.d < 10) {
            return false;
        }
        return AuraUtil.c() || (this.g.a("Адаптивные удары").c().booleanValue() && aM_.field_1724.method_24828() && !aM_.field_1724.field_3913.field_54155.comp_3163()) || !AuraUtil.b();
    }

    private class_1309 d(boolean aimed) {
        if (!aimed) {
            return (this.h.a("Враг за стеной").c().booleanValue() ? e(false).or(() -> {
                return e(true);
            }) : e(true)).orElse(null);
        }
        float yaw = aM_.field_1724.method_36454();
        float pitch = aM_.field_1724.method_36455();
        return x().filter(e -> {
            return AuraUtil.a(yaw, pitch, 3.0d, e, !this.h.a("Враг за стеной").c().booleanValue());
        }).min(Comparator.comparingDouble((v0) -> {
            return AuraUtil.a(v0);
        })).orElse(null);
    }

    private Optional<class_1309> e(boolean allowBehindWalls) {
        Comparator<? super class_1309> comparatorComparingDouble;
        class_243 eye = aM_.field_1724.method_33571();
        if (MaceUtil.a()) {
            class_243 landing = MaceUtil.a(aM_.field_1724, (class_1937) aM_.field_1687).orElse(null);
            class_243 landingEye = landing != null ? landing.method_1031(0.0d, aM_.field_1724.method_5751(), 0.0d) : null;
            comparatorComparingDouble = Comparator.comparing((class_1309 e) ->
                Boolean.valueOf(!AuraUtil.a(eye, e, 4.0d) && (landingEye == null || !AuraUtil.a(landingEye, e, 4.0d)))
            ).thenComparing((class_1309 e2) ->
                Boolean.valueOf(aM_.field_1724.field_6017 > 1.0f && !c(e2))
            ).thenComparingDouble((class_1309 v0) -> AuraUtil.a(v0));
        } else {
            comparatorComparingDouble = Comparator.comparingDouble(e3 -> {
                return Math.acos(class_3532.method_15350(class_243.method_1030(aM_.field_1724.method_36455(), aM_.field_1724.method_36454()).method_1026(e3.method_5829().method_1005().method_1020(eye).method_1029()), -1.0d, 1.0d));
            });
        }
        Stream<class_1309> stream = x();
        if (!allowBehindWalls) {
            stream = stream.filter(e4 -> {
                return AuraUtil.a(eye, e4, 4.0d);
            });
        }
        return stream.min(comparatorComparingDouble);
    }

    private Stream<class_1309> x() {
        return StreamSupport.stream(aM_.field_1687.method_18112().spliterator(), false)
                .filter(class_1309.class::isInstance)
                .map(class_1309.class::cast)
                .filter(this::a);
    }

    private boolean d(class_1309 e) {
        if (e instanceof class_1657) {
            class_1657 p = (class_1657) e;
            return this.f.a("Игроки").c().booleanValue() && (this.f.a("Друзья").c().booleanValue() || !Delta.h().d().e().d(p.method_5477().getString()));
        }
        if (e instanceof class_1308) {
            return this.f.a("Мобы").c().booleanValue();
        }
        if (e instanceof class_1429) {
            return this.f.a("Животные").c().booleanValue();
        }
        return false;
    }
}
