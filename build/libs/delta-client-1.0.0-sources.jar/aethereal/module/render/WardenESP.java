package aethereal.module.render;

import platform.inject.accessors.WorldAccessor;
import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.InterfaceC0020Opcode;
import aethereal.core.Module;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.ProjectUtil;
import aethereal.util.ServerUtil;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.DrawEvent;

import aethereal.util.CounterUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.Generated;
import net.minecraft.class_1531;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_5562;
import org.joml.Vector2f;

@ModuleRegister(a = "Warden ESP", b = "Отображает сундуки в городе варденов с таймером возрождения", c = Category.Render)
public class WardenESP extends Module {
    private static final Pattern b = Pattern.compile("(\\d{2}):(\\d{2})");
    private final List<a> c = new ArrayList();

    @EventTarget
    public void a(DrawEvent event) {
        if (aM_.field_1687.method_27983().method_29177().toString().equals("minecraft:overworld")) {
            List<class_2338> chests = q();
            if (event.b()) {
                for (class_1531 class_1531Var : aM_.field_1687.method_8390(class_1531.class, aM_.field_1724.method_5829().method_1014(256.0), e -> true)) {
                    if (class_1531Var instanceof class_1531) {
                        class_1531 stand = (class_1531) class_1531Var;
                        Matcher matcher = b.matcher(stand.method_5477().getString());
                        if (matcher.find()) {
                            int minutes = Integer.parseInt(matcher.group(1));
                            int seconds = Integer.parseInt(matcher.group(2));
                            long ms = ((((long) minutes) * 60) + ((long) seconds)) * 1000;
                            class_2338 nearest = a(chests, stand.method_24515());
                            if (nearest != null) {
                                a existing = b(nearest);
                                if (existing != null) {
                                    existing.a(ms);
                                } else {
                                    this.c.add(new a(nearest, ms));
                                }
                            }
                        }
                    }
                }
                this.c.removeIf(info -> {
                    return info.a() <= 0;
                });
                a(event, chests);
            }
            if (event.c()) {
                b(event, chests);
            }
        }
    }

    private void a(DrawEvent event, List<class_2338> chests) {
        int background = ColorUtil.a(11, 11, 13, InterfaceC0020Opcode.cR);
        for (class_2338 coord : chests) {
            a info = b(coord);
            if (info != null) {
                Vector2f screen = ProjectUtil.a(((double) coord.method_10263()) + 0.5d, coord.method_10264() + 1, ((double) coord.method_10260()) + 0.5d);
                if (ProjectUtil.a(screen)) {
                    int totalSec = (int) (info.a() / 1000);
                    class_2561 text = class_2561.method_43470(String.format(Locale.US, "%02d:%02d", Integer.valueOf(totalSec / 60), Integer.valueOf(totalSec % 60)));
                    float width = 16.5f + Fonts.e.a(text, 6.5f);
                    float x = screen.x() - (width / 2.0f);
                    float y = screen.y() - 6.0f;
                    event.d().a(event.h(), x, y, width - 0.5f, 12.0f, 3.5f, background, 1.0f, background, 6.0f);
                    event.d().a(event.h(), class_2960.method_60655("delta", "pictures/minecraft/chest.png"), x + 3.0f, y + 0.5f + 2.0f, 7.0f, 7.0f, 0.0f, -1);
                    Fonts.e.a(event.h(), text, x + 3.0f + 8.0f + 2.0f, (y + ((12.0f - Fonts.e.a(6.5f)) / 2.0f)) - 0.5f, 6.5f);
                }
            }
        }
    }

    private void b(DrawEvent event, List<class_2338> chests) {
        for (class_2338 coord : chests) {
            if (b(coord) == null) {
                event.e().a(event.h(), new class_238(coord.method_10263(), coord.method_10264(), coord.method_10260(), coord.method_10263() + 1, coord.method_10264() + 1, coord.method_10260() + 1), ColorUtil.a(255, 100, 100, 255), 1.0f);
            }
        }
    }

    private class_2338 a(List<class_2338> chests, class_2338 standPos) {
        for (class_2338 coord : chests) {
            if (standPos.method_10263() == coord.method_10263() && standPos.method_10260() == coord.method_10260()) {
                return coord;
            }
        }
        return null;
    }

    private a b(class_2338 pos) {
        int currentAnarchy = ServerUtil.a.d();
        for (a info : this.c) {
            if (info.c().equals(pos) && info.e() == currentAnarchy) {
                return info;
            }
        }
        return null;
    }

    public long a(class_2338 pos) {
        for (class_1531 class_1531Var : aM_.field_1687.method_8390(class_1531.class, aM_.field_1724.method_5829().method_1014(256.0), e -> true)) {
            if (class_1531Var instanceof class_1531) {
                class_1531 stand = (class_1531) class_1531Var;
                if (stand.method_24515().method_10263() == pos.method_10263() && stand.method_24515().method_10260() == pos.method_10260()) {
                    Matcher matcher = b.matcher(stand.method_5477().getString());
                    if (matcher.find()) {
                        return ((((long) Integer.parseInt(matcher.group(1))) * 60) + ((long) Integer.parseInt(matcher.group(2)))) * 1000;
                    }
                }
            }
        }
        a info = b(pos);
        if (info == null) {
            return -1L;
        }
        return info.a();
    }

    public List<class_2338> q() {
        class_2586 blockEntity;
        class_2591<?> type;
        List<class_2338> result = new ArrayList<>();
        for (class_5562 ticker : ((platform.inject.accessors.WorldAccessor) aM_.field_1687).getBlockEntityTickers()) {
            class_2338 pos = ticker.method_31705();
            if (!ticker.method_31704() && pos.method_10264() >= -60 && pos.method_10264() <= -35 && pos.method_10263() >= -2070 && pos.method_10263() <= -1921 && pos.method_10260() >= -2076 && pos.method_10260() <= -1929 && (blockEntity = aM_.field_1687.method_8321(pos)) != null && ((type = blockEntity.method_11017()) == class_2591.field_11914 || type == class_2591.field_11891)) {
                result.add(pos);
            }
        }
        return result;
    }

    public static class a {
        private final class_2338 b;
        private long c;
        private final CounterUtil a = new CounterUtil();
        private int d = ServerUtil.a.d();

        @Generated
        public CounterUtil b() {
            return this.a;
        }

        @Generated
        public class_2338 c() {
            return this.b;
        }

        @Generated
        public long d() {
            return this.c;
        }

        @Generated
        public int e() {
            return this.d;
        }

        public a(class_2338 chestPos, long current) {
            this.b = chestPos;
            this.c = current;
            this.a.b();
        }

        public void a(long current) {
            if (Math.abs((current / 1000) - (a() / 1000)) > 5) {
                this.c = current;
                this.a.b();
                this.d = ServerUtil.a.d();
            }
        }

        public long a() {
            return Math.max(0L, this.c - this.a.c());
        }
    }
}
