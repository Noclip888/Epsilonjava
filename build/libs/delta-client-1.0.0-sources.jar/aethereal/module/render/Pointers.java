package aethereal.module.render;

import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.InterfaceC0020Opcode;
import aethereal.core.Module;
import aethereal.render.ColorUtil;
import aethereal.util.Look;
import aethereal.util.MathUtil;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.DrawEvent;
import aethereal.setting.BooleanSetting;

import aethereal.setting.MultiModeSetting;
import aethereal.setting.SliderSetting;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

@ModuleRegister(a = "Pointers", b = "Указывает лучами направление к игрокам", c = Category.Render)
public class Pointers extends Module {
    private final MultiModeSetting b = new MultiModeSetting("Визуальные настройки", new BooleanSetting("Фильтр по друзьям", false), new BooleanSetting("Трассировка до игрока", true), new BooleanSetting("Навигационная стрелка", true));
    private final SliderSetting c = new SliderSetting("Размер стрелки", 7.0f, 5.0f, 15.0f, 1.0f);
    private final SliderSetting d = new SliderSetting("Отступ от центра", 30.0f, 20.0f, 50.0f, 1.0f);
    private float e;

    public Pointers() {
        a(this.b, this.c, this.d);
    }

    @EventTarget
    public void a(DrawEvent event) {
        if (event.c() && this.b.a("Трассировка до игрока").c().booleanValue()) {
            class_243 cam = aM_.method_1561().field_4686.method_19326();
            class_243 start = new class_243(0.0d, 0.0d, 27.0d).method_1037((float) (-Math.toRadians(aM_.method_1561().field_4686.method_19329()))).method_1024((float) (-Math.toRadians(aM_.method_1561().field_4686.method_19330()))).method_1019(cam);
            Matrix4f matrix = event.h().method_23760().method_23761();
            class_287 buffer = q();
            boolean any = false;
            for (class_1297 _e : aM_.field_1687.method_18112()) {
            if (!(_e instanceof class_1657 class_746Var)) continue;
                if (class_746Var instanceof class_1657) {
                    class_1657 player = (class_1657) class_746Var;
                    if (class_746Var != aM_.field_1724 && class_746Var.method_5805()) {
                        class_243 pos = MathUtil.a((class_1297) class_746Var, event.g()).method_1031(0.0d, class_746Var.method_17682() / 2.0f, 0.0d);
                        boolean isFriend = Delta.h().d().e().d(player.method_5477().getString());
                        if (!this.b.a("Фильтр по друзьям").c().booleanValue() || isFriend) {
                            buffer.method_22918(matrix, (float) (start.method_10216() - cam.field_1352), (float) (start.method_10214() - cam.field_1351), (float) (start.method_10215() - cam.field_1350)).method_22915(isFriend ? 0.0f : 1.0f, 1.0f, isFriend ? 0.0f : 1.0f, 1.0f);
                            buffer.method_22918(matrix, (float) (pos.method_10216() - cam.field_1352), (float) (pos.method_10214() - cam.field_1351), (float) (pos.method_10215() - cam.field_1350)).method_22915(isFriend ? 0.0f : 1.0f, 1.0f, isFriend ? 0.0f : 1.0f, 1.0f);
                            any = true;
                        }
                    }
                }
            }
            a(buffer, any);
        }
        if (event.b() && this.b.a("Навигационная стрелка").c().booleanValue()) {
            this.e = MathUtil.c(this.e, this.e + class_3532.method_15393(Look.b() - this.e), 2.0f);
            for (class_1297 _e : aM_.field_1687.method_18112()) {
            if (!(_e instanceof class_1657 class_746Var2)) continue;
                if (class_746Var2 instanceof class_1657) {
                    class_1657 player2 = (class_1657) class_746Var2;
                    if (class_746Var2 != aM_.field_1724 && class_746Var2.method_5805()) {
                        boolean isFriend2 = Delta.h().d().e().d(player2.method_5477().getString());
                        if (!this.b.a("Фильтр по друзьям").c().booleanValue() || isFriend2) {
                            class_243 pos2 = MathUtil.a((class_1297) class_746Var2, event.g());
                            class_243 eye = MathUtil.a((class_1297) aM_.field_1724, event.g());
                            float angle = class_3532.method_15393(((float) Math.toDegrees(Math.atan2(eye.field_1352 - pos2.method_10216(), pos2.method_10215() - eye.field_1350))) - this.e);
                            float radians = (float) Math.toRadians(angle);
                            class_4587 stack = event.h();
                            stack.method_22903();
                            stack.method_46416((aM_.method_22683().method_4486() / 2.0f) + (((float) Math.sin(radians)) * this.d.c().floatValue()), (aM_.method_22683().method_4502() / 2.0f) - (((float) Math.cos(radians)) * this.d.c().floatValue()), 0.0f);
                            stack.method_22907(class_7833.field_40718.rotationDegrees(angle));
                            event.d().a(stack, class_2960.method_60655("delta", "pictures/pointer.png"), (-this.c.c().floatValue()) / 2.0f, (-this.c.c().floatValue()) / 2.0f, this.c.c().floatValue(), this.c.c().floatValue(), 0.0f, isFriend2 ? ColorUtil.a(85, 255, 85, InterfaceC0020Opcode.aL) : ColorUtil.a(255, 255, 255, InterfaceC0020Opcode.aL));
                            stack.method_22909();
                        }
                    }
                }
            }
        }
    }

    private class_287 q() {
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(class_10142.field_53876);
        return class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
    }

    private void a(class_287 buffer, boolean draw) {
        if (draw) {
            class_286.method_43433(buffer.method_60800());
        } else {
            buffer.method_60800();
        }
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
}
