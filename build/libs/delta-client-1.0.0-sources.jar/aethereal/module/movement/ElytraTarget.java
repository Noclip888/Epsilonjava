package aethereal.module.movement;

import aethereal.module.combat.AuraUtil;
import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.TickEvent;
import aethereal.module.combat.Aura;
import aethereal.util.Rotation;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import aethereal.util.CounterUtil;

@ModuleRegister(a = "Elytra Target", b = "Наводит на врага в полёте на элитре и ускоряется фейерверком из второй руки", c = Category.Movement)
public class ElytraTarget extends Module {
    private final CounterUtil b = new CounterUtil();

    @EventTarget
    public void a(TickEvent event) {
        Aura aura = Delta.h().d().t().B();
        if (aura.m() && aM_.field_1724.method_6128()) {
            if (aM_.field_1724.method_6079().method_7909() != class_1802.field_8639 && !Delta.h().d().t().V().b) {
                if (Delta.h().d().v().a().a().isEmpty()) {
                    Delta.h().d().v().a().a(class_1802.field_8639, 45, 1);
                }
            } else if ((this.b.a(150L) && aM_.field_1724.method_18798().method_1033() < 1.5d) || aura.b == 1) {
                aM_.field_1761.method_2919(aM_.field_1724, class_1268.field_5810);
                this.b.b();
            }
            class_1309 target = aura.s();
            if (target == null) {
                return;
            }
            class_243 eye = aM_.field_1724.method_33571();
            class_243 enemy = target.method_5829().method_1005();
            double dx = enemy.field_1352 - eye.field_1352;
            double dz = enemy.field_1350 - eye.field_1350;
            double horizontal = Math.sqrt((dx * dx) + (dz * dz));
            double nx = horizontal == 0.0d ? 0.0d : dx / horizontal;
            double nz = horizontal == 0.0d ? 0.0d : dz / horizontal;
            double lift = Math.max(0.0d, 3.0d - q());
            class_243 aim = new class_243(enemy.field_1352 + (nx * 4.0d), enemy.field_1351 + lift, enemy.field_1350 + (nz * 4.0d));
            Rotation aimRotation = Rotation.a(eye, aim);
            float Yaw = AuraUtil.a(aM_.field_1724.method_36454(), aimRotation.c(), 1.0f);
            float Pitch = AuraUtil.a(aM_.field_1724.method_36455(), aura.b <= 3 ? 0.0f : aimRotation.d(), aura.b <= 3 ? 1.0f : Math.clamp(aura.b / 10.0f, 0.0f, 1.0f));
            Delta.h().d().k().a(new Rotation(Yaw, Pitch), 180.0f, 1, 1);
        }
    }

    private double q() {
        class_243 start = aM_.field_1724.method_19538();
        class_243 end = start.method_1023(0.0d, 2.0d, 0.0d);
        class_3965 class_3965VarMethod_17742 = aM_.field_1687.method_17742(new class_3959(start, end, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, aM_.field_1724));
        if (class_3965VarMethod_17742.method_17783() == class_239.class_240.field_1333) {
            return 2.0d;
        }
        return start.method_10214() - class_3965VarMethod_17742.method_17784().field_1351;
    }
}
