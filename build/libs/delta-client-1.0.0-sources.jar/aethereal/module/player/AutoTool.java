package aethereal.module.player;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.core.ModuleRegister;
import aethereal.event.TickEvent;
import aethereal.handler.InventoryHandler;

import java.util.Comparator;
import java.util.stream.IntStream;
import net.minecraft.class_1661;
import net.minecraft.class_1743;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_3965;

@ModuleRegister(a = "Auto Tool", b = "Автоматически выбирает подходящий инструмент для блока", c = Category.Player)
public class AutoTool extends Module implements Interface {
    private final int[] b = {-1, -1};

    @EventTarget
    public void a(TickEvent event) {
        int bestSlot;
        InventoryHandler handler = Delta.h().d().v().a();
        if (handler.a().isEmpty()) {
            if (aM_.field_1765 instanceof class_3965 class_3965Var) {
                class_3965 hit = class_3965Var;
                if (aM_.field_1690.field_1886.method_1434()) {
                    if (this.b[0] != -1 || (bestSlot = a(aM_.field_1687.method_8320(hit.method_17777()))) == -1) {
                        return;
                    }
                    this.b[0] = aM_.field_1724.method_31548().field_7545;
                    if (bestSlot > 8) {
                        this.b[1] = bestSlot;
                        handler.a(bestSlot, this.b[0], 1);
                        return;
                    } else {
                        aM_.field_1724.method_31548().field_7545 = bestSlot;
                        return;
                    }
                }
            }
            if (this.b[0] == -1) {
                return;
            }
            if (this.b[1] == -1) {
                aM_.field_1724.method_31548().field_7545 = this.b[0];
            } else {
                handler.a(this.b[1], this.b[0], 1);
            }
            this.b[0] = -1;
            this.b[1] = -1;
        }
    }

    private int a(class_2680 state) {
        int shears;
        class_1661 inventory = aM_.field_1724.method_31548();
        return (!state.method_27852(class_2246.field_10343) || (shears = IntStream.range(0, inventory.field_7547.size()).filter(i -> {
            return inventory.method_5438(i).method_31574(class_1802.field_8868);
        }).findFirst().orElse(-1)) == -1) ? IntStream.range(0, inventory.field_7547.size()).filter(i2 -> {
            return inventory.method_5438(i2).method_7924(state) > 1.0f && a(inventory.method_5438(i2), state);
        }).boxed().max(Comparator.comparingDouble(i3 -> {
            return inventory.method_5438(i3.intValue()).method_7924(state);
        })).orElse(-1).intValue() : shears;
    }

    private boolean a(class_1799 stack, class_2680 state) {
        if (state.method_26164(class_3481.field_33713)) {
            return stack.method_7909() instanceof class_1743;
        }
        if (state.method_26164(class_3481.field_33715)) {
            return stack.method_7909() instanceof class_1810;
        }
        if (state.method_26164(class_3481.field_33716)) {
            return stack.method_7909() instanceof class_1821;
        }
        if (state.method_26164(class_3481.field_33714)) {
            return stack.method_7909() instanceof class_1794;
        }
        return true;
    }
}
