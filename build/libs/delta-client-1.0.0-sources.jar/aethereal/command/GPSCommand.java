package aethereal.command;

import aethereal.util.BooleanUtils;
import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.util.ChatUtil;

import aethereal.command.BaseCommand;
import aethereal.command.Command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import lombok.Generated;
import net.minecraft.class_2172;
import net.minecraft.class_243;

@Command(a = "gps")
public class GPSCommand extends BaseCommand {
    private class_243 c;

    @Generated
    public class_243 c() {
        return this.c;
    }

    @Override
    public void a(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(a(BooleanUtils.c).executes(context -> {
            if (this.c == null) {
                ChatUtil.a((Object) "GPS-метка сейчас отсутствует");
                return 1;
            }
            this.c = null;
            ChatUtil.a((Object) "GPS-метка больше не отображается");
            return 1;
        })).then(e("x").executes(context2 -> {
            ChatUtil.a((Object) "Использование: .gps <x> <z>, .gps <x> <y> <z> или .gps off");
            return 1;
        }).then(e("y или z").executes(context3 -> {
            a(new class_243(b((CommandContext<class_2172>) context3, "x"), aM_.field_1724.method_23318(), b((CommandContext<class_2172>) context3, "y или z")));
            return 1;
        }).then(e("z").executes(context4 -> {
            a(new class_243(b((CommandContext<class_2172>) context4, "x"), b((CommandContext<class_2172>) context4, "y или z"), b((CommandContext<class_2172>) context4, "z")));
            return 1;
        })))).then(a("event").executes(context5 -> {
            Delta.h().d().u().c().a(WayCommand.a.GPS);
            aM_.field_1724.field_3944.method_45731("event delay");
            return 1;
        })).executes(context6 -> {
            ChatUtil.a((Object) "Использование: .gps <x> <z>, .gps <x> <y> <z> или .gps off");
            return 1;
        });
    }

    public void a(class_243 pos) {
        this.c = pos;
        ChatUtil.a((Object) ("GPS-метка установлена: " + ((int) pos.method_10216()) + ", " + ((int) pos.method_10214()) + ", " + ((int) pos.method_10215())));
    }
}
