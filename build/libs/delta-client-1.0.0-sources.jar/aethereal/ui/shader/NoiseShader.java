package aethereal.ui.shader;

import static aethereal.core.Interface.aM_;
import aethereal.core.EventManager;

import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.event.ResizeEvent;
import aethereal.ui.shader.Shader;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.class_10366;
import net.minecraft.class_278;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_6367;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;

public class NoiseShader extends Shader implements Interface {
    private static final class_2960 c = class_2960.method_60655("delta", "core/noise/noise_shader");
    private final Matrix4f d;
    private class_6367 e;
    private class_278 f;
    private class_278 g;

    public NoiseShader() {
        super(c, class_290.field_1576);
        this.d = new Matrix4f();
        EventManager.a(this);
    }

    @EventTarget
    public void a(ResizeEvent event) {
        this.e = new class_6367(aM_.method_22683().method_4489(), aM_.method_22683().method_4506(), true);
    }

    public void e() {
        if (this.e != null) {
            this.e.method_29329(aM_.method_1522());
        }
    }

    @Override
    protected void b() {
        this.f = a("TintColor");
        this.g = a("Time");
    }

    public void a(float[] color) {
        if (this.e != null) {
            RenderSystem.backupProjectionMatrix();
            RenderSystem.setProjectionMatrix(this.d, class_10366.field_54953);
            Matrix4fStack modelView = RenderSystem.getModelViewStack();
            modelView.pushMatrix().identity();
            RenderSystem.disableDepthTest();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableCull();
            RenderSystem.setShaderTexture(0, aM_.method_1522().method_30277());
            RenderSystem.setShaderTexture(1, aM_.method_1522().method_30278());
            RenderSystem.setShaderTexture(2, this.e.method_30278());
            a();
            if (this.f != null) {
                this.f.method_35657(color[0], color[1], color[2], color[3]);
            }
            if (this.g != null) {
                this.g.method_1251((System.currentTimeMillis() % 100000) / 1000.0f);
            }
            int white = new Color(255, 255, 255, 255).getRGB();
            class_287 builder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
            builder.method_22912(-1.0f, -1.0f, 0.0f).method_39415(white);
            builder.method_22912(-1.0f, 1.0f, 0.0f).method_39415(white);
            builder.method_22912(1.0f, 1.0f, 0.0f).method_39415(white);
            builder.method_22912(1.0f, -1.0f, 0.0f).method_39415(white);
            class_286.method_43433(builder.method_60800());
            RenderSystem.setShaderTexture(0, 0);
            RenderSystem.setShaderTexture(1, 0);
            RenderSystem.setShaderTexture(2, 0);
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            RenderSystem.enableDepthTest();
            modelView.popMatrix();
            RenderSystem.restoreProjectionMatrix();
        }
    }
}
