package aethereal.ui.screen;

import aethereal.render.ScaleUtil;
import aethereal.core.NativeMethodLookup;
import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Interface;
import aethereal.core.Category;
import aethereal.core.Module;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.MathUtil;

import aethereal.ui.screen.GUIPanel;

import aethereal.render.AnimationUtil;
import aethereal.ui.element.TextField;
import aethereal.api.Compile;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;
import lombok.Generated;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5611;
import org.joml.Vector4f;

public class GUIScreen extends class_437 {
    private final TextField a;
    private final AnimationUtil b;
    private final List<GUIPanel> c;
    private String d;

    @Compile
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        double dA = MathUtil.scale(mouseX, 2);
        double dA2 = MathUtil.scale(mouseY, 2);
        ScaleUtil.a(context, 2);
        double dSum = this.c.stream().mapToDouble(new ToDoubleFunction() {
            @Override
            public double applyAsDouble(Object obj) {
                return ((GUIPanel) obj).f().z;
            }
        }).sum();
        float size = (this.c.size() - 1) * 8.0f;
        class_310 class_310Var = Interface.aM_;
        int iMethod_4486 = class_310Var.method_22683().method_4486();
        float f = size + ((float) dSum);
        float f2 = (iMethod_4486 - f) * 0.5f;
        float f3 = f2;
        float f4 = 0.0f;
        for (final GUIPanel gUIPanel : this.c) {
            Vector4f vector4fF = gUIPanel.f();
            gUIPanel.a(Delta.h().d().t().e().stream().filter(obj -> this.a(gUIPanel, (Module) obj)).sorted(Comparator.comparing(new Function() {
                @Override
                public Object apply(Object obj) {
                    return ((Module) obj).j();
                }
            }, String.CASE_INSENSITIVE_ORDER)).toList());
            vector4fF.x = f3;
            vector4fF.y = (class_310Var.method_22683().method_4502() - vector4fF.w) * 0.5f;
            f4 = vector4fF.y;
            gUIPanel.a(context, (int) dA, (int) dA2, delta);
            f3 += vector4fF.z + 8.0f;
        }
        Iterator<GUIPanel> it = this.c.iterator();
        while (it.hasNext()) {
            it.next().a(context, dA, dA2, delta);
        }
        float f5 = ((GUIPanel) this.c.getFirst()).f().w;
        class_4587 class_4587VarMethod_51448 = context.method_51448();
        float fC = ((GUIPanel) this.c.getFirst()).b().c();
        float fEase = EasingList.s.ease(fC);
        class_4587VarMethod_51448.method_22903();
        float fEase2 = EasingList.p.ease(fC);
        float f6 = (0.5f * f) + f2;
        float f7 = f5 + f4;
        float f8 = 12.0f + f7 + 10.0f;
        float f9 = ((1.0f - fEase2) * 14.0f) + f8;
        float f10 = (0.15f * fEase) + 0.85f;
        class_4587VarMethod_51448.method_46416(f6, f9, 0.0f);
        class_4587VarMethod_51448.method_22905(f10, f10, 1.0f);
        class_4587VarMethod_51448.method_46416(-f6, -f8, 0.0f);
        a(context, f6, f7, (int) dA, (int) dA2, delta);
        class_4587VarMethod_51448.method_22909();
        a(context.method_51448(), f6, f4, delta);
        ScaleUtil.a(context);
    }

    @Compile
    public boolean method_25402(final double mouseX, final double mouseY, final int button) {
        TextField textField = this.a;
        List<GUIPanel> list = this.c;
        textField.a(MathUtil.scale(mouseX, 2), MathUtil.scale(mouseY, 2), button);
        if (list.stream().filter(obj -> GUIScreen.f((GUIPanel) obj)).anyMatch(obj -> ((GUIPanel) obj).a(MathUtil.scale(mouseX, 2), MathUtil.scale(mouseY, 2), button))) {
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Compile
    public boolean method_25406(final double mouseX, final double mouseY, final int button) {
        if (this.c.stream().filter(obj -> GUIScreen.e((GUIPanel) obj)).anyMatch(obj -> ((GUIPanel) obj).b(MathUtil.scale(mouseX, 2), MathUtil.scale(mouseY, 2), button))) {
            return true;
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    @Compile
    public boolean method_25403(final double mouseX, final double mouseY, final int button, final double deltaX, final double deltaY) {
        TextField textField = this.a;
        List<GUIPanel> list = this.c;
        textField.b(MathUtil.scale(mouseX, 2), MathUtil.scale(mouseY, 2), button);
        if (list.stream().filter(obj -> GUIScreen.d((GUIPanel) obj)).anyMatch(obj -> ((GUIPanel) obj).a(MathUtil.scale(mouseX, 2), MathUtil.scale(mouseY, 2), button, MathUtil.scale(deltaX, 2), MathUtil.scale(deltaY, 2)))) {
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Compile
    public boolean method_25401(final double mouseX, final double mouseY, double horizontalAmount, final double verticalAmount) {
        double scaledX = MathUtil.scale(mouseX, 2);
        double scaledY = MathUtil.scale(mouseY, 2);
        for (GUIPanel panel : this.c) {
            if (panel.d() == null) {
                continue;
            }
            Vector4f bounds = panel.f();
            if (MathUtil.a(scaledX, scaledY, bounds.x, bounds.y, bounds.z, bounds.w)) {
                return panel.a(scaledX, scaledY, verticalAmount);
            }
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Compile
    public boolean method_25404(final int keyCode, final int scanCode, final int modifiers) {
        TextField textField = this.a;
        List<GUIPanel> list = this.c;
        if (keyCode == 70 && (modifiers & 2) != 0) {
            textField.a(!textField.j());
            return true;
        }
        if (textField.j()) {
            textField.a(keyCode, scanCode, modifiers);
            return true;
        }
        if (list.stream().filter(obj -> GUIScreen.b((GUIPanel) obj)).anyMatch(obj -> ((GUIPanel) obj).a(keyCode, scanCode, modifiers))) {
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Compile
    public boolean method_25400(final char character, final int modifiers) {
        TextField textField = this.a;
        List<GUIPanel> list = this.c;
        if (textField.j()) {
            textField.a(character, modifiers);
            return true;
        }
        if (list.stream().filter(obj -> GUIScreen.a((GUIPanel) obj)).anyMatch(obj -> ((GUIPanel) obj).a(character, modifiers))) {
            return true;
        }
        return super.method_25400(character, modifiers);
    }

    static {
        NativeMethodLookup.lookup(GUIScreen.class, 5);
    }

    @Generated
    public TextField a() {
        return this.a;
    }

    @Generated
    public AnimationUtil b() {
        return this.b;
    }

    @Generated
    public List<GUIPanel> c() {
        return this.c;
    }

    @Generated
    public String d() {
        return this.d;
    }

    public GUIScreen(class_2561 title) {
        super(title);
        this.a = new TextField(TextField.a.GUI);
        this.b = new AnimationUtil();
        this.c = new ArrayList();
        for (Category category : Category.values()) {
            this.c.add(new GUIPanel(category));
        }
        this.a.a("Поиск по модулям");
    }

    public void method_25419() {
        super.method_25419();
        this.c.forEach(panel -> {
            panel.b().c(0.0f);
        });
    }

    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
    }

    public boolean a(GUIPanel panel, Module module) {
        return module.l() == panel.c() && module.j().toLowerCase().contains(this.a.g().toString().toLowerCase());
    }

    private void a(class_332 context, float centerX, float panelBottom, int mouseX, int mouseY, float delta) {
        this.a.b(new class_5611(100.0f, 20.0f));
        this.a.a(new class_5611(centerX - 50.0f, panelBottom + 12.0f));
        this.a.a(context, mouseX, mouseY, delta, 1.0f);
    }

    private void a(class_4587 matrices, float centerX, float panelTop, float delta) {
        Delta.h().d().o();
        Module hovered = (Module) this.c.stream().map((v0) -> {
            return v0.e();
        }).filter(module -> {
            return (module == null || module.k() == null || module.k().isEmpty()) ? false : true;
        }).findFirst().orElse(null);
        if (hovered != null && !hovered.k().equals(this.d)) {
            this.d = hovered.k();
            this.b.c(0.0f);
        }
        this.b.a(0.0f, 1.0f, 0.3f, EasingList.i, delta);
        this.b.a(hovered != null);
        float fade = EasingList.p.ease(this.b.c());
        if (fade > 0.0f && this.d != null) {
            float x = centerX - (Fonts.c.a(this.d, 10.0f) / 2.0f);
            float y = ((panelTop - Fonts.c.a(10.0f)) - 8.0f) + ((1.0f - fade) * 4.0f);
            Fonts.c.a(matrices, this.d, x + 0.5f, y + 0.5f, 10.0f, ColorUtil.a(ColorUtil.a(0, 0, 0, 255), 0.5f * fade));
            Fonts.c.a(matrices, this.d, x, y, 10.0f, ColorUtil.a(ColorUtil.a(255, 255, 255, 255), fade));
        }
    }

    public static boolean f(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean e(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean d(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean c(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean b(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean a(GUIPanel panel) {
        return panel.d() != null;
    }
}
