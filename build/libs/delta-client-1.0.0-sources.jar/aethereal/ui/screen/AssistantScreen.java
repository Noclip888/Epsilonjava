package aethereal.ui.screen;

import aethereal.autobuy.AutoBuyEntry;
import aethereal.lib.javassist.TokenId;
import aethereal.autobuy.AutoBuyProcessor;
import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.InterfaceC0020Opcode;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.MathUtil;

import aethereal.config.ThemeInfo;
import aethereal.config.ThemeProcessor;
import aethereal.core.Interface;
import aethereal.render.Draw2DProcessor;
import aethereal.render.Draw3DProcessor;
import aethereal.ui.screen.RadialScreen;

import aethereal.core.Action;
import java.util.Arrays;
import java.util.List;
import lombok.Generated;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5611;

public class AssistantScreen extends class_437 implements Interface {
    private final RadialScreen b;
    private final List<AutoBuyEntry> c;
    private class_5611 d;
    private class_5611 e;
    private int f;
    private int g;

    @Generated
    public RadialScreen a() {
        return this.b;
    }

    @Generated
    public int b() {
        return this.g;
    }

    public AssistantScreen(class_2561 title) {
        super(title);
        this.b = new RadialScreen(2, 75.0f, 101.25f);
        this.c = Arrays.stream(AutoBuyEntry.values()).filter(info -> {
            return info.d() == class_1802.field_8436;
        }).toList();
        this.d = null;
        this.e = null;
        this.f = -1;
        this.g = -1;
        a(this.b.a());
    }

    public void a(int count) {
        this.b.b(Math.max(count, 1));
        for (int i = 0; i < this.b.a(); i++) {
            this.b.a(i, class_1799.field_8037, c(i), true);
        }
    }

    public void a(int slot, AutoBuyEntry potion) {
        this.b.a(slot, potion.a(), potion.b(), c(slot), true);
    }

    public boolean method_25402(double mouseX, double mouseY, int button) {
        int slot;
        if (button == 0 && this.f != -1 && this.d != null && this.e != null) {
            for (int index = 0; index < this.c.size(); index++) {
                float rowY = this.d.method_32119() + (index * 18.0f);
                if (MathUtil.a(mouseX, mouseY, this.d.method_32118(), rowY, this.e.method_32118(), 18.0f)) {
                    AutoBuyEntry potion = this.c.get(index);
                    for (int segment = 0; segment < this.b.a(); segment++) {
                        if (potion.a(this.b.c(segment))) {
                            c();
                            return true;
                        }
                    }
                    int slot2 = this.f;
                    this.b.a(slot2, potion.a(), potion.b(), c(slot2), true);
                    c();
                    return true;
                }
            }
            c();
            return true;
        }
        if (button == 2) {
            int newSlot = this.b.a();
            this.b.b(newSlot + 1);
            this.b.a(newSlot, class_1799.field_8037, c(newSlot), true);
            return true;
        }
        class_5611 center = new class_5611(this.field_22789 / 2.0f, this.field_22790 / 2.0f);
        if (button == 0 && (slot = this.b.a(mouseX, mouseY, center)) >= 0 && !this.b.c(slot).method_7960()) {
            this.g = slot;
            return true;
        }
        int before = this.b.a();
        boolean handled = this.b.a(mouseX, mouseY, button, center);
        if (this.b.a() != before) {
            c();
            for (int i = 0; i < this.b.a(); i++) {
                this.b.a(i, c(i));
            }
        }
        return handled;
    }

    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (button == 0 && this.g != -1) {
            b(this.b.a(mouseX, mouseY, new class_5611(this.field_22789 / 2.0f, this.field_22790 / 2.0f)));
            return true;
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    public void b(int target) {
        if (this.g == -1) {
            return;
        }
        if (target >= 0 && target != this.g) {
            this.b.a(this.g, target);
        } else {
            this.b.d(this.g).execute();
        }
        this.g = -1;
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.b.a(context, mouseX, mouseY, new class_5611(this.field_22789 / 2.0f, this.field_22790 / 2.0f));
        if (this.g != -1 && this.b.a(mouseX, mouseY, new class_5611(this.field_22789 / 2.0f, this.field_22790 / 2.0f)) != this.g) {
            Delta.h().d().j().a(context, this.b.c(this.g), mouseX - 8, mouseY - 8, TokenId.a_, 1.0f, 1.0f, false);
        }
        if (this.f != -1 && this.d != null) {
            a(context, mouseX, mouseY);
        }
    }

    private void a(class_332 context, int mouseX, int mouseY) {
        class_4587 matrices = context.method_51448();
        Draw2DProcessor draw = Delta.h().d().i();
        Draw3DProcessor draw3d = Delta.h().d().j();
        ThemeProcessor theme = Delta.h().d().o();
        draw.a(matrices, this.d.method_32118(), this.d.method_32119(), this.e.method_32118(), this.e.method_32119(), 8.0f, theme.a(ThemeInfo.BACKGROUND_GUI).a(), 1.0f, theme.a(ThemeInfo.BACKGROUND_GUI).a(), 11.0f);
        draw.a(matrices, this.d.method_32118(), this.d.method_32119(), this.e.method_32118(), this.e.method_32119(), 8.0f, 1.0f, ColorUtil.a(255, 255, 255, 15));
        for (int index = 0; index < this.c.size(); index++) {
            AutoBuyEntry potion = this.c.get(index);
            float rowY = this.d.method_32119() + (index * 18.0f);
            boolean hovered = MathUtil.a(mouseX, mouseY, this.d.method_32118(), rowY, this.e.method_32118(), 18.0f);
            if (hovered) {
                draw.a(matrices, this.d.method_32118() + 2.0f, rowY + 1.0f, this.e.method_32118() - 4.0f, 16.0f, 6.0f, ColorUtil.a(255, 255, 255, 12));
            }
            draw3d.a(context, potion.a(), this.d.method_32118() + 5.0f, (rowY + 9.0f) - 6.0f, 0, 1.0f, 0.75f, false);
            Fonts.e.a(matrices, potion.b(), this.d.method_32118() + 5.0f + 12.0f + 4.0f, (rowY + 9.0f) - (Fonts.e.a(6.5f) / 2.0f), 6.5f, hovered ? ColorUtil.a(255, 255, 255, 220) : ColorUtil.a(255, 255, 255, InterfaceC0020Opcode.ap));
        }
    }

    private Action c(int slot) {
        return () -> {
            if (this.b.c(slot).method_7960()) {
                this.f = slot;
                this.d = d(slot);
                this.e = d();
            } else {
                Delta.h().d().v().b().a(this.b.c(slot));
                aM_.field_1724.method_3137();
            }
        };
    }

    private void c() {
        this.f = -1;
        this.d = null;
        this.e = null;
    }

    private class_5611 d() {
        float maxLabelWidth = 0.0f;
        for (AutoBuyEntry potion : this.c) {
            maxLabelWidth = Math.max(maxLabelWidth, Fonts.e.a(potion.b(), 6.5f));
        }
        return new class_5611(26.0f + maxLabelWidth + 10.0f, this.c.size() * 18.0f);
    }

    private class_5611 d(int slot) {
        double angleStep = 6.28318530719644d / ((double) this.b.a());
        double startAngle = (-1.5707963569506784d) + (angleStep * ((double) slot));
        return new class_5611((this.field_22789 / 2.0f) + (((float) Math.cos(startAngle + (angleStep / 2.0d))) * 88.125f) + 12.0f, (this.field_22790 / 2.0f) + (((float) Math.sin(startAngle + (angleStep / 2.0d))) * 88.125f) + 12.0f);
    }
}
