package aethereal.ui.screen;

import aethereal.core.NativeMethodLookup;
import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Interface;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.MathUtil;

import aethereal.autobuy.AutoBuySection;
import aethereal.autobuy.CollectorSection;
import aethereal.config.ThemeInfo;
import aethereal.config.ThemeProcessor;
import aethereal.render.Draw2DProcessor;

import aethereal.render.AnimationUtil;
import aethereal.ui.element.Section;
import aethereal.api.Compile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import lombok.Generated;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import org.joml.Vector4f;

public class StationScreen extends class_437 {
    private final List<Section> a;
    private final Vector4f b;
    private final Vector4f c;
    private final Vector4f d;
    private final AnimationUtil e;
    private final AnimationUtil f;
    private int g;
    private float h;

    @Compile
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        Vector4f vector4f = this.b;
        class_310 class_310Var = Interface.aM_;
        vector4f.x = (class_310Var.method_22683().method_4486() - this.b.z) * 0.5f;
        this.b.y = (class_310Var.method_22683().method_4502() - this.b.w) * 0.5f;
        this.f.a(0.0f, 1.0f, 0.3f, EasingList.g, delta);
        this.f.a(true);
        Vector4f vector4f2 = this.b;
        float f = vector4f2.x;
        float f2 = 0.5f * vector4f2.z;
        float f3 = vector4f2.y;
        float f4 = 0.5f * vector4f2.w;
        float fEase = 0.85f + (EasingList.s.ease(this.f.c()) * 0.15f);
        class_4587 class_4587VarMethod_51448 = context.method_51448();
        class_4587VarMethod_51448.method_22903();
        float f5 = f2 + f;
        float f6 = f4 + f3;
        class_4587VarMethod_51448.method_46416(f5, ((1.0f - EasingList.p.ease(this.f.c())) * 14.0f) + f6, 0.0f);
        class_4587VarMethod_51448.method_22905(fEase, fEase, 1.0f);
        class_4587VarMethod_51448.method_46416(-f5, -f6, 0.0f);
        Draw2DProcessor draw2DProcessorI = Delta.h().d().i();
        ThemeProcessor themeProcessorO = Delta.h().d().o();
        int iA = themeProcessorO.a(ThemeInfo.BACKGROUND_GUI).a();
        ThemeInfo themeInfo = ThemeInfo.PRIMARY;
        int iA2 = ColorUtil.a(ColorUtil.a(iA, themeProcessorO.a(themeInfo).a(), themeProcessorO.a(themeInfo).b() * 0.25f), 220);
        draw2DProcessorI.a(context.method_51448(), vector4f2.x, vector4f2.y, vector4f2.z, vector4f2.w, 8.0f, iA2, 1.0f, iA2, 16.0f);
        draw2DProcessorI.a(context.method_51448(), vector4f2.x, vector4f2.y, vector4f2.z, vector4f2.w, 8.0f, 0.5f, themeProcessorO.a(ThemeInfo.OUTLINE_MEDIUM).a());
        a(context, delta, iA2);
        this.d.set(vector4f2.x, this.c.y + this.c.w + 8.0f, vector4f2.z, ((vector4f2.y + vector4f2.w) - 8.0f) - ((this.c.y + this.c.w) + 12.0f));
        b().a(context, this.d, mouseX, mouseY, this.e.a(), delta);
        Draw2DProcessor draw2DProcessorI2 = Delta.h().d().i();
        float f7 = this.h;
        draw2DProcessorI2.a(context, f7 - 3.0f, this.c.y + this.c.w, 6.0f, 0.5f, Delta.h().d().o().a(ThemeInfo.PRIMARY).a());
        class_4587VarMethod_51448.method_22909();
        this.e.a(Math.min(0.0f, this.d.w - b().a(this.d)), 0.0f, 1.0f);
    }

    @Compile
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (b().a(mouseX, mouseY, verticalAmount)) {
            return true;
        }
        this.e.a(((float) verticalAmount) * 15.0f);
        return true;
    }

    @Compile
    public boolean method_25402(double mouseX, double mouseY, int button) {
        Vector4f vector4f = this.c;
        List<Section> list = this.a;
        Vector4f vector4f2 = this.d;
        AnimationUtil animationUtil = this.e;
        float f = vector4f.x + 12.0f;
        for (int i = 0; list.size() > i; i++) {
            float fB = Fonts.a.b(list.get(i).b(), 8.5f);
            if (MathUtil.a(mouseX, mouseY, f - 6.0f, vector4f.y, fB + 12.0f, vector4f.w)) {
                this.g = i;
                animationUtil.b(0.0f);
                return true;
            }
            f += fB + 12.0f;
        }
        if (vector4f2.y > mouseY || !b().a(mouseX, mouseY, button)) {
            return super.method_25402(mouseX, mouseY, button);
        }
        return true;
    }

    @Compile
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (b().b(mouseX, mouseY, button)) {
            return true;
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    @Compile
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (b().a(mouseX, mouseY, button, deltaX, deltaY)) {
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Compile
    public boolean method_25400(char character, int modifiers) {
        if (b().a(character, modifiers)) {
            return true;
        }
        return super.method_25400(character, modifiers);
    }

    @Compile
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        Section sectionB = b();
        if (sectionB == null) {
            throw new NullPointerException();
        }
        if (sectionB.a(keyCode, scanCode, modifiers)) {
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    static {
        NativeMethodLookup.lookup(StationScreen.class, 17);
    }

    @Generated
    public AnimationUtil a() {
        return this.e;
    }

    public StationScreen(class_2561 title) {
        this(title, 0);
    }

    public StationScreen(class_2561 title, int selected) {
        super(title);
        this.a = new ArrayList();
        this.b = new Vector4f(0.0f, 0.0f, 425.0f, 235.0f);
        this.c = new Vector4f(0.0f, 0.0f, 0.0f, 16.0f);
        this.d = new Vector4f(0.0f, 0.0f, 0.0f, 0.0f);
        this.e = new AnimationUtil();
        this.f = new AnimationUtil();
        this.a.add(new CollectorSection());
        this.a.add(new AutoBuySection());
        this.g = selected;
    }

    public void method_25419() {
        super.method_25419();
        this.f.c(0.0f);
    }

    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
    }

    private Section b() {
        return this.a.get(this.g);
    }

    private void a(class_332 context, float delta, int background) {
        Draw2DProcessor draw = Delta.h().d().i();
        ThemeProcessor theme = Delta.h().d().o();
        float iconsWidth = 12.0f * (this.a.size() - 1);
        Iterator<Section> it = this.a.iterator();
        while (it.hasNext()) {
            iconsWidth += Fonts.a.b(it.next().b(), 8.5f);
        }
        this.c.z = iconsWidth + 24.0f;
        this.c.x = this.b.x + ((this.b.z - this.c.z) / 2.0f);
        this.c.y = this.b.y + 8.0f;
        draw.a(context.method_51448(), this.c.x, this.c.y, this.c.z, this.c.w, 6.0f, 0.5f, ColorUtil.a(255, 255, 255, 4));
        Fonts.a.a(context.method_51448(), "a", this.b.x + 8.0f, this.c.y + ((this.c.w - Fonts.a.a(12.0f)) / 2.0f), 12.0f, ColorUtil.a(theme.a(ThemeInfo.PRIMARY).a(), 0.75f));
        float separatorX = this.b.x + 8.0f + Fonts.a.a("a", 12.0f) + 8.0f;
        draw.a(context.method_51448(), separatorX, this.c.y + ((this.c.w - 8.0f) / 2.0f), 0.75f, 8.0f, 0.0f, ColorUtil.a(255, 255, 255, 25));
        Fonts.c.a(context.method_51448(), "deltaclient.xyz", separatorX + 8.0f, (this.c.y + ((this.c.w - Fonts.c.a(6.75f)) / 2.0f)) - 0.5f, 6.75f, theme.a(ThemeInfo.TEXT_DISABLED).a());
        float avatarX = ((this.b.x + this.b.z) - 12.0f) - 8.0f;
        draw.a(context.method_51448(), class_2960.method_60655("delta", "icon.png"), avatarX, this.c.y + ((this.c.w - 12.0f) / 2.0f), 12.0f, 12.0f, 5.0f, -1);
        String sectionName = b().c();
        float separatorX2 = avatarX - 8.0f;
        draw.a(context.method_51448(), separatorX2, this.c.y + ((this.c.w - 8.0f) / 2.0f), 0.75f, 8.0f, 0.0f, ColorUtil.a(255, 255, 255, 25));
        Fonts.c.a(context.method_51448(), sectionName, (separatorX2 - 8.0f) - Fonts.c.a(sectionName, 6.75f), (this.c.y + ((this.c.w - Fonts.c.a(6.75f)) / 2.0f)) - 0.5f, 6.75f, theme.a(ThemeInfo.TEXT_DISABLED).a());
        float x = this.c.x + 12.0f;
        float y = this.c.y + ((this.c.w - Fonts.a.a(8.5f)) / 2.0f);
        float target = this.h;
        int i = 0;
        while (i < this.a.size()) {
            Section section = this.a.get(i);
            float iconWidth = Fonts.a.b(section.b(), 8.5f);
            section.a().a(i == this.g);
            section.a().a(0.0f, 1.0f, 0.3f, EasingList.i, delta);
            Fonts.a.a(context.method_51448(), section.b(), x, y, 8.5f, ColorUtil.a(theme.a(ThemeInfo.TEXT_DISABLED).a(), ColorUtil.a(theme.a(ThemeInfo.PRIMARY).a(), 1.0f), section.a().c()));
            if (i == this.g) {
                target = x + (iconWidth / 2.0f);
            }
            x += iconWidth + 12.0f;
            i++;
        }
        this.h = this.h == 0.0f ? target : MathUtil.c(this.h, target, 1.25f);
    }
}
