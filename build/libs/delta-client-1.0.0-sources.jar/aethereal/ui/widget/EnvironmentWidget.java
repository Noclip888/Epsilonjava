package aethereal.ui.widget;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.InterfaceC0020Opcode;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.InventoryUtil;
import aethereal.util.ServerUtil;

import aethereal.config.ThemeInfo;
import aethereal.config.ThemeProcessor;
import aethereal.core.GlobalEvent;
import aethereal.core.Interface;
import aethereal.event.DrawEvent;
import aethereal.module.misc.StreamerMode;
import aethereal.ui.element.DragInfo;
import aethereal.ui.widget.Widget;

import aethereal.setting.BooleanSetting;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;
import net.minecraft.class_10130;
import net.minecraft.class_1068;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_408;
import net.minecraft.class_742;
import net.minecraft.class_7923;
import net.minecraft.class_9334;

public class EnvironmentWidget extends Widget implements Interface {
    private final BooleanSetting f;
    private final Map<UUID, b> g;
    private final List<UUID> h;
    private final UUID[] i;

    public EnvironmentWidget() {
        super(new DragInfo("Окружение", 0.0f, 0.0f, 0.0f, 0.0f));
        this.f = new BooleanSetting("Показывать броню", true);
        this.g = new HashMap();
        this.h = new ArrayList();
        this.i = new UUID[2];
        j().a(this);
        a(this.f);
    }

    @Override
    public void a(DrawEvent event) {
        d().a(0.0f, 1.0f, 0.3f, EasingList.g, event.g());
        float animation = a();
        float x = j().a();
        float y = j().b();
        Stream<UUID> stream = this.h.stream();
        Map<UUID, b> map = this.g;
        Objects.requireNonNull(map);
        List<b> shown = stream.map((v1) -> {
            return map.get(v1);
        }).filter((v0) -> {
            return Objects.nonNull(v0);
        }).toList();
        float width = 14.5f + Fonts.e.a("Окружение", this.e) + 5.0f;
        for (b data : shown) {
            width = Math.max(width, Math.max(20.0f + Fonts.e.a(data.d + ((int) data.f) + "HP", 6.5f) + 34.0f, (data.b.size() * 15.0f) - 2.0f));
        }
        j().c(width);
        if (animation > 0.0f) {
            a(event, "x", "Окружение", width, animation);
        }
        float contentY = y + this.d + 3.0f;
        Iterator<b> it = shown.iterator();
        while (it.hasNext()) {
            contentY += a(event, it.next(), x, contentY, width, animation);
        }
        j().d(Math.max(this.d, (contentY - y) - 2.0f));
        super.a(event);
    }

    private float a(DrawEvent event, b data, float x, float y, float width, float animation) {
        float textY = (y + ((12.0f - Fonts.e.a(6.5f)) / 2.0f)) - 0.5f;
        String health = ((int) data.f) + "HP";
        a(event, x, y, width, 12.0f, 3.0f, animation, false);
        event.d().a(event.h(), x + 2.0f, y + 2.0f, 8.0f, 8.0f, 1.5f, ColorUtil.a(-1, animation), 0.125f, 0.125f, 0.125f, 0.125f, aM_.method_1531().method_4619(data.e).method_4624());
        Fonts.e.a(event.h(), health, ((x + width) - 3.0f) - Fonts.e.a(health, 6.5f), textY, 6.5f, ColorUtil.a(-1, animation));
        float right = ((x + width) - 4.0f) - Fonts.e.a(health, 6.5f);
        if (this.f.c().booleanValue()) {
            for (int i = 3; i >= 0; i--) {
                if (!data.c[i].method_7960()) {
                    right -= 7.0f;
                    event.e().a(event.i(), InventoryUtil.a(data.c[i]), right - 2.0f, y + 2.0f, 0, animation, 0.5f, false);
                }
            }
        }
        Fonts.e.c(event.h(), data.d, x + 12.5f, textY, 6.5f, ColorUtil.a(-1, animation), (right - 16.5f) - x);
        if (data.b.isEmpty()) {
            return 14.0f;
        }
        long now = System.currentTimeMillis();
        List<a> history = new ArrayList<>(data.b.values());
        Collections.reverse(history);
        for (int i2 = 0; i2 < history.size(); i2++) {
            a entry = history.get(i2);
            float itemX = x + (i2 * 15.0f);
            float itemY = y + 12.0f + 2.0f;
            int left = entry.a(now);
            a(event, itemX, itemY, 13.0f, 13.0f, 2.0f, animation, entry.c != 0);
            event.e().a(event.i(), entry.a, itemX + 2.1f, itemY + 2.1f, 0, animation, 0.55f, entry.c == 0);
            if (left > 0) {
                String text = left > 99 ? "99+" : String.valueOf(left);
                float textWidth = Fonts.e.a(text, 6.5f);
                float badge = textWidth + 6.0f;
                float badgeX = itemX + ((13.0f - badge) / 2.0f);
                float badgeY = itemY - 4.0f;
                float textX = badgeX + (((badge - textWidth) - 0.3f) / 2.0f);
                float textY2 = badgeY + ((8.0f - Fonts.e.a(6.5f)) / 2.0f) + 1.0f;
                int color = ColorUtil.a(ColorUtil.a(255, 60, 60, 255), animation);
                a(event, badgeX + 1.5f, badgeY + 1.0f, badge - 3.0f, 8.0f, 2.0f, animation, false);
                Fonts.e.a(event.h(), text, textX, textY2, 6.5f, color);
                Fonts.e.a(event.h(), text, textX + 0.3f, textY2, 6.5f, color);
            }
        }
        return 29.0f;
    }

    private void a(DrawEvent event, float x, float y, float width, float height, float radius, float animation, boolean empty) {
        ThemeProcessor theme = Delta.h().d().o();
        int background = ColorUtil.a(theme.a(ThemeInfo.BACKGROUND_HUD).a(), theme.a(ThemeInfo.PRIMARY).a(), theme.a(ThemeInfo.PRIMARY).b() / 6.0f);
        event.d().b(event.h(), x, y, width, height, radius, ColorUtil.a(empty ? ColorUtil.a(background, ColorUtil.a(255, 60, 60, 255), 0.35f) : background, theme.a(ThemeInfo.BACKGROUND_HUD).b() * animation), animation);
    }

    @Override
    public void a(GlobalEvent event) {
        class_1657 class_1657Var;
        if (aM_.field_1687 != null && aM_.field_1724 != null) {
            class_1657 class_1657VarS = (class_1657) Delta.h().d().t().B().s();
            if (class_1657VarS instanceof class_1657) {
                class_1657 aura = class_1657VarS;
                class_1657Var = aura;
            } else {
                class_1657 class_1657VarS2 = (class_1657) Delta.h().d().t().X().s();
                if (class_1657VarS2 instanceof class_1657) {
                    class_1657 trigger = class_1657VarS2;
                    class_1657Var = trigger;
                } else {
                    class_1657Var = null;
                }
            }
            class_1657 target = class_1657Var;
            if (target != null && !target.method_5667().equals(this.i[0])) {
                this.i[1] = this.i[0];
                this.i[0] = target.method_5667();
            }
            long now = System.currentTimeMillis();
            List<? extends class_1657> nearby = aM_.field_1687.method_18456().stream().filter(player -> {
                return (player == aM_.field_1724 || !player.method_5805() || Delta.h().d().e().d(player.method_5477().getString())) ? false : true;
            }).sorted(Comparator.<class_1657>comparingInt((class_1657 player2) -> {
                if (player2.method_5667().equals(this.i[0])) {
                    return 0;
                }
                return player2.method_5667().equals(this.i[1]) ? 1 : 2;
            }).thenComparingInt((class_1657 player3) -> {
                return -a(player3);
            }).thenComparing((class_1657 player4) -> {
                return player4.method_5477().getString();
            }, (String v0, String v1) -> {
                return v0.compareToIgnoreCase(v1);
            })).limit(2L).toList();
            this.h.clear();
            for (class_1657 player5 : nearby) {
                this.h.add(player5.method_5667());
                this.g.computeIfAbsent(player5.method_5667(), b::new).a(player5, now);
            }
            this.g.values().removeIf(data -> {
                return !this.h.contains(data.a) && now - data.g > 30000;
            });
        }
        d().a(aM_.field_1687 != null && (!this.h.isEmpty() || (aM_.field_1755 instanceof class_408)));
        super.a(event);
    }

    private static int a(class_1657 player) {
        int i;
        int score = 0;
        for (int i2 = 0; i2 < 4; i2++) {
            String name = class_7923.field_41178.method_10221(player.method_6118(class_1304.values()[5 - i2]).method_7909()).method_12832();
            int i3 = score;
            if (name.startsWith("netherite_")) {
                i = 4;
            } else if (name.startsWith("diamond_")) {
                i = 3;
            } else if (name.startsWith("iron_")) {
                i = 2;
            } else {
                i = name.startsWith("leather_") ? 1 : 0;
            }
            score = i3 + i;
        }
        return score;
    }

    static int a(class_1799 stack) {
        if (stack.method_31574(class_1802.field_8551) || stack.method_31574(class_1802.field_22021) || stack.method_31574(class_1802.field_8543) || stack.method_31574(class_1802.field_8479) || stack.method_31574(class_1802.field_8614) || stack.method_31574(class_1802.field_49098) || stack.method_31574(class_1802.field_8449)) {
            return 3;
        }
        if (stack.method_57826(class_9334.field_50075)) {
            return 2;
        }
        return (stack.method_31574(class_1802.field_8287) || stack.method_31574(class_1802.field_8814)) ? 1 : 0;
    }

    static int b(class_1799 stack) {
        if (stack.method_31574(class_1802.field_8367)) {
            return InterfaceC0020Opcode.ap;
        }
        if (stack.method_31574(class_1802.field_8479) || stack.method_31574(class_1802.field_8449) || stack.method_31574(class_1802.field_8814)) {
            return 60;
        }
        if (stack.method_31574(class_1802.field_8463)) {
            return 30;
        }
        if (stack.method_31574(class_1802.field_8551)) {
            return 25;
        }
        return stack.method_31574(class_1802.field_22021) ? 15 : 0;
    }

    static final class a {
        final class_1799 a;
        long b;
        long c;
        int d;

        a(class_1799 stack, int hand) {
            this.a = stack.method_7972();
            this.a.method_7974(0);
            this.a.method_57379(class_9334.field_53966, new class_10130(0.0f, Optional.of(class_2960.method_60655("delta", "widget"))));
            this.d = hand;
        }

        int a(long now) {
            int total = EnvironmentWidget.b(this.a);
            if (total == 0 || this.b == 0) {
                return 0;
            }
            return Math.max((int) Math.ceil(((((long) total) * 1000) - (now - this.b)) / 1000.0d), 0);
        }
    }

    static final class b {
        final UUID a;
        final LinkedHashMap<class_1792, a> b = new LinkedHashMap<>();
        final class_1799[] c = new class_1799[6];
        String d = "";
        class_2960 e;
        float f;
        long g;

        private b(UUID id) {
            this.a = id;
            Arrays.fill(this.c, class_1799.field_8037);
        }

        void a(class_1657 player, long now) {
            class_2960 class_2960VarComp_1626;
            StreamerMode streamer = Delta.h().d().t().aE();
            this.d = (streamer.m() && streamer.r().c().booleanValue()) ? streamer.a(player.method_5477().getString()) : player.method_5477().getString();
            if (player instanceof class_742) {
                class_742 client = (class_742) player;
                class_2960VarComp_1626 = client.method_52814().comp_1626();
            } else {
                class_2960VarComp_1626 = class_1068.method_4648(this.a).comp_1626();
            }
            this.e = class_2960VarComp_1626;
            this.f = ServerUtil.a.a((class_1309) player);
            this.g = now;
            for (int i = 0; i < 4; i++) {
                this.c[i] = player.method_6118(class_1304.values()[5 - i]);
            }
            class_1799 main = player.method_6047();
            class_1799 off = player.method_6079();
            for (a entry : this.b.values()) {
                if (entry.c == 0 && entry.a.method_7947() == 1 && this.c[entry.d].method_31574(entry.a.method_7909())) {
                    if ((entry.d == 4 ? main : off).method_7960()) {
                        entry.c = now;
                    }
                }
            }
            this.c[4] = main;
            this.c[5] = off;
            for (int hand = 4; hand < 6; hand++) {
                if (EnvironmentWidget.a(this.c[hand]) > 0) {
                    a(player, this.c[hand], hand, now);
                }
            }
            this.b.values().removeIf(entry2 -> {
                return entry2.c != 0 && now - entry2.c > 10000;
            });
        }

        private void a(class_1657 player, class_1799 stack, int hand, long now) {
            a entry = this.b.remove(stack.method_7909());
            if (entry != null) {
                if (stack.method_7947() < entry.a.method_7947() && EnvironmentWidget.b(stack) > 0 && Interface.aM_.field_1687.method_8390(class_1542.class, player.method_5829().method_1014(2.0d), item -> {
                    return item.method_6983().method_31574(stack.method_7909());
                }).isEmpty()) {
                    entry.b = now;
                }
                entry.a.method_7939(stack.method_7947());
                entry.d = hand;
                entry.c = 0L;
                this.b.put(stack.method_7909(), entry);
                return;
            }
            if (this.b.size() >= 9) {
                Optional<class_1792> map = this.b.entrySet().stream().filter(candidate -> {
                    return EnvironmentWidget.a(((a) candidate.getValue()).a) < EnvironmentWidget.a(stack);
                }).findFirst().map((v0) -> {
                    return v0.getKey();
                });
                LinkedHashMap<class_1792, a> linkedHashMap = this.b;
                Objects.requireNonNull(linkedHashMap);
                map.ifPresent(linkedHashMap::remove);
                if (this.b.size() >= 9) {
                    return;
                }
            }
            this.b.put(stack.method_7909(), new a(stack, hand));
        }
    }
}
