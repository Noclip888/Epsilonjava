package aethereal.ui.widget;


import aethereal.core.Delta;
import aethereal.render.EasingList;
import aethereal.render.ColorUtil;
import aethereal.util.MathUtil;

import aethereal.render.AnimationUtil;
import java.util.List;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

public class EffectMarker {
    private EffectMarker() {
    }

    public static void a(List<a> list, float x, float y) {
        if (list != null) {
            list.add(new a(x, y));
        }
    }

    public static void a(class_4587 matrices, float partialTicks, List<a> list) {
        if (list == null || list.isEmpty()) {
            return;
        }
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).a(matrices, partialTicks)) {
                list.remove(i);
            }
        }
    }

    public static final class a {
        private final AnimationUtil a = new AnimationUtil();
        private final long b = System.nanoTime() + 300000000;
        private final float c;
        private final float d;
        private boolean e;

        a(float x, float y) {
            this.c = x;
            this.d = y;
        }

        boolean a(class_4587 matrices, float partialTicks) {
            this.a.a(0.0f, 1.0f, 0.2f, EasingList.h, partialTicks);
            if (!this.e && System.nanoTime() >= this.b) {
                this.e = true;
            }
            this.a.a(!this.e);
            float progress = MathUtil.b(this.a.c(), 0.0f, 1.0f);
            float scale = this.e ? progress : a(progress);
            float length = 4.0f * Math.max(1.0E-4f, scale);
            int color = ColorUtil.a(255, 255, 255, Math.round(250.0f * progress));
            matrices.method_22903();
            matrices.method_46416(this.c, this.d, 0.0f);
            for (int i = 0; i < 4; i++) {
                a(matrices, length, 45.0f + (90.0f * i), length, color);
            }
            matrices.method_22909();
            return this.e && progress <= 0.01f;
        }

        private void a(class_4587 matrices, float length, float angleDeg, float offset, int color) {
            matrices.method_22903();
            matrices.method_22907(class_7833.field_40718.rotationDegrees(angleDeg));
            matrices.method_46416(offset, 0.0f, 0.0f);
            Delta.h().d().i().a(matrices, (-length) / 2.0f, -0.25f, length, 0.5f, 0.0f, color);
            matrices.method_22909();
        }

        private float a(float scale) {
            if (scale <= 0.0f) {
                return 0.0f;
            }
            if (scale < 0.6f) {
                return scale / 0.6f;
            }
            return scale < 0.8f ? 1.0f + (((scale - 0.6f) / 0.5f) * 0.5f) : 1.2f - (((scale - 0.8f) / 0.2f) * 0.2f);
        }
    }
}
