package aethereal.ui.widget;

import aethereal.render.ScissorUtil;
import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Interface;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.InventoryUtil;
import aethereal.util.MathUtil;
import aethereal.util.ServerUtil;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3966;
import net.minecraft.class_408;
import net.minecraft.class_742;
import aethereal.config.ThemeInfo;
import aethereal.core.GlobalEvent;
import aethereal.event.DrawEvent;
import aethereal.module.misc.StreamerMode;
import aethereal.ui.element.DragInfo;
import aethereal.ui.widget.Widget;

import aethereal.render.AnimationUtil;
import aethereal.setting.BooleanSetting;

public class TargetWidget extends Widget {
    private final BooleanSetting f;
    private final BooleanSetting g;
    private final AnimationUtil h;
    private final AnimationUtil i;
    private class_1309 j;
    private String k;

    public TargetWidget() {
        super(new DragInfo("Таргет-худ", 0.0f, 0.0f, 0.0f, 0.0f));
        this.f = new BooleanSetting("Визуализация предметов", true);
        this.g = new BooleanSetting("Отображать при наводке", false);
        this.h = new AnimationUtil();
        this.i = new AnimationUtil();
        this.k = "";
        j().a(this);
        a(this.g, this.f);
    }

    @Override
    public void a(DrawEvent event) {
        String string;
        d().a(0.0f, 1.0f, 0.3f, EasingList.g, event.g());
        if (a() > 0.0f && this.j != null) {
            j().c(100.0f);
            j().d(24.0f);
            float x = j().a();
            float y = j().b();
            a(event, x, y, j().f(), j().g(), true, a());
            float headSize = j().g() / 1.35f;
            float headY = y + ((j().g() - headSize) / 2.0f);
            if (this.j instanceof class_742 player) {
                event.d().a(event.h(), x + 5.0f, headY, headSize, headSize, 2.0f, ColorUtil.a(-1, a()), 0.125f, 0.125f, 0.125f, 0.125f, Interface.aM_.method_1531().method_4619(player.method_52814().comp_1626()).method_4624());
            } else if (this.j != null) {
                Fonts.a.a(event.h(), "B", x + 6.5f + ((headSize - 24.0f) / 2.0f), headY + ((headSize - 24.0f) / 2.0f), 24.0f, ColorUtil.a(-1, a()));
            }
            float textX = x + 5.0f + headSize + 5.0f;
            StreamerMode streamerMode = Delta.h().d().t().aE();
            if (streamerMode.m() && streamerMode.r().c().booleanValue()) {
                string = streamerMode.a(this.j.method_5477().getString());
            } else {
                string = this.j.method_5477().getString();
            }
            String name = string;
            if (name.length() > 12) {
                Fonts.e.c(event.h(), name, textX, headY, 7.5f, ColorUtil.a(-1, a()), Fonts.e.a(name.substring(0, 12), 7.5f));
            } else {
                Fonts.e.a(event.h(), name, textX, headY, 7.5f, ColorUtil.a(-1, a()));
            }
            if (this.f.c().booleanValue()) {
                int i = 0;
                for (class_1799 stack : new class_1799[]{this.j.method_6118(class_1304.field_6166), this.j.method_6118(class_1304.field_6172), this.j.method_6118(class_1304.field_6174), this.j.method_6118(class_1304.field_6169), this.j.method_6079(), this.j.method_6047()}) {
                    if (!stack.method_7960()) {
                        event.e().a(event.i(), InventoryUtil.a(stack), ((x + j().f()) - 10.0f) - (i * 9), y + j().g(), 0, a(), 0.55f, true);
                        i++;
                    }
                }
            }
            int primary = Delta.h().d().o().a(ThemeInfo.PRIMARY).a();
            String hpValue = String.valueOf((int) ServerUtil.a.a(this.j));
            if (this.k.isEmpty()) {
                this.k = hpValue;
            }
            float progress = hpValue.equals(this.k) ? 1.0f : this.i.a(0.0f, 1.0f, 0.75f);
            a(event, hpValue, this.k, ((x + j().f()) - 5.0f) - Fonts.e.a(hpValue, 7.0f), headY + 0.5f, 7.0f, primary, progress);
            if (progress >= 0.99f) {
                this.k = hpValue;
                this.i.c(0.0f);
            }
            float targetHP = MathUtil.b(MathUtil.b(ServerUtil.a.a(this.j), 0.0f, this.j.method_6063()) / this.j.method_6063(), 0.0f, 1.0f);
            float lineHP = this.h.a(targetHP, targetHP, 0.5f);
            float alpha = Delta.h().d().o().a(ThemeInfo.BACKGROUND_HUD).b() * a();
            event.d().a(event.h(), textX, headY + 12.5f, 54.0f, 3.0f, 0.5f, ColorUtil.a(ColorUtil.b(primary, 0.3f), a()));
            event.d().a(event.h(), textX, headY + 12.5f, 54.0f * lineHP, 3.0f, 0.5f, ColorUtil.a(primary, alpha));
        }
        super.a(event);
    }

    private void a(DrawEvent event, String current, String previous, float right, float y, float size, int color, float progress) {
        float height = Fonts.e.a(size);
        float cursor = right + Fonts.e.a(current, size);
        int i = 0;
        while (i < current.length()) {
            char digit = current.charAt((current.length() - 1) - i);
            char old = i < previous.length() ? previous.charAt((previous.length() - 1) - i) : ' ';
            String value = String.valueOf(digit);
            cursor -= Fonts.e.a(value, size);
            if (digit == old || progress >= 1.0f) {
                Fonts.e.a(event.h(), value, cursor, y, size, ColorUtil.a(color, a()));
            } else {
                ScissorUtil.a(event.h(), cursor - 0.5f, y, Fonts.e.a(value, size) + 1.0f, height + 1.0f);
                Fonts.e.a(event.h(), String.valueOf(old), cursor, y - (height * progress), size, ColorUtil.a(color, (1.0f - progress) * a()));
                Fonts.e.a(event.h(), value, cursor, y + (height * (1.0f - progress)), size, ColorUtil.a(color, progress * a()));
                ScissorUtil.a(event.h());
            }
            i++;
        }
    }

    @Override
    public void a(GlobalEvent event) {
        class_1309 class_1309Var;
        class_1309 class_1309Var2;
        class_1309 targets = Delta.h().d().t().B().s() != null ? Delta.h().d().t().B().s() : Delta.h().d().t().X().s();
        if (this.g.c().booleanValue()) {
            class_3966 class_3966Var = Interface.aM_.field_1765 instanceof class_3966 ? (class_3966) Interface.aM_.field_1765 : null;
            if (class_3966Var instanceof class_3966) {
                class_3966 hit = class_3966Var;
                class_1309 class_1309VarMethod_17782 = hit.method_17782() instanceof class_1309 ? (class_1309) hit.method_17782() : null;
                if (class_1309VarMethod_17782 instanceof class_1657) {
                    class_1309 class_1309Var3 = (class_1657) class_1309VarMethod_17782;
                    if (class_1309Var3 != Interface.aM_.field_1724) {
                        class_1309Var = class_1309Var3;
                    } else {
                        class_1309Var = null;
                    }
                } else {
                    class_1309Var = null;
                }
            } else {
                class_1309Var = null;
            }
        } else {
            class_1309Var = null;
        }
        class_1309 crosshair = class_1309Var;
        if (targets != null) {
            class_1309Var2 = targets;
        } else if (crosshair != null) {
            class_1309Var2 = crosshair;
        } else {
            class_1309Var2 = Interface.aM_.field_1755 instanceof class_408 ? Interface.aM_.field_1724 : null;
        }
        class_1309 target = class_1309Var2;
        boolean visible = target != null;
        if (target != null) {
            this.j = target;
        }
        d().a(visible);
        if (!visible && d().a() <= 0.0f) {
            this.j = null;
        }
        super.a(event);
    }
}
