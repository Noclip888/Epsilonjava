package aethereal.ui.widget;

import aethereal.staff.StaffConstructor;
import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.MathUtil;
import net.minecraft.class_408;
import net.minecraft.class_640;
import aethereal.config.ThemeInfo;
import aethereal.core.GlobalEvent;
import aethereal.core.Interface;
import aethereal.event.DrawEvent;
import aethereal.render.AnimationUtil;
import aethereal.ui.element.DragInfo;
import aethereal.ui.widget.Widget;

public class StaffWidget extends Widget implements Interface {
    public StaffWidget() {
        super(new DragInfo("Стафф", 0.0f, 0.0f, 0.0f, 0.0f));
        j().a(this);
    }

    @Override
    public void a(DrawEvent event) {
        d().a(0.0f, 1.0f, 0.3f, EasingList.g, event.g());
        float x = j().a();
        float y = j().b();
        float targetWidth = 14.5f + Fonts.e.a("Staff-list", this.e) + 5.0f + 2.0f;
        float contentY = y + this.d + 3.0f;
        boolean active = false;
        for (StaffConstructor staff : Delta.h().d().f().a()) {
            if (staff.b().c() > 0.0f) {
                targetWidth = Math.max(targetWidth, 19.0f + Fonts.e.a(staff.a(), 6.5f) + 8.0f + Fonts.e.a(a(staff.a()) ? "Near" : "Online", 6.5f) + 5.0f + 2.0f);
                active = true;
            }
        }
        float width = MathUtil.c(j().f(), targetWidth, 0.5f);
        j().c(width);
        if (a() > 0.0f) {
            a(event, "i", "Staff-list", width, a());
        }
        for (StaffConstructor staff2 : Delta.h().d().f().a()) {
            AnimationUtil animationUtil = staff2.b();
            animationUtil.a(0.0f, 1.0f, 0.3f, EasingList.g, event.g());
            float animation = animationUtil.c() * a();
            if (animation > 0.0f) {
                float offsetX = (-8.0f) * (1.0f - animation);
                float offsetY = -(1.0f - animation);
                float drawY = contentY + offsetY;
                float textY = (drawY + ((11.5f - Fonts.e.a(6.5f)) / 2.0f)) - 0.5f;
                a(event, x + offsetX, drawY, width, 11.5f, false, animation);
                a(event, x + offsetX + 15.0f, drawY, 11.5f, animation);
                class_640 entry = aM_.method_1562() == null ? null : (class_640) aM_.method_1562().method_2880().stream().filter(e -> {
                    return e.method_2966().getName().equalsIgnoreCase(staff2.a());
                }).findFirst().orElse(null);
                if (entry != null) {
                    event.d().a(event.h(), x + offsetX + 5.0f, drawY + 2.0f, 7.5f, 7.5f, 2.0f, ColorUtil.a(-1, animation), 0.125f, 0.125f, 0.125f, 0.125f, aM_.method_1531().method_4619(entry.method_52810().comp_1626()).method_4624());
                } else {
                    Fonts.a.a(event.h(), "y", x + offsetX + 5.0f, drawY + ((11.5f - Fonts.a.a(8.0f)) / 2.0f), 8.0f, ColorUtil.a(Delta.h().d().o().a(ThemeInfo.PRIMARY).a(), animation));
                }
                Fonts.e.a(event.h(), staff2.a(), x + offsetX + 19.0f, textY, 6.5f, ColorUtil.a(-1, animation));
                boolean near = a(staff2.a());
                Fonts.e.a(event.h(), near ? "Near" : "Online", ((((x + offsetX) + width) - 5.0f) - Fonts.e.a(near ? "Near" : "Online", 6.5f)) - 1.0f, textY, 6.5f, ColorUtil.a(near ? -1529792 : -9711765, animation));
                contentY += 13.5f * animation;
            }
        }
        j().d(active ? (contentY - y) - 2.0f : this.d);
        super.a(event);
    }

    @Override
    public void a(GlobalEvent event) {
        boolean visible = aM_.field_1755 instanceof class_408;
        for (StaffConstructor staff : Delta.h().d().f().a()) {
            staff.b().a((aM_.method_1562() != null && aM_.method_1562().method_2880().stream().anyMatch(e -> {
                return e.method_2966().getName().equalsIgnoreCase(staff.a());
            })) || a(staff.a()));
            if (staff.b().c() > 0.0f) {
                visible = true;
            }
        }
        d().a(visible);
        super.a(event);
    }

    private boolean a(String name) {
        return aM_.field_1687 != null && aM_.field_1687.method_18456().stream().anyMatch(playerEntity -> {
            return playerEntity.method_5477().getString().equalsIgnoreCase(name);
        });
    }
}
