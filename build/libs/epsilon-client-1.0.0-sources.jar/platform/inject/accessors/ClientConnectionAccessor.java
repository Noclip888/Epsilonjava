package platform.inject.accessors;


import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import net.minecraft.class_7648;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_2535.class})
public interface ClientConnectionAccessor {
    @Invoker("sendImmediately")
    void sendWithoutEvent(class_2596<?> class_2596Var, class_7648 class_7648Var, boolean z);

    @Accessor("packetListener")
    void setPacketListener(class_2547 class_2547Var);
}
