package platform.inject.accessors;


import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_1297.class})
public interface EntityInvoker {
    @Invoker("unsetRemoved")
    void unset();

    @Invoker("baseTick")
    void baseTickInvoker();
}
