package platform.inject.accessors;


import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_746.class})
public interface ClientPlayerEntityAccessor {
    @Accessor("lastYaw")
    float getLastYaw();

    @Accessor("lastPitch")
    float getLastPitch();

    @Accessor("lastSprinting")
    void setWasSprinting(boolean z);

    @Accessor("lastSprinting")
    boolean getWasSprinting();
}
