package platform.inject.accessors;


import java.util.List;
import net.minecraft.class_303;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_338.class})
public interface ChatHudAccessor {
    @Accessor("messages")
    List<class_303> getMessages();

    @Accessor("visibleMessages")
    List<class_303.class_7590> getVisibleMessages();
}
