package platform.inject.accessors;


import net.minecraft.class_10444;
import net.minecraft.class_332;
import net.minecraft.class_4597;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_332.class})
public interface DrawContextAccessor {
    @Accessor("vertexConsumers")
    class_4597.class_4598 getVertexConsumers();

    @Accessor("itemRenderState")
    class_10444 getItemRenderState();
}
