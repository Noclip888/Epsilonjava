package platform.inject.accessors;


import net.minecraft.class_4185;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_4185.class})
public interface ButtonWidgetAccessor {
    @Accessor("onPress")
    class_4185.class_4241 getOnPress();

    @Accessor("onPress")
    @Mutable
    void setOnPress(class_4185.class_4241 class_4241Var);
}
