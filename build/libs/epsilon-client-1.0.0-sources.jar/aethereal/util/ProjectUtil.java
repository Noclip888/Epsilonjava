package aethereal.util;

import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;

import aethereal.core.Interface;

import lombok.Generated;
import net.minecraft.class_238;
import platform.inject.invokers.GameRendererInvoker;
import org.joml.Quaternionf;
import org.joml.Vector2f;
import org.joml.Vector3f;

public class ProjectUtil implements Interface {
    @Generated
    private ProjectUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static Vector2f a(double x, double y, double z) {
        net.minecraft.class_4184 camera = aM_.method_1561().field_4686;
        Vector3f result3f = new Vector3f((float) (x - camera.method_19326().field_1352), (float) (y - camera.method_19326().field_1351), (float) (z - camera.method_19326().field_1350));
        
        Quaternionf invCamRot = new Quaternionf(camera.method_23767()).conjugate();
        result3f.rotate(invCamRot);
        
        return a(result3f, ((GameRendererInvoker) (Object) aM_.field_1773).invokeGetFov(camera, aM_.method_61966().method_60637(false), true));
    }

    private static Vector2f a(Vector3f result3f, double fov) {
        if (result3f.z >= 0.0f) {
            return new Vector2f(Float.MAX_VALUE, Float.MAX_VALUE);
        }
        float realAspect = (float) aM_.method_22683().method_4489() / (float) aM_.method_22683().method_4506();
        float modifiedAspect = Epsilon.h().d().t().aB().m() ? Epsilon.h().d().t().aB().q() : realAspect;
        
        double halfHeightAtDepth = (-result3f.z) * Math.tan(Math.toRadians(fov / 2.0d));
        double halfWidthAtDepth = halfHeightAtDepth * ((double) modifiedAspect);
        
        double ndcX = result3f.x / halfWidthAtDepth;
        double ndcY = result3f.y / halfHeightAtDepth;
        
        float screenX = (float) (aM_.method_22683().method_4486() / 2.0f + ndcX * (aM_.method_22683().method_4486() / 2.0f));
        float screenY = (float) (aM_.method_22683().method_4502() / 2.0f - ndcY * (aM_.method_22683().method_4502() / 2.0f));
        
        return new Vector2f(screenX, screenY);
    }

    public static float[] a(class_238 box) {
        float minX = Float.MAX_VALUE;
        float minY = Float.MAX_VALUE;
        float maxX = -3.4028235E38f;
        float maxY = -3.4028235E38f;
        for (int corner = 0; corner < 8; corner++) {
            double x = (corner & 1) == 0 ? box.field_1323 : box.field_1320;
            double y = (corner & 2) == 0 ? box.field_1322 : box.field_1325;
            double z = (corner & 4) == 0 ? box.field_1321 : box.field_1324;
            Vector2f screen = a(x, y, z);
            if (screen.x() != Float.MAX_VALUE) {
                minX = Math.min(minX, screen.x());
                minY = Math.min(minY, screen.y());
                maxX = Math.max(maxX, screen.x());
                maxY = Math.max(maxY, screen.y());
            }
        }
        if (maxX <= minX || maxY <= minY) {
            return null;
        }
        return new float[]{minX, minY, maxX, maxY};
    }

    public static boolean a(Vector2f screen) {
        return screen.x() != Float.MAX_VALUE && screen.y() != Float.MAX_VALUE && screen.x() >= 0.0f && screen.y() >= 0.0f && screen.x() <= ((float) aM_.method_22683().method_4486()) && screen.y() <= ((float) aM_.method_22683().method_4502());
    }
}
