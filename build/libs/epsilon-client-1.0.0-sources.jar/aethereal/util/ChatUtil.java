package aethereal.util;

import aethereal.ui.shader.GradientUtil;
import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;
import aethereal.render.ColorUtil;

import aethereal.config.ThemeInfo;
import aethereal.core.Interface;

import lombok.Generated;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_5250;

public class ChatUtil implements Interface {
    @Generated
    private ChatUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static void a(Object message) {
        a("[Epsilon 1.21.4]", message);
    }

    public static void a(String prefix, Object message) {
        class_5250 class_5250VarB;
        if (aM_.field_1724 != null) {
            if (prefix == null || prefix.isEmpty()) {
                class_5250VarB = b(message);
            } else {
                class_5250VarB = a(prefix).method_27661().method_10852(class_2561.method_43470("")).method_10852(b(message));
            }
            aM_.field_1724.method_7353(class_5250VarB, false);
        }
    }

    public static class_5250 b(Object message) {
        if (message instanceof class_5250) {
            class_5250 mutableText = (class_5250) message;
            return mutableText;
        }
        if (message instanceof class_2561) {
            class_2561 text = (class_2561) message;
            return text.method_27661();
        }
        return class_2561.method_43470(("&7" + String.valueOf(message)).replace('&', (char) 167));
    }

    public static class_5250 a(Object message, class_2561 hover) {
        String strValueOf;
        if (message instanceof class_2561) {
            class_2561 text = (class_2561) message;
            strValueOf = text.getString();
        } else {
            strValueOf = String.valueOf(message);
        }
        String rawMessage = strValueOf;
        return class_2561.method_43470(rawMessage.replace('&', (char) 167)).method_10862(class_2583.field_24360.method_10949(new class_2568(class_2568.class_5247.field_24342, hover.method_27661())));
    }

    private static class_5250 a(String prefix) {
        int primary = Epsilon.h().d().o().a(ThemeInfo.PRIMARY).a();
        return GradientUtil.a(prefix + " » ", primary, ColorUtil.b(primary, 0.5f), 1, 5.0f);
    }
}
