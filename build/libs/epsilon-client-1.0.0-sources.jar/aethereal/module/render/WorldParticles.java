package aethereal.module.render;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.core.Module;
import aethereal.core.ModuleRegister;
import aethereal.event.BlockChangeEvent;
import aethereal.setting.SliderSetting;
import net.minecraft.class_2246;
import net.minecraft.class_2398;

@ModuleRegister(a = "World Particles", b = "Добавляет искры при изменении и разрушении блоков", c = Category.Render)
public class WorldParticles extends Module implements Interface {
    private final SliderSetting amount = new SliderSetting("Количество частиц", 7.0f, 1.0f, 16.0f, 1.0f);

    public WorldParticles() {
        a(this.amount);
    }

    @EventTarget
    public void onBlockChange(BlockChangeEvent event) {
        if (aM_.field_1687 == null || aM_.field_1724 == null || !event.d().method_26215() || event.c().method_26215()) return;
        if (aM_.field_1724.method_5707(event.b().method_46558()) > 32.0 * 32.0) return;
        var particle = event.c().method_27852(class_2246.field_27099) ? class_2398.field_11240 : class_2398.field_29643;
        for (int i = 0; i < this.amount.c().intValue(); i++) {
            double x = event.b().method_10263() + Math.random();
            double y = event.b().method_10264() + Math.random();
            double z = event.b().method_10260() + Math.random();
            aM_.field_1687.method_8406(particle, x, y, z, (Math.random() - 0.5) * 0.04, Math.random() * 0.05, (Math.random() - 0.5) * 0.04);
        }
    }
}
