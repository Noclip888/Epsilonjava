package aethereal.module.render;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.Epsilon;
import aethereal.core.Interface;
import aethereal.core.Module;
import aethereal.core.ModuleRegister;
import aethereal.event.DrawEvent;
import aethereal.event.TickEvent;
import aethereal.config.ThemeInfo;
import aethereal.setting.SliderSetting;
import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.class_243;

@ModuleRegister(a = "Trails", b = "Оставляет плавный цветной след за движением игрока", c = Category.Render)
public class Trails extends Module implements Interface {
    private final SliderSetting length = new SliderSetting("Длина следа", 32.0f, 8.0f, 96.0f, 1.0f);
    private final Deque<class_243> points = new ArrayDeque<>();

    public Trails() {
        a(this.length);
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (aM_.field_1724 == null || aM_.field_1687 == null) return;
        class_243 pos = aM_.field_1724.method_19538().method_1031(0.0, 0.08, 0.0);
        if (this.points.isEmpty() || this.points.getLast().method_1025(pos) > 0.0025) this.points.addLast(pos);
        while (this.points.size() > this.length.c().intValue()) this.points.removeFirst();
    }

    @EventTarget
    public void onRender(DrawEvent event) {
        if (!event.c() || this.points.size() < 2) return;
        class_243 previous = null;
        for (class_243 point : this.points) {
            if (previous != null) {
                class_243 control = previous.method_35590(point, 0.5);
                Epsilon.h().d().j().a(event.h(), previous, point, control, Epsilon.h().d().o().a(ThemeInfo.PRIMARY).a(), 1.4f);
            }
            previous = point;
        }
    }

    @Override
    public void c() {
        super.c();
        this.points.clear();
    }
}
