package aethereal.module.render;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.Module;
import aethereal.core.ModuleRegister;
import aethereal.event.AmbienceEvent;
import aethereal.render.ColorUtil;
import aethereal.setting.ColorSetting;
import aethereal.setting.SliderSetting;
import net.minecraft.class_3532;
import net.minecraft.class_5636;
import net.minecraft.class_6854;

@ModuleRegister(a = "FogAtmosphere", b = "Создаёт настраиваемый цветной туман с плавной дальностью", c = Category.Render)
public class FogAtmosphere extends Module {
    private final ColorSetting fogColor = new ColorSetting("Цвет тумана", ColorUtil.a(135, 154, 190, 210));
    private final SliderSetting start = new SliderSetting("Начало тумана", 8.0f, 0.0f, 32.0f, 1.0f);
    private final SliderSetting density = new SliderSetting("Плотность", 55.0f, 5.0f, 100.0f, 1.0f);

    public FogAtmosphere() {
        a(this.fogColor, this.start, this.density);
    }

    @EventTarget
    public void onFog(AmbienceEvent.b event) {
        if (event.b().method_19334() != class_5636.field_27888) return;
        float view = Math.max(1.0f, event.c());
        float[] rgba = ColorUtil.a(this.fogColor.c().intValue());
        float fogStart = class_3532.method_15363(this.start.c(), 0.0f, view * 0.7f);
        float fogEnd = class_3532.method_15363(fogStart + (view * (this.density.c() / 100.0f)), fogStart + 1.0f, view);
        event.a(fogStart, fogEnd, class_6854.field_36350, rgba[0], rgba[1], rgba[2], rgba[3]);
    }
}
