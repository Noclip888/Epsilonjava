package aethereal.module.render;

import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;
import aethereal.core.Module;
import aethereal.render.ColorUtil;
import aethereal.render.Draw2DProcessor;
import aethereal.util.MathUtil;
import aethereal.util.ProjectUtil;
import aethereal.util.ServerUtil;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import aethereal.config.ThemeInfo;
import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.DrawEvent;

import aethereal.setting.ColorSetting;
import aethereal.setting.ModeSetting;

@ModuleRegister(a = "Entity Box", b = "Отображает боксы вокруг сущностей", c = Category.Render)
public class EntityBox extends Module {
    private final ModeSetting b = new ModeSetting("Тип визуализации", "Квадрат", "Квадрат", "Углы", "Заливка", "Отключен");
    private final ModeSetting c = new ModeSetting("Источник цвета", "Клиентский", "Клиентский", "Статичный");
    private final ModeSetting d = (ModeSetting) new ModeSetting("Бар здоровья", "Отключен", "Отключен", "Стандартный").a(() -> {
        return Boolean.valueOf(this.b.l("Квадрат") || this.b.l("Углы"));
    });
    private final ColorSetting e = (ColorSetting) new ColorSetting("Цвет визуализации", Integer.valueOf(ColorUtil.a(255, 255, 255, 255))).a(() -> {
        return Boolean.valueOf(this.c.l("Статичный"));
    });

    public EntityBox() {
        a(this.b, this.c, this.d, this.e);
    }

    @EventTarget
    public void a(DrawEvent event) {
        if (this.b.l("Заливка")) {
            if (event.c()) {
                for (class_1297 entity : aM_.field_1687.method_18112()) {
                    if (a(entity)) {
                        event.e().a(event.h(), entity.method_5829().method_997(MathUtil.a(entity, event.g()).method_1020(entity.method_19538())), this.c.l("Статичный") ? this.e.c().intValue() : Epsilon.h().d().o().a(ThemeInfo.PRIMARY).a(), 0.75f);
                    }
                }
                return;
            }
            return;
        }
        if (event.b()) {
            if (this.b.l("Квадрат") || this.b.l("Углы")) {
                Draw2DProcessor draw = event.d();
                for (class_1297 entity : aM_.field_1687.method_18112()) {
                    class_238 box = a(entity) ? entity.method_5829().method_997(MathUtil.a(entity, event.g()).method_1020(entity.method_19538())) : null;
                    float[] bounds = box == null ? null : ProjectUtil.a(box);
                    if (bounds != null) {
                        class_1309 living = entity instanceof class_1309 ? (class_1309) entity : null;
                        boolean healthBar = !this.d.l("Отключен") && living != null;
                        float percent = healthBar ? Math.min(Math.max(0.0f, ServerUtil.a.a(living)) / Math.max(1.0f, living.method_6063()), 1.0f) : 0.0f;
                        int healthColor = ColorUtil.b(ColorUtil.a(255, 0, 0, 255), ColorUtil.a(0, 255, 0, 255), percent);
                        int color = this.c.l("Статичный") ? this.e.c().intValue() : ColorUtil.a(Epsilon.h().d().o().a(ThemeInfo.PRIMARY).a(), 255);
                        a(draw, event, bounds[0], bounds[1], bounds[2], bounds[3], color, this.b.l("Углы"), healthBar, percent, healthColor);
                    }
                }
            }
        }
    }

    private void a(Draw2DProcessor draw, DrawEvent event, float minX, float minY, float maxX, float maxY, int color, boolean corners, boolean healthBar, float healthPercent, int healthColor) {
        float width = maxX - minX;
        float height = maxY - minY;
        if (width <= 0.0f || height <= 0.0f) {
            return;
        }
        float line = 0.75f;
        float outline = 1.75f;
        int outlineColor = ColorUtil.a(0, 0, 0, 255);
        if (corners) {
            float length = Math.min(width, height) * 0.25f;
            a(draw, event, minX, minY, length, 0.0f, line, outline, color, outlineColor);
            a(draw, event, minX, minY, 0.0f, length, line, outline, color, outlineColor);
            a(draw, event, maxX, minY, -length, 0.0f, line, outline, color, outlineColor);
            a(draw, event, maxX, minY, 0.0f, length, line, outline, color, outlineColor);
            a(draw, event, minX, maxY, length, 0.0f, line, outline, color, outlineColor);
            a(draw, event, minX, maxY, 0.0f, -length, line, outline, color, outlineColor);
            a(draw, event, maxX, maxY, -length, 0.0f, line, outline, color, outlineColor);
            a(draw, event, maxX, maxY, 0.0f, -length, line, outline, color, outlineColor);
        } else {
            a(draw, event, minX, minY, width, 0.0f, line, outline, color, outlineColor);
            a(draw, event, minX, maxY, width, 0.0f, line, outline, color, outlineColor);
            a(draw, event, minX, minY, 0.0f, height, line, outline, color, outlineColor);
            a(draw, event, maxX, minY, 0.0f, height, line, outline, color, outlineColor);
        }
        if (healthBar) {
            float barX = minX - 3.0f;
            draw.a(event.h(), barX - 0.5f, minY - 0.5f, 1.75f, height + 1.0f, 0.0f, outlineColor);
            draw.a(event.h(), barX, minY + (height * (1.0f - healthPercent)), 0.75f, height * healthPercent, 0.0f, healthColor);
        }
    }

    private void a(Draw2DProcessor draw, DrawEvent event, float x, float y, float lengthX, float lengthY, float line, float outline, int color, int outlineColor) {
        float left = Math.min(x, x + lengthX);
        float top = Math.min(y, y + lengthY);
        float width = lengthX == 0.0f ? line : Math.abs(lengthX);
        float height = lengthY == 0.0f ? line : Math.abs(lengthY);
        if (lengthX == 0.0f) {
            left -= line * 0.5f;
        }
        if (lengthY == 0.0f) {
            top -= line * 0.5f;
        }
        float outlineOffset = (outline - line) * 0.5f;
        draw.a(event.h(), left - outlineOffset, top - outlineOffset, width + (outlineOffset * 2.0f), height + (outlineOffset * 2.0f), 0.0f, outlineColor);
        draw.a(event.h(), left, top, width, height, 0.0f, color);
    }

    private boolean a(class_1297 entity) {
        if ((entity instanceof class_1657) || (entity instanceof class_1542)) {
            return (entity == aM_.field_1724 && aM_.field_1690.method_31044().method_31034()) ? false : true;
        }
        return false;
    }
}
