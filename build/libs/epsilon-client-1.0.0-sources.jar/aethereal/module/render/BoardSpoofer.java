package aethereal.module.render;

import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.ScoreboardEvent;
import aethereal.setting.BooleanSetting;

import aethereal.setting.ModeSetting;
import aethereal.setting.MultiModeSetting;
import aethereal.setting.StringSetting;
import java.util.Locale;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;

@ModuleRegister(a = "Board Spoofer", b = "Подменяет значения доната, монет и токенов в Scoreboard", c = Category.Render)
public class BoardSpoofer extends Module {
    private final MultiModeSetting b = new MultiModeSetting("Элементы настройки", new BooleanSetting("Ранг", true), new BooleanSetting("Монеты", true), new BooleanSetting("Токены", true));
    private final ModeSetting c = (ModeSetting) new ModeSetting("Выберите привилегию", "Игрок", "Игрок", "Барон", "Страж", "Герой", "Аспид", "Сквид", "Глава", "Элита", "Титан", "Принц", "Князь", "Герцог").a(() -> {
        return this.b.a("Ранг").c();
    });
    private final StringSetting d = (StringSetting) new StringSetting("Число монет", "", true).a(() -> {
        return this.b.a("Монеты").c();
    });
    private final StringSetting e = (StringSetting) new StringSetting("Число токенов", "", true).a(() -> {
        return this.b.a("Токены").c();
    });

    public BoardSpoofer() {
        a(this.b, this.c, this.d, this.e);
    }

    @EventTarget
    public void a(ScoreboardEvent event) {
        class_2561 title = event.b();
        if (this.b.a("Ранг").c().booleanValue()) {
            title = a(title, "Ранг: ", this.c.c());
        }
        if (this.b.a("Монеты").c().booleanValue()) {
            class_2561 class_2561Var = title;
            Locale locale = Locale.US;
            Object[] objArr = new Object[1];
            objArr[0] = Long.valueOf(Long.parseLong(this.d.c().isEmpty() ? "0" : this.d.c()));
            title = a(class_2561Var, "Монет: ", String.format(locale, "%,d", objArr));
        }
        if (this.b.a("Токены").c().booleanValue()) {
            title = a(title, "Токенов: ", this.e.c().isEmpty() ? "0" : this.e.c());
        }
        event.a(title);
    }

    private class_2561 a(class_2561 text, String label, String newValue) {
        class_5250 rebuilt = class_2561.method_43473();
        StringBuilder seen = new StringBuilder();
        text.method_27658((style, part) -> {
            int previousLength = seen.length();
            seen.append(part);
            int labelIndex = seen.indexOf(label);
            if (labelIndex == -1 || labelIndex + label.length() <= previousLength) {
                rebuilt.method_10852(class_2561.method_43470(part).method_10862(style));
                return Optional.empty();
            }
            rebuilt.method_10852(class_2561.method_43470(part.substring(0, (labelIndex + label.length()) - previousLength)).method_10862(style));
            rebuilt.method_10852(class_2561.method_43470(newValue).method_10862("Ранг: ".equals(label) ? a(newValue) : style));
            return Optional.of(true);
        }, class_2583.field_24360);
        return rebuilt.method_10855().isEmpty() ? text : rebuilt;
    }

    private class_2583 a(String rank) {
        switch (rank) {
            case "Страж":
                return class_2583.field_24360.method_27706(class_124.field_1054);
            case "Барон":
            case "Сквид":
                return class_2583.field_24360.method_27706(class_124.field_1075);
            case "Герой":
                return class_2583.field_24360.method_27706(class_124.field_1060);
            case "Аспид":
                return class_2583.field_24360.method_27706(class_124.field_1062);
            case "Глава":
            case "Титан":
                return class_2583.field_24360.method_27706(class_124.field_1065);
            case "Элита":
                return class_2583.field_24360.method_27706(class_124.field_1064);
            case "Принц":
            case "Князь":
                return class_2583.field_24360.method_27706(class_124.field_1061);
            case "Герцог":
                return class_2583.field_24360.method_27706(class_124.field_1079);
            default:
                return class_2583.field_24360.method_27706(class_124.field_1068);
        }
    }
}
