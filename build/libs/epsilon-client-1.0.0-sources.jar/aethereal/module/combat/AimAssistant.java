package aethereal.module.combat;

import aethereal.module.combat.AuraUtil;
import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;
import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.LookEvent;
import aethereal.event.TickEvent;
import aethereal.module.combat.TriggerBot;

import aethereal.setting.BooleanSetting;
import aethereal.setting.MultiModeSetting;
import aethereal.setting.SliderSetting;
import java.util.Comparator;
import java.util.Objects;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import lombok.Generated;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1829;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_9362;

@ModuleRegister(a = "Aim Assistant", b = "Доводит прицел до цели", c = Category.Combat)
public class AimAssistant extends Module {
    private final MultiModeSetting b = new MultiModeSetting("Цели для наведения", new BooleanSetting("Игроки", true), new BooleanSetting("Животные", false), new BooleanSetting("Мобы", false), new BooleanSetting("Друзья", true));
    private final BooleanSetting c = new BooleanSetting("Наводить за стеной", false);
    private final SliderSetting d = new SliderSetting("Порог", 5.0f, 1.0f, 5.0f, 0.25f);
    private final BooleanSetting e = new BooleanSetting("Только с оружием", true);
    private class_1309 f;
    private class_243 g;

    @Generated
    public class_1309 q() {
        return this.f;
    }

    public AimAssistant() {
        a(this.b, this.c, this.d, this.e);
    }

    @Override
    public void c() {
        super.c();
        this.f = null;
    }

    @EventTarget
    public void a(TickEvent event) {
        TriggerBot trigger = Epsilon.h().d().t().X();
        class_1309 found = trigger.m() ? trigger.s() : r();
        if (found != this.f) {
            this.g = null;
        }
        this.f = found;
    }

    @EventTarget
    public void a(LookEvent event) {
        if (!a(this.f) || aM_.field_1724.method_6115()) {
            return;
        }
        if (!this.e.c().booleanValue() || s()) {
            class_243 position = AuraUtil.a(aM_.field_1724.method_33571(), this.f, 3.0d, this.c.c().booleanValue());
            if (position == class_243.field_1353) {
                return;
            }
            this.g = this.g == null ? position : this.g.method_35590(position, 0.2000000448441151d);
            float yaw = (float) class_3532.method_15338(Math.toDegrees(Math.atan2(this.g.field_1350, this.g.field_1352)) - 90.0d);
            float pitch = (float) (-Math.toDegrees(Math.atan2(this.g.field_1351, Math.hypot(this.g.field_1352, this.g.field_1350))));
            float deltaYaw = class_3532.method_15393(yaw - aM_.field_1724.method_36454());
            float deltaPitch = pitch - aM_.field_1724.method_36455();
            if (Math.abs(deltaPitch) <= 13.0f && Math.abs(deltaYaw) < 8.0f && AuraUtil.a(aM_.field_1724.method_36454(), aM_.field_1724.method_36455(), 3.0d, this.f, this.c.c().booleanValue())) {
                deltaPitch = 0.0f;
            }
            float frame = aM_.method_61966().method_60636();
            float ease = class_3532.method_15363(((float) Math.hypot(deltaYaw, deltaPitch)) / 4.0f, 0.0f, 1.0f);
            float speed = this.d.c().floatValue() * frame * ease;
            if (speed <= 0.0f) {
                return;
            }
            float step = Math.min(1.0f, speed / Math.max(Math.abs(deltaYaw), Math.abs(deltaPitch) * 2.0f));
            aM_.field_1724.method_36456(aM_.field_1724.method_36454() + (deltaYaw * step));
            if (deltaPitch != 0.0f) {
                aM_.field_1724.method_36457(class_3532.method_15363(aM_.field_1724.method_36455() + (deltaPitch * step), -90.0f, 90.0f));
            }
        }
    }

    private class_1309 r() {
        class_243 eye = aM_.field_1724.method_33571();
        class_243 look = class_243.method_1030(aM_.field_1724.method_36455(), aM_.field_1724.method_36454());
        return StreamSupport.stream(aM_.field_1687.method_18112().spliterator(), false)
                .filter(class_1309.class::isInstance)
                .map(class_1309.class::cast)
                .filter(entity -> a(entity) && (this.c.c().booleanValue() || AuraUtil.a(eye, entity, 4.0d)))
                .min(Comparator.comparingDouble(entity2 ->
                        Math.acos(class_3532.method_15350(look.method_1026(entity2.method_5829().method_1005().method_1020(eye).method_1029()), -1.0d, 1.0d))))
                .orElse(null);
    }

    private boolean s() {
        class_1792 item = aM_.field_1724.method_6047().method_7909();
        return (item instanceof class_1829) || (item instanceof class_1743) || (item instanceof class_9362);
    }

    private boolean a(class_1309 entity) {
        return entity != null && entity.method_5805() && !entity.method_31481() && entity != aM_.field_1724 && AuraUtil.a((class_1297) entity, 4.0d + (aM_.field_1724.method_18798().method_1033() * 3.0d)) && b(entity);
    }

    private boolean b(class_1309 entity) {
        if (entity instanceof class_1657) {
            class_1657 player = (class_1657) entity;
            return this.b.a("Игроки").c().booleanValue() && (this.b.a("Друзья").c().booleanValue() || !Epsilon.h().d().e().d(player.method_5477().getString()));
        }
        if (entity instanceof class_1308) {
            return this.b.a("Мобы").c().booleanValue();
        }
        return (entity instanceof class_1429) && this.b.a("Животные").c().booleanValue();
    }
}
