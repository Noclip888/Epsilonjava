package aethereal.module.combat;

import aethereal.core.Interface;

import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.PacketEvent;
import aethereal.util.ServerUtil;
import net.minecraft.class_2708;

@ModuleRegister(a = "No Server Desync", b = "Не даёт серверу принудительно сбрасывать поворот вашей камеры", c = Category.Combat)
public class NoServerDesync extends Module {
    private static final String[] b = {"funtime.su", "funtime.sh"};

    @EventTarget
    public void a(PacketEvent event) {
        if (ServerUtil.isServerDomain(b)) {
            return;
        }
        if (event.c() && event.d() instanceof class_2708 packet) {
            if (packet.comp_3228().comp_3151() != 0.0f && packet.comp_3228().comp_3150() != 0.0f) {
                event.a(true);
            }
        }
    }
}
