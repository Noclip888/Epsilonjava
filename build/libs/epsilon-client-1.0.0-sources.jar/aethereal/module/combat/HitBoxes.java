package aethereal.module.combat;

import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;
import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.BoundingBoxEvent;

import aethereal.setting.SliderSetting;
import net.minecraft.class_1657;
import net.minecraft.class_238;

@ModuleRegister(a = "Hit Boxes", b = "Увеличивает хитбокс игроков, упрощая попадания по ним", c = Category.Combat)
public class HitBoxes extends Module {
    private final SliderSetting b = new SliderSetting("Расширение X и Z", 0.0f, 0.0f, 1.0f, 0.1f);
    private final SliderSetting c = new SliderSetting("Расширение Y", 0.0f, 0.0f, 1.0f, 0.1f);

    public HitBoxes() {
        a(this.b, this.c);
    }

    @EventTarget
    public void a(BoundingBoxEvent event) {
        class_1657 class_1657VarC = (class_1657) event.c();
        if (class_1657VarC instanceof class_1657) {
            class_1657 player = class_1657VarC;
            class_238 box = event.b();
            class_238 changedBox = new class_238(box.field_1323 - ((double) (this.b.h().floatValue() / 2.0f)), box.field_1322, box.field_1321 - ((double) (this.b.h().floatValue() / 2.0f)), box.field_1320 + ((double) (this.b.h().floatValue() / 2.0f)), box.field_1325 + ((double) this.c.h().floatValue()), box.field_1324 + ((double) (this.b.h().floatValue() / 2.0f)));
            if (player.method_5628() != aM_.field_1724.method_5628() && !Epsilon.h().d().e().d(player.method_5477().getString())) {
                event.a(changedBox);
            }
        }
    }
}
