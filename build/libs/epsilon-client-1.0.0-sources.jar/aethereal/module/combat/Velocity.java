package aethereal.module.combat;

import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Module;
import aethereal.util.Look;
import net.minecraft.class_1282;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2743;
import net.minecraft.class_3532;
import net.minecraft.class_8143;
import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.InputEvent;
import aethereal.event.PacketEvent;

import aethereal.setting.BooleanSetting;
import aethereal.setting.ModeSetting;

@ModuleRegister(a = "Velocity", b = "Не позволяет игрокам откидывать вас", c = Category.Combat)
public class Velocity extends Module {
    private final ModeSetting b = new ModeSetting("Режим анти-отбрасывания", "Легитный", "Обычный", "Легитный");
    private final BooleanSetting c = (BooleanSetting) new BooleanSetting("Прыгать в легит", true).a(() -> {
        return Boolean.valueOf(this.b.l("Легитный"));
    });
    private final BooleanSetting d = (BooleanSetting) new BooleanSetting("Легитный", true).a(() -> {
        return Boolean.valueOf(this.b.l("Легитный"));
    });
    private class_243 e = class_243.field_1353;
    private int f;

    public Velocity() {
        a(this.b, this.c, this.d);
    }

    @Override
    public void c() {
        super.c();
        this.e = class_243.field_1353;
        this.f = 0;
    }

    @EventTarget
    public void a(PacketEvent event) {
        if (!event.c() || aM_.field_1724 == null) {
            return;
        }
        class_8143 class_8143VarD = (class_8143) event.d();
        if (class_8143VarD instanceof class_8143) {
            class_8143 damage = class_8143VarD;
            if (damage.comp_1267() == aM_.field_1724.method_5628()) {
                class_1282 source = damage.method_49071(aM_.field_1687);
                boolean player = source.method_5529() instanceof class_1657;
                this.f = player ? aM_.field_1724.field_6012 : 0;
                if (!player) {
                    this.e = class_243.field_1353;
                }
            }
        }
        class_2743 class_2743VarD = (class_2743) event.d();
        if (class_2743VarD instanceof class_2743) {
            class_2743 packet = class_2743VarD;
            if (packet.method_11818() == aM_.field_1724.method_5628()) {
                if (!this.b.l("Обычный")) {
                    this.e = new class_243(packet.method_11815(), 0.0d, packet.method_11819());
                } else {
                    event.a(true);
                }
            }
        }
    }

    @EventTarget
    public void a(InputEvent event) {
        float f;
        float f2;
        if (aM_.field_1724.field_6235 <= 0) {
            this.e = class_243.field_1353;
            return;
        }
        if (!this.b.l("Легитный") || this.e.method_1027() == 0.0d || aM_.field_1724.field_6012 - this.f > 10) {
            return;
        }
        double angle = class_3532.method_15338((Math.toDegrees(Math.atan2(-this.e.field_1350, -this.e.field_1352)) - 90.0d) - ((double) Look.b()));
        if (this.d.c().booleanValue() && aM_.field_1690.field_1894.method_1434() && Math.abs(angle) >= 140.0d) {
            return;
        }
        if (angle <= -45.0d || angle >= 45.0d) {
            f = (angle > 135.0d || angle < -135.0d) ? -1.0f : 0.0f;
        } else {
            f = 1.0f;
        }
        event.a(f);
        if (angle < 45.0d || angle > 135.0d) {
            f2 = (angle > -45.0d || angle < -135.0d) ? 0.0f : 1.0f;
        } else {
            f2 = -1.0f;
        }
        event.b(f2);
        event.b(this.c.c().booleanValue() && aM_.field_1724.method_24828());
    }
}
