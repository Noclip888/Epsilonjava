package aethereal.module.combat;

import aethereal.handler.UseableHandler;
import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;
import aethereal.core.InterfaceC0020Opcode;
import aethereal.core.Module;
import aethereal.util.InventoryUtil;
import aethereal.util.ServerUtil;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.TickEvent;
import aethereal.module.combat.Aura;
import aethereal.module.combat.TriggerBot;

import aethereal.setting.BooleanSetting;
import java.util.List;
import lombok.Generated;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import platform.inject.accessors.ItemCooldownManagerAccessor;

@ModuleRegister(a = "Mace Helper", b = "Автоматизирует действия при использовании булавы", c = Category.Combat)
public class MaceHelper extends Module {
    public int d;
    public boolean e;
    public BooleanSetting b = new BooleanSetting("Усиление урона", true);
    public BooleanSetting c = new BooleanSetting("Авто-переключение булавы", false);
    int[] f = {-1, -1};

    @Generated
    public BooleanSetting q() {
        return this.b;
    }

    @Generated
    public BooleanSetting r() {
        return this.c;
    }

    @Generated
    public int s() {
        return this.d;
    }

    @Generated
    public boolean t() {
        return this.e;
    }

    @Generated
    public int[] u() {
        return this.f;
    }

    public MaceHelper() {
        a(this.b, this.c);
    }

    @EventTarget
    public void a(TickEvent event) {
        class_243 landing;
        this.d--;
        List<UseableHandler.a> tasks = Epsilon.h().d().v().b().a();
        if ((this.d <= 198 && aM_.field_1724.method_24828()) || aM_.field_1724.method_5799() || aM_.field_1724.field_6012 < 5) {
            if (this.e && tasks.isEmpty()) {
                if (this.f[1] > 8) {
                    Epsilon.h().d().v().a().a(this.f[0], this.f[1], 1);
                } else {
                    aM_.field_1724.method_31548().field_7545 = this.f[0];
                }
                this.e = false;
                this.f = new int[]{-1, -1};
            }
            this.d = 0;
        }
        if (!tasks.isEmpty() && ((UseableHandler.a) tasks.getFirst()).a().method_7909() == class_1802.field_49098) {
            this.d = InterfaceC0020Opcode.aN;
        }
        int hotbar = InventoryUtil.a(class_1802.field_49814, true);
        int slotMace = InventoryUtil.a(class_1802.field_49814, false);
        if (!this.c.c().booleanValue() || slotMace == -1) {
            return;
        }
        if (!ServerUtil.a.a() || ServerUtil.e()) {
            ItemCooldownManagerAccessor cooldowns = (ItemCooldownManagerAccessor) (ItemCooldownManagerAccessor) aM_.field_1724.method_7357();
            Object entry = cooldowns.getEntries().get(aM_.field_1724.method_7357().method_62836(class_1802.field_49814.method_7854()));
            if (entry == null || ((platform.inject.accessors.ItemCooldownEntryAccessor) entry).getEndTick() - cooldowns.getTick() <= 10) {
                Aura aura = Epsilon.h().d().t().B();
                TriggerBot triggerBot = Epsilon.h().d().t().X();
                boolean fromAura = aura.s() != null;
                class_1309 target = fromAura ? aura.s() : triggerBot.s();
                if (target == null || target.method_6039() || aM_.field_1724.method_24828() || MaceUtil.a() || this.e || aM_.field_1724.field_6017 <= 0.0f || !tasks.isEmpty() || !Epsilon.h().d().v().a().a().isEmpty() || Math.hypot(target.method_19538().field_1352 - aM_.field_1724.method_19538().field_1352, target.method_19538().field_1350 - aM_.field_1724.method_19538().field_1350) > 6.0d) {
                    return;
                }
                if ((fromAura ? aura.b : triggerBot.d) <= 1 || (landing = MaceUtil.a(aM_.field_1724, (class_1937) aM_.field_1687).orElse(null)) == null || aM_.field_1724.method_23318() + aM_.field_1724.method_18798().field_1351 <= landing.method_10214() || aM_.field_1724.method_23318() - landing.method_10214() <= 3.5d) {
                    return;
                }
                this.e = true;
                int[] iArr = new int[2];
                iArr[0] = aM_.field_1724.method_31548().field_7545;
                iArr[1] = hotbar != -1 ? hotbar : slotMace;
                this.f = iArr;
                if (hotbar == -1) {
                    Epsilon.h().d().v().a().a(slotMace, aM_.field_1724.method_31548().field_7545, 1);
                } else {
                    aM_.field_1724.method_31548().field_7545 = hotbar;
                }
            }
        }
    }
}
