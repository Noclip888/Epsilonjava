package aethereal.module.player;

import static aethereal.core.Interface.aM_;
import aethereal.core.InterfaceC0020Opcode;
import aethereal.core.Module;
import aethereal.render.ColorUtil;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.core.ModuleRegister;
import aethereal.event.AttackEvent;
import aethereal.event.DrawEvent;
import aethereal.event.PacketEvent;
import aethereal.event.TickEvent;

import aethereal.setting.BooleanSetting;
import aethereal.setting.SliderSetting;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2743;
import net.minecraft.class_2797;
import net.minecraft.class_2813;
import net.minecraft.class_2824;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import platform.inject.accessors.ClientConnectionAccessor;

@ModuleRegister(a = "Fake Lags", b = "Задерживает отправку пакетов, имитируя лаги на сервере", c = Category.Player)
public class FakeLags extends Module implements Interface {
    private final SliderSetting b = new SliderSetting("Задержка симуляции", 20.0f, 1.0f, 40.0f, 1.0f);
    private final BooleanSetting c = new BooleanSetting("Отображать серв-позицию", false);
    private final Queue<class_2596<?>> d = new ConcurrentLinkedQueue();
    private int e;
    private int f;
    private class_243 g;

    public FakeLags() {
        a(this.b, this.c);
    }

    @Override
    public void b() {
        super.b();
        this.d.clear();
        this.e = 0;
        this.f = 0;
        this.g = null;
    }

    @Override
    public void c() {
        super.c();
        q();
        this.g = null;
    }

    @EventTarget
    public void a(AttackEvent event) {
        this.f = 2;
        q();
    }

    @EventTarget
    public void a(PacketEvent event) {
        if (aM_.field_1724 == null) {
            return;
        }
        if (event.c()) {
            class_2743 class_2743VarD = (class_2743) event.d();
            if (class_2743VarD instanceof class_2743) {
                class_2743 velocity = class_2743VarD;
                if (velocity.method_11818() == aM_.field_1724.method_5628()) {
                    q();
                    return;
                }
                return;
            }
            return;
        }
        if (event.b()) {
            if (this.f > 0 || a(event.d())) {
                q();
            } else {
                this.d.offer(event.d());
                event.a(true);
            }
        }
    }

    @EventTarget
    public void a(TickEvent event) {
        if (this.f > 0) {
            this.f--;
        }
        int i = this.e + 1;
        this.e = i;
        if (i >= this.b.c().intValue() && !this.d.isEmpty()) {
            q();
            this.e = 0;
        }
    }

    @EventTarget
    public void a(DrawEvent event) {
        if (event.c() && this.c.c().booleanValue() && this.g != null) {
            event.e().a(event.h(), aM_.field_1724.method_5829().method_997(this.g.method_1020(aM_.field_1724.method_19538())), ColorUtil.a(255, 255, 255, InterfaceC0020Opcode.aN), 0.75f);
        }
    }

    private boolean a(class_2596<?> packet) {
        return (packet instanceof class_2824) || (packet instanceof class_2797) || (packet instanceof class_2868) || (packet instanceof class_2879) || (packet instanceof class_2885) || (packet instanceof class_2886) || (packet instanceof class_2813);
    }

    private void q() {
        ClientConnectionAccessor connection = (ClientConnectionAccessor) aM_.field_1724.field_3944.method_48296();
        this.d.forEach(packet -> {
            connection.sendWithoutEvent(packet, null, true);
        });
        this.d.clear();
        this.g = aM_.field_1724.method_19538();
    }
}
