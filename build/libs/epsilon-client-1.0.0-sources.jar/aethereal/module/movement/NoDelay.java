package aethereal.module.movement;

import aethereal.core.Interface;

import platform.inject.accessors.LivingEntityAccessor;
import platform.inject.accessors.MinecraftClientAccessor;
import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;
import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.TickEvent;
import aethereal.setting.BooleanSetting;

import aethereal.setting.MultiModeSetting;
import net.minecraft.class_1747;

@ModuleRegister(a = "No Delay", b = "Убирает задержку у выбранных действий", c = Category.Movement)
public class NoDelay extends Module {
    public final MultiModeSetting b = new MultiModeSetting("Отключить задержку на", new BooleanSetting("Поставку блоков", true), new BooleanSetting("Прыжки", true));

    public NoDelay() {
        a(this.b);
    }

    @EventTarget
    public void a(TickEvent event) {
        if (this.b.a("Поставку блоков").c().booleanValue() && (aM_.field_1724.method_6047().method_7909() instanceof class_1747) && !Epsilon.h().d().t().aS().m()) {
            ((platform.inject.accessors.MinecraftClientAccessor) (Object) aM_).setItemUseCooldown(0);
        }
        if (this.b.a("Прыжки").c().booleanValue()) {
            ((platform.inject.accessors.LivingEntityAccessor) (Object) aM_.field_1724).setJumpingCooldown(0);
        }
    }
}
