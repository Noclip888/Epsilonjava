package aethereal.module.movement;

import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.TickEvent;

import aethereal.setting.SliderSetting;

@ModuleRegister(a = "Fly", b = "Позволяет свободно летать по миру", c = Category.Movement)
public class Fly extends Module {
    private final SliderSetting b = new SliderSetting("Скорость X и Z", 1.0f, 0.1f, 5.0f, 0.1f);
    private final SliderSetting c = new SliderSetting("Скорость Y", 1.0f, 0.1f, 5.0f, 0.1f);

    public Fly() {
        a(this.b, this.c);
    }

    @EventTarget
    public void a(TickEvent event) {
        q();
    }

    private void q() {
        double dFloatValue;
        float fSignum;
        float yaw = aM_.field_1724.method_36454();
        if (aM_.field_1690.field_1832.method_1434()) {
            dFloatValue = -this.c.c().floatValue();
        } else {
            dFloatValue = aM_.field_1690.field_1903.method_1434() ? this.c.c().floatValue() : 0.0d;
        }
        double motionY = dFloatValue;
        if (aM_.field_1724.field_3913.field_3905 == 0.0f && aM_.field_1724.field_3913.field_3907 == 0.0f) {
            aM_.field_1724.method_18800(0.0d, motionY, 0.0d);
            return;
        }
        if (aM_.field_1724.field_3913.field_3905 != 0.0f) {
            if (aM_.field_1724.field_3913.field_3907 != 0.0f) {
                fSignum = (aM_.field_1724.field_3913.field_3905 > 0.0f ? -45.0f : 45.0f) * Math.signum(aM_.field_1724.field_3913.field_3907);
            } else {
                fSignum = 0.0f;
            }
            yaw += fSignum;
            aM_.field_1724.field_3913.field_3907 = 0.0f;
            aM_.field_1724.field_3913.field_3905 = Math.signum(aM_.field_1724.field_3913.field_3905);
        }
        double radians = Math.toRadians(yaw + 90.0f);
        double speedXZ = this.b.c().floatValue();
        double motionX = (((double) aM_.field_1724.field_3913.field_3905) * speedXZ * Math.cos(radians)) + (((double) aM_.field_1724.field_3913.field_3907) * speedXZ * Math.sin(radians));
        double motionZ = ((((double) aM_.field_1724.field_3913.field_3905) * speedXZ) * Math.sin(radians)) - ((((double) aM_.field_1724.field_3913.field_3907) * speedXZ) * Math.cos(radians));
        aM_.field_1724.method_18800(motionX, motionY, motionZ);
    }
}
