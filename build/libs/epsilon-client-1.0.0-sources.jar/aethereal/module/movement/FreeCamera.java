package aethereal.module.movement;

import static aethereal.core.Interface.aM_;
import aethereal.core.Module;
import aethereal.util.Look;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2848;
import net.minecraft.class_2851;
import net.minecraft.class_3675;
import net.minecraft.class_3959;
import net.minecraft.class_5498;
import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.core.ModuleRegister;
import aethereal.event.CameraPositionEvent;
import aethereal.event.CrosshairTargetEvent;
import aethereal.event.InputEvent;
import aethereal.event.PacketEvent;
import aethereal.event.TickEvent;

import aethereal.setting.BooleanSetting;
import aethereal.setting.SliderSetting;

@ModuleRegister(a = "Free Camera", b = "Позволяет свободно перемещать камеру, пока игрок остаётся на месте", c = Category.Movement)
public class FreeCamera extends Module implements Interface {
    private final SliderSetting b = new SliderSetting("Скорость движения XZ", 1.0f, 0.1f, 5.0f, 0.1f);
    private final SliderSetting c = new SliderSetting("Скорость движения Y", 1.0f, 0.1f, 5.0f, 0.1f);
    private final BooleanSetting d = new BooleanSetting("Замораживать пакеты в полете", true);
    private class_243 e;
    private class_243 f;
    private class_243 g;
    private float h;
    private float i;
    private boolean j;
    private boolean k;

    public FreeCamera() {
        a(this.d, this.b, this.c);
    }

    @Override
    public void b() {
        super.b();
        if (aM_.field_1724 == null) {
            d(true);
            a();
            return;
        }
        this.f = aM_.field_1724.method_33571();
        this.e = aM_.field_1724.method_33571();
        if (this.d.c().booleanValue()) {
            this.g = aM_.field_1724.method_19538();
        }
        d(false);
    }

    @Override
    public void c() {
        super.c();
        d(true);
    }

    @EventTarget
    public void a(CameraPositionEvent event) {
        if (this.e != null && aM_.field_1724.method_5805()) {
            if (aM_.field_1690.method_31044() != class_5498.field_26664) {
                aM_.field_1690.method_31043(class_5498.field_26664);
            }
            class_243 basePrev = this.f != null ? this.f : this.e;
            class_243 interpolated = new class_243(basePrev.field_1352 + ((this.e.field_1352 - basePrev.field_1352) * ((double) aM_.method_61966().method_60637(false))), basePrev.field_1351 + ((this.e.field_1351 - basePrev.field_1351) * ((double) aM_.method_61966().method_60637(false))), basePrev.field_1350 + ((this.e.field_1350 - basePrev.field_1350) * ((double) aM_.method_61966().method_60637(false))));
            event.a(interpolated);
            event.a(true);
        }
    }

    @EventTarget
    public void a(CrosshairTargetEvent event) {
        if (this.e != null && aM_.field_1724.method_5805()) {
            event.a((class_239) aM_.field_1687.method_17742(new class_3959(this.e, this.e.method_1019(aM_.field_1724.method_5828(event.b()).method_1021(aM_.field_1724.method_55754())), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, aM_.field_1724)));
            event.a(true);
        }
    }

    @EventTarget
    public void a(TickEvent eventTick) {
        float f;
        float f2;
        if (this.e != null && aM_.field_1724.method_5805()) {
            if (aM_.field_1755 == null) {
                if (aM_.field_1690.field_1894.method_1434()) {
                    f = 1.0f;
                } else {
                    f = aM_.field_1690.field_1881.method_1434() ? -1.0f : 0.0f;
                }
                this.h = f;
                if (class_3675.method_15987(aM_.method_22683().method_4490(), 65)) {
                    f2 = 1.0f;
                } else {
                    f2 = class_3675.method_15987(aM_.method_22683().method_4490(), 68) ? -1.0f : 0.0f;
                }
                this.i = f2;
                this.j = aM_.field_1690.field_1903.method_1434();
                this.k = aM_.field_1690.field_1832.method_1434();
            } else {
                d(false);
            }
            if (this.d.c().booleanValue() && !aM_.field_1724.method_24828()) {
                aM_.field_1724.method_18800(0.0d, 0.0d, 0.0d);
                if (this.g != null) {
                    aM_.field_1724.method_5814(this.g.field_1352, this.g.field_1351, this.g.field_1350);
                }
            }
            this.f = this.e;
            this.e = this.e.method_1031(((((double) this.h) * (-Math.sin(Math.toRadians(Look.b())))) + (((double) this.i) * Math.cos(Math.toRadians(Look.b())))) * ((double) this.b.c().floatValue()), (this.j ? this.c.c().floatValue() : 0.0d) - (this.k ? this.c.c().floatValue() : 0.0d), ((((double) this.h) * Math.cos(Math.toRadians(Look.b()))) + (((double) this.i) * Math.sin(Math.toRadians(Look.b())))) * ((double) this.b.c().floatValue()));
        }
    }

    @EventTarget
    public void a(InputEvent event) {
        float f;
        float f2;
        if (this.e != null && aM_.field_1724.method_5805()) {
            if (aM_.field_1755 != null) {
                event.a(0.0f);
                event.b(0.0f);
                event.b(false);
                event.c(false);
                return;
            }
            if (class_3675.method_15987(aM_.method_22683().method_4490(), 265)) {
                f = 1.0f;
            } else {
                f = class_3675.method_15987(aM_.method_22683().method_4490(), 264) ? -1.0f : 0.0f;
            }
            event.a(f);
            if (class_3675.method_15987(aM_.method_22683().method_4490(), 262)) {
                f2 = -1.0f;
            } else {
                f2 = class_3675.method_15987(aM_.method_22683().method_4490(), 263) ? 1.0f : 0.0f;
            }
            event.b(f2);
            event.b(false);
            event.c(false);
        }
    }

    @EventTarget
    public void a(PacketEvent event) {
        if (event.b() && this.d.c().booleanValue() && this.e != null && !aM_.field_1724.method_24828() && aM_.field_1724.method_5805()) {
            if ((event.d() instanceof class_2851) || (event.d() instanceof class_2848)) {
                event.a(true);
            }
        }
    }

    private void d(boolean clearPositions) {
        if (clearPositions) {
            this.e = null;
            this.f = null;
            this.g = null;
        } else {
            this.i = 0.0f;
            this.h = 0.0f;
            this.k = false;
            this.j = false;
        }
    }
}
