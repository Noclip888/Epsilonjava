package aethereal.module.movement;

import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.InputEvent;
import net.minecraft.class_2848;

@ModuleRegister(a = "No Crouch", b = "Убирает замедление от приседания на вашей стороне", c = Category.Movement)
public class NoCrouch extends Module {
    private boolean b;

    @EventTarget
    public void a(InputEvent e) {
        class_2848.class_2849 class_2849Var;
        boolean sneaking = e.e();
        if (sneaking) {
            class_2849Var = class_2848.class_2849.field_12979;
        } else {
            class_2849Var = this.b ? class_2848.class_2849.field_12984 : null;
        }
        class_2848.class_2849 mode = class_2849Var;
        if (mode != null) {
            aM_.field_1724.field_3944.method_52787(new class_2848(aM_.field_1724, mode));
        }
        this.b = sneaking;
        e.c(false);
    }
}
