package aethereal.module.misc;

import platform.inject.invokers.MinecraftClientInvoker;
import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;
import aethereal.core.Module;
import aethereal.util.ChatUtil;
import aethereal.util.InventoryUtil;
import aethereal.util.Look;
import aethereal.util.MathUtil;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.TickEvent;
import aethereal.util.Rotation;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

@ModuleRegister(a = "Clan Upgrader", b = "Быстро прокачивает клан с помощью редстоуна и факела", c = Category.Misc)
public class ClanUpgrader extends Module {
    private int b;

    @Override
    public void c() {
        super.c();
        if (this.b != -1) {
            aM_.field_1724.method_31548().field_7545 = this.b;
            this.b = -1;
        }
    }

    @EventTarget
    public void a(TickEvent event) {
        int redstone = InventoryUtil.a(class_1802.field_8725, true);
        int torch = InventoryUtil.a(class_1802.field_8810, true);
        int target = redstone != -1 ? redstone : torch;
        if (redstone == -1 && torch == -1) {
            ChatUtil.a((Object) "Вам необходимо иметь факел или редстоун в хотбаре");
            a();
            return;
        }
        float randomPitch = ((float) (Math.sin(System.currentTimeMillis() / 1220.0d) * ((double) (Math.abs(90.0f - aM_.field_1724.method_36455()) / 8.0f)))) + MathUtil.a(-0.1f, 0.1f);
        Rotation rotation = new Rotation(Look.b() + MathUtil.a(-1.0f, 1.0f), MathUtil.b(88.0f + randomPitch, -90.0f, 90.0f));
        Epsilon.h().d().k().a(rotation, 90.0f, 1, 1);
        if (this.b == -1) {
            this.b = aM_.field_1724.method_31548().field_7545;
        }
        if (aM_.field_1724.method_31548().field_7545 != target) {
            aM_.field_1724.method_31548().field_7545 = target;
        }
        if (Rotation.b().a(rotation) <= 1.0d) {
            class_2338 position = aM_.field_1724.method_24515();
            if (aM_.field_1687.method_8320(position).method_27852(class_2246.field_10091) || aM_.field_1687.method_8320(position).method_27852(class_2246.field_10336)) {
                aM_.field_1761.method_2910(position, class_2350.field_11036);
                aM_.field_1724.method_6104(class_1268.field_5808);
            } else {
                ((platform.inject.invokers.MinecraftClientInvoker) aM_).invokeDoItemUse();
            }
        }
    }
}
