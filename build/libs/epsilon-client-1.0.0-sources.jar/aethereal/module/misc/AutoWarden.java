package aethereal.module.misc;

import aethereal.util.StringUtils;
import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;
import aethereal.core.InterfaceC0020Opcode;
import aethereal.core.Module;
import aethereal.util.ChatUtil;
import aethereal.util.InventoryUtil;
import aethereal.util.MathUtil;
import aethereal.util.ServerUtil;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.InputEvent;
import aethereal.event.PacketEvent;
import aethereal.event.SoundEvent;
import aethereal.event.TickEvent;
import aethereal.module.render.WardenESP;
import aethereal.util.Rotation;

import aethereal.setting.BooleanSetting;
import aethereal.util.CounterUtil;
import aethereal.setting.ModeSetting;
import baritone.api.BaritoneAPI;
import baritone.api.pathing.goals.GoalBlock;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Stream;
import lombok.Generated;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1744;
import net.minecraft.class_1746;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_1847;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2745;
import net.minecraft.class_3481;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_418;
import net.minecraft.class_437;
import net.minecraft.class_476;
import net.minecraft.class_6880;
import net.minecraft.class_7260;
import net.minecraft.class_7439;
import net.minecraft.class_7923;
import net.minecraft.class_8052;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

@ModuleRegister(a = "Auto Warden", b = "Автоматизирует фарм варденов на анархии", c = Category.Misc)
public class AutoWarden extends Module {
    private int i;
    private boolean j;
    private class_238 k;
    private class_2338 l;
    private String n;
    private final List<Integer> b = new ArrayList();
    private final Map<class_2338, Integer> c = new HashMap();
    private final Map<class_2338, Integer> d = new HashMap();
    private final BooleanSetting e = new BooleanSetting("Использовать скорость", false);
    private final BooleanSetting f = new BooleanSetting("Репортить обидчиков", false);
    private final ModeSetting g = new ModeSetting("Приоритеты лута", "Средний", "Низкий", "Средний", "Высокий");
    private final BooleanSetting p = new BooleanSetting("Отладка", false);
    private int h = 1;
    private final CounterUtil m = new CounterUtil();
    private a o = a.SAVE;
    private boolean previousFreeLook;
    private boolean previousBlockFreeLook;
    private Double previousRandomLooking;
    private Double previousRandomLooking113;

    enum a {
        SAVE,
        TAKE,
        COLLECTING,
        ESCAPE
    }

    @Generated
    public List<Integer> q() {
        return this.b;
    }

    public AutoWarden() {
        a(this.e, this.f, this.g, this.p);
    }

    @Override
    public void b() {
        super.b();
        int current = ServerUtil.a.d();
        if (current >= 0) {
            this.b.remove(Integer.valueOf(current));
            this.b.add(0, Integer.valueOf(current));
        }
        this.h = 1;
        this.o = a.COLLECTING;
        this.d.clear();
        if (!Epsilon.h().d().t().i().m()) {
            Epsilon.h().d().t().i().a();
        }
        ChatUtil.a((Object) "Shift + Пробел — быстрое выключение функции");
        var settings = BaritoneAPI.getSettings();
        this.previousFreeLook = settings.freeLook.value;
        this.previousBlockFreeLook = settings.blockFreeLook.value;
        this.previousRandomLooking = settings.randomLooking.value;
        this.previousRandomLooking113 = settings.randomLooking113.value;
        settings.avoidance.value = true;
        settings.maxFallHeightNoWater.value = 256;
        // Let Baritone steer the player's visible view along its path, with its gradual aim processor.
        settings.freeLook.value = false;
        settings.blockFreeLook.value = false;
        // Random per-tick rotations make the camera jitter instead of following the route.
        settings.randomLooking.value = 0.0d;
        settings.randomLooking113.value = 0.0d;
        d(true);
    }

    @Override
    public void c() {
        super.c();
        BaritoneAPI.getSettings().allowBreak.value = false;
        BaritoneAPI.getSettings().allowPlace.value = false;
        BaritoneAPI.getSettings().avoidance.value = false;
        BaritoneAPI.getSettings().maxFallHeightNoWater.value = 3;
        BaritoneAPI.getSettings().freeLook.value = this.previousFreeLook;
        BaritoneAPI.getSettings().blockFreeLook.value = this.previousBlockFreeLook;
        if (this.previousRandomLooking != null) {
            BaritoneAPI.getSettings().randomLooking.value = this.previousRandomLooking;
        }
        if (this.previousRandomLooking113 != null) {
            BaritoneAPI.getSettings().randomLooking113.value = this.previousRandomLooking113;
        }
        d(false);
    }

    private void d(boolean add) {
        List<class_2248> list = (List) BaritoneAPI.getSettings().blocksToAvoid.value;
        try {
            for (class_2248 block : class_7923.field_41175) {
                if (block.method_9564().method_26164(class_3481.field_26983)) {
                    if (!add) {
                        list.remove(block);
                    } else if (!list.contains(block)) {
                        list.add(block);
                    }
                }
            }
        } catch (IllegalStateException e) {
        }
    }

    @EventTarget
    public void a(TickEvent event) {
        if ((aM_.field_1755 instanceof class_418) && aM_.field_1724.field_6213 >= 5) {
            aM_.field_1724.method_7331();
        }
        if (aM_.field_1724 == null || aM_.field_1687 == null) {
            return;
        }
        if (this.p.c().booleanValue() && aM_.field_1724.field_6012 % 20 == 0) {
            S();
        }
        if (aM_.field_1690.field_1832.method_1434() && aM_.field_1690.field_1903.method_1434()) {
            a();
        }
        for (class_7260 class_7260Var : aM_.field_1687.method_8390(class_7260.class, aM_.field_1724.method_5829().method_1014(256.0), e -> true)) {
            if (class_7260Var instanceof class_7260) {
                class_7260 warden = class_7260Var;
                this.d.put(warden.method_24515(), Integer.valueOf(aM_.field_1724.field_6012 + 100));
            }
        }
        this.d.values().removeIf(expire -> {
            return aM_.field_1724.field_6012 > expire.intValue();
        });
        if (this.n != null) {
            if (aM_.field_1724.field_6012 >= 20 && aM_.field_1724.field_6012 < 30) {
                aM_.field_1724.field_3944.method_45729("/report " + this.n + " чит");
                this.n = null;
                return;
            }
            return;
        }
        if (aM_.field_1724.field_6012 < 5) {
            this.i = 0;
            this.c.clear();
            return;
        }
        if (ServerUtil.a.d() < 0) {
            if (aM_.field_1724.field_6012 % 100 == 0 && t() >= 0 && aM_.field_1724.field_6012 > 300) {
                aM_.field_1724.field_3944.method_45730("an" + t());
            }
            this.o = a.SAVE;
            return;
        }
        if (aM_.field_1724.field_6012 % 100 == 0 && E() && (this.k == null || !G())) {
            F();
        }
        if (aM_.field_1724.method_6059(class_1294.field_5912) && b(32.0d)) {
            e(false);
            return;
        }
        if (aM_.field_1724.method_6059(class_1294.field_5912) && b(32.0d)) {
            e(false);
            return;
        }
        switch (this.o) {
            case SAVE:
                v();
                break;
            case TAKE:
                w();
                break;
            case COLLECTING:
                x();
                break;
            case ESCAPE:
                B();
                break;
        }
        if (!r() || aM_.field_1724.field_6012 % 15 != 0) {
            return;
        }
        C();
    }

    @EventTarget
    public void a(PacketEvent event) {
        if (event.c()) {
            class_7439 class_7439VarD = (class_7439) event.d();
            if (class_7439VarD instanceof class_7439) {
                class_7439 message = class_7439VarD;
                if (!message.comp_763().getString().contains("Помянем. Вы погибли")) {
                    return;
                }
                this.j = true;
                String text = message.comp_763().getString();
                if (this.f.c().booleanValue() && aM_.field_1724 != null && text.contains("Вас убил")) {
                    StringBuilder effects = new StringBuilder();
                    for (class_1293 effect : aM_.field_1724.method_6026()) {
                        effects.append(((class_1291) effect.method_5579().comp_349()).method_5560().getString()).append(StringUtils.a);
                    }
                    ChatUtil.a((Object) ("Эффекты при смерти: " + (effects.isEmpty() ? "нет" : effects.toString().trim())));
                    if (!aM_.field_1724.method_6059(class_1294.field_5912) && !a(2.0d)) {
                        this.n = text.split("Вас убил ")[1].split(",")[0].trim();
                    }
                }
            }
        }
    }

    @EventTarget
    public void a(SoundEvent event) {
        String path = event.b().method_4775().method_12832();
        if (aM_.field_1724 != null) {
            if (path.contains("warden.roar") || path.contains("warden.angry") || path.contains("warden.sonic")) {
                this.i = aM_.field_1724.field_6012 + 100;
            }
        }
    }

    @EventTarget
    public void a(InputEvent event) {
        if (aM_.field_1724 == null) {
            return;
        }
        if (!aM_.field_1724.method_24828() && !aM_.field_1724.method_6101()) {
            event.c(false);
        }
        if (r() && aM_.field_1724.method_6047().method_7960() && !a(3.0d)) {
            int dir = ((float) (aM_.field_1724.field_6012 % 10)) <= MathUtil.a(3.0f, 8.0f) ? -1 : 1;
            event.a(dir);
            event.b(dir);
        }
    }

    private boolean r() {
        if (aM_.field_1687.method_8320(aM_.field_1724.method_24515()).method_26164(class_3481.field_26983) || aM_.field_1687.method_8320(aM_.field_1724.method_24515().method_10074()).method_26164(class_3481.field_26983)) {
            return true;
        }
        return !A() && this.o == a.COLLECTING && E() && aM_.field_1755 == null && !L() && !Epsilon.h().d().v().k().a() && s();
    }

    private boolean s() {
        class_238 box = aM_.field_1724.method_5829().method_1009(0.05000000009506496d, 0.0d, 0.05000000009506496d);
        for (class_2338 pos : class_2338.method_10097(class_2338.method_49637(box.field_1323, box.field_1322, box.field_1321), class_2338.method_49637(box.field_1320, box.field_1325, box.field_1324))) {
            if (!aM_.field_1687.method_8320(pos).method_26215()) {
                return true;
            }
        }
        return false;
    }

    private boolean a(double range) {
        for (class_2338 chest : Epsilon.h().d().t().i().q()) {
            if (aM_.field_1724.method_5707(class_243.method_24953(chest)) <= range * range) {
                return true;
            }
        }
        return false;
    }

    private int t() {
        if (this.b.isEmpty()) {
            return -1;
        }
        return ((Integer) this.b.getFirst()).intValue();
    }

    private boolean u() {
        return t() >= 0 && t() == ServerUtil.a.d();
    }

    private void v() {
        if (t() >= 0 && ServerUtil.a.d() != t() && !ServerUtil.e() && aM_.field_1724.field_6012 % 5 == 0 && aM_.field_1724.field_6012 > 5) {
            aM_.field_1724.field_3944.method_45730("an" + t());
        }
        if (u()) {
            M();
            a(R(), true, a.TAKE);
        }
    }

    private void w() {
        if (this.j && this.b.size() > 1) {
            int i = this.h + 1;
            this.h = i;
            if (i >= this.b.size()) {
                this.h = 1;
            }
            this.j = false;
        }
        this.i = 0;
        this.c.clear();
        if (aM_.field_1724.field_6012 % 20 == 0) {
            StringBuilder missing = new StringBuilder("Собираем (возможно не хватает) -> ");
            if (Q() < 1) {
                missing.append("зелье невидимости, ");
            }
            if (InventoryUtil.a(class_1802.field_8071) < 3) {
                missing.append("золотая морковь, ");
            }
            if (this.e.c().booleanValue() && a(this::f) < 0) {
                missing.append("зелье скорости ");
            }
            if (aM_.field_1724.field_6012 % InterfaceC0020Opcode.aN == 0 && !missing.isEmpty() && !O()) {
                aM_.field_1724.method_3137();
            }
        }
        if (u()) {
            a(P() || O(), false, a.COLLECTING);
        }
    }

    private void x() {
        if (y()) {
            return;
        }
        Epsilon.h().d().t().aV().b(18);
        if (Epsilon.h().d().v().k().a()) {
            if (L()) {
                C();
                return;
            }
            return;
        }
        if (this.b.size() <= 1) {
            if (aM_.field_1724.field_6012 % 20 == 0) {
                ChatUtil.a((Object) "ОШИБКА -> .warden list пустой");
                return;
            }
            return;
        }
        if (this.h >= this.b.size()) {
            this.h = 1;
        }
        int target = this.b.get(this.h).intValue();
        if (ServerUtil.a.d() != target) {
            if (aM_.field_1724.field_6012 % 10 != 0 || aM_.field_1724.field_6012 <= 10) {
                return;
            }
            aM_.field_1724.field_3944.method_45730("an" + target);
            return;
        }
        if (aM_.field_1724.field_6012 > 5) {
            z();
        }
    }

    private int b(int base) {
        double d;
        double d2 = base;
        if (this.g.l("Низкий")) {
            d = 1.5d;
        } else {
            d = this.g.l("Высокий") ? 0.80000014538821d : 1.0d;
        }
        return (int) (d2 * d);
    }

    private boolean y() {
        boolean aggro = A();
        if ((aggro || D() > b(20) || aM_.field_1724.method_7344().method_7586() < 8 || (this.c.values().stream().filter(count -> {
            return count.intValue() >= 2;
        }).count() >= 3 && aM_.field_1724.field_6012 % 30 == 0)) && aM_.field_1724.field_6012 > 100) {
            if (aggro) {
                this.j = true;
            }
            this.o = a.ESCAPE;
            return true;
        }
        if (!ServerUtil.e() && D() > b(8)) {
            this.o = a.ESCAPE;
            return true;
        }
        int pvpTime = ServerUtil.f();
        if (pvpTime >= 0 && pvpTime < 7 && !b(14.0d) && D() > b(7)) {
            this.o = a.ESCAPE;
            return true;
        }
        return false;
    }

    private void z() {
        class_1293 invis = aM_.field_1724.method_6112(class_1294.field_5905);
        boolean ready = aM_.field_1724.method_6059(class_1294.field_5912) || (invis != null && invis.method_5584() >= 400);
        if (!ready && invis == null && Q() < 1 && aM_.field_1724.field_6012 % 5 == 0 && !ServerUtil.e()) {
            this.o = a.ESCAPE;
            return;
        }
        if (!ready) {
            K();
        }
        if (!E()) {
            if (aM_.field_1724.field_6012 % 50 == 0) {
                aM_.field_1724.field_3944.method_45730("home");
            }
        } else if (ready) {
            int speedSlot = (this.e.c().booleanValue() && aM_.field_1724.method_6112(class_1294.field_5904) == null) ? a(this::f) : -1;
            if (speedSlot < 0) {
                H();
            } else {
                Epsilon.h().d().v().k().a(speedSlot);
            }
        }
    }

    private boolean A() {
        if (aM_.field_1724.field_6012 < this.i) {
            for (class_1297 entity : aM_.field_1687.method_18112()) {
                if (entity instanceof class_7260) {
                    class_7260 warden = (class_7260) entity;
                    double distSq = aM_.field_1724.method_5858(warden);
                    if (distSq < 900.0d && b(warden) && (distSq < 16.0d || a(warden))) {
                        return true;
                    }
                }
            }
            return false;
        }
        return false;
    }

    private boolean a(class_7260 warden) {
        return ((aM_.field_1724.method_23317() - warden.method_23317()) * (warden.method_23317() - warden.field_6014)) + ((aM_.field_1724.method_23321() - warden.method_23321()) * (warden.method_23321() - warden.field_5969)) > 0.010000003841705648d;
    }

    private boolean b(class_7260 warden) {
        double yawToMe = Math.toDegrees(Math.atan2(-(aM_.field_1724.method_23317() - warden.method_23317()), aM_.field_1724.method_23321() - warden.method_23321()));
        return Math.abs(((((((double) warden.method_43078()) - yawToMe) % 360.0d) + 540.0d) % 360.0d) - 180.0d) < 10.0d;
    }

    private void B() {
        if (u()) {
            this.o = a.SAVE;
            return;
        }
        if (A() && ServerUtil.e()) {
            e(true);
            return;
        }
        class_2338 near = J();
        if ((aM_.field_1755 instanceof class_476) || (near != null && Epsilon.h().d().t().i().a(near) < 0 && aM_.field_1724.method_33571().method_1025(class_243.method_24953(near)) <= 16.0d)) {
            H();
            return;
        }
        if (ServerUtil.e()) {
            if (D() >= 23 || b(2.0d) || ServerUtil.f() <= 16 || near == null) {
                e(true);
                return;
            } else {
                H();
                return;
            }
        }
        this.o = a.SAVE;
    }

    private void e(boolean warden) {
        N();
        M();
        class_2338 best = null;
        double bestScore = -1.0d;
        int y = aM_.field_1724.method_24515().method_10264();
        for (int angle = 0; angle < 360; angle += 30) {
            int x = c((int) (aM_.field_1724.method_23317() + (Math.cos(Math.toRadians(angle)) * 25.0d)));
            int z = d((int) (aM_.field_1724.method_23321() + (Math.sin(Math.toRadians(angle)) * 25.0d)));
            double score = a(x, z, warden);
            if (score > bestScore) {
                bestScore = score;
                best = new class_2338(x, y, z);
            }
        }
        a(best);
    }

    private void a(class_2338 spot) {
        if (spot != null) {
            if (aM_.field_1724.field_6012 % 10 == 0 || (!L() && aM_.field_1724.field_6012 % 5 == 0)) {
                BaritoneAPI.getProvider().getPrimaryBaritone().getCustomGoalProcess().setGoalAndPath(new GoalBlock(new class_2338(c(spot.method_10263()), spot.method_10264(), d(spot.method_10260()))));
            }
        }
    }

    private void C() {
        BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().cancelEverything();
    }

    private void S() {
        baritone.api.behavior.IPathingBehavior pathing = BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior();
        ChatUtil.a((Object) ("&7[AW] состояние &f" + this.o + " &7| анархия &f" + ServerUtil.a.d() + "&7, нужна &f" + t() + " &7(список: &f" + this.b.size() + "&7) | в зоне фермы &f" + E() + " &7| сундуков у ESP &f" + Epsilon.h().d().t().i().q().size() + " &7| варден &f" + A() + " &7| пвп &f" + ServerUtil.e() + " &7| baritone: &f" + (pathing.isPathing() ? String.valueOf(pathing.getGoal()) : "стоит")));
        ChatUtil.a((Object) ("&7[AW] застрял(r) &c" + r() + " &7| двигаюсь(L) &f" + L() + " &7| в блоке(s) &f" + s() + " &7| свечи &f" + (aM_.field_1687.method_8320(aM_.field_1724.method_24515()).method_26164(class_3481.field_26983) || aM_.field_1687.method_8320(aM_.field_1724.method_24515().method_10074()).method_26164(class_3481.field_26983))));
        class_2338 reach = f(true);
        class_2338 far = T();
        ChatUtil.a((Object) ("&7[AW] лут в инвентаре(R) &f" + R() + " &7| приёмник в руке &f" + (reach == null ? "нет" : String.valueOf(reach)) + " &7| ближайший приёмник &f" + (far == null ? "не найден в радиусе 16" : far + " (" + ((int) Math.sqrt(aM_.field_1724.method_5707(class_243.method_24953(far)))) + " бл.)") + " &7| экран &f" + (aM_.field_1755 == null ? "нет" : aM_.field_1755.getClass().getSimpleName())));
    }

    private class_2338 T() {
        class_2338 origin = aM_.field_1724.method_24515();
        class_2338.class_2339 pos = new class_2338.class_2339();
        class_2338 best = null;
        double bestDist = Double.MAX_VALUE;
        for (int dx = -16; dx <= 16; dx++) {
            for (int dy = -6; dy <= 6; dy++) {
                for (int dz = -16; dz <= 16; dz++) {
                    pos.method_10103(origin.method_10263() + dx, origin.method_10264() + dy, origin.method_10260() + dz);
                    if (aM_.field_1687.method_8320(pos).method_27852(class_2246.field_10034) && g((class_2338) pos) && aM_.field_1687.method_8320(pos.method_10084()).method_26215()) {
                        double dist = aM_.field_1724.method_5707(class_243.method_24953(pos));
                        if (dist < bestDist) {
                            bestDist = dist;
                            best = pos.method_10062();
                        }
                    }
                }
            }
        }
        return best;
    }

    private double a(int x, int z, boolean warden) {
        double min = 1.7976922776554316E308d;
        for (class_1297 class_746Var : aM_.field_1687.method_18112()) {
            if (class_746Var != aM_.field_1724 && ((class_746Var instanceof class_1657) || (warden && (class_746Var instanceof class_7260)))) {
                min = Math.min(min, Math.hypot(class_746Var.method_23317() - ((double) x), class_746Var.method_23321() - ((double) z)));
            }
        }
        return min;
    }

    private int D() {
        int n = 0;
        for (class_1799 stack : aM_.field_1724.method_31548().field_7547) {
            if (!stack.method_7960()) {
                n++;
            }
        }
        return n;
    }

    private boolean E() {
        return aM_.field_1687.method_27983().method_29177().toString().equals("minecraft:overworld") && aM_.field_1724.method_23317() <= -1921.0d && aM_.field_1724.method_23317() >= -2070.0d && aM_.field_1724.method_23321() <= -1929.0d && aM_.field_1724.method_23321() >= -2076.0d;
    }

    private void F() {
        this.k = new class_238(-2070.0d, aM_.field_1724.method_24515().method_10264(), -2076.0d, -1921.0d, aM_.field_1724.method_24515().method_10264(), -1929.0d);
    }

    private boolean G() {
        return this.k != null && aM_.field_1724.method_23317() >= this.k.field_1323 && aM_.field_1724.method_23317() <= this.k.field_1320 && aM_.field_1724.method_23321() >= this.k.field_1321 && aM_.field_1724.method_23321() <= this.k.field_1324;
    }

    private int c(int x) {
        return this.k == null ? x : (int) Math.max(this.k.field_1323 + 10.0d, Math.min(this.k.field_1320 - 10.0d, x));
    }

    private int d(int z) {
        return this.k == null ? z : (int) Math.max(this.k.field_1321 + 10.0d, Math.min(this.k.field_1324 - 10.0d, z));
    }

    private void H() {
        class_437 class_437Var = aM_.field_1755;
        if (class_437Var instanceof class_476) {
            class_476 screen = (class_476) class_437Var;
            a(screen);
            return;
        }
        class_2338 pick = J();
        if (pick == null) {
            pick = I();
        }
        boolean stay = (pick == null || this.l == null || pick.equals(this.l) || Epsilon.h().d().t().i().a(this.l) <= 25000) ? false : true;
        if (!stay) {
            this.m.b();
        }
        if (!stay || this.m.a(1000L)) {
            this.l = pick;
        }
        class_2338 target = this.l;
        if (target == null && aM_.field_1724.field_6012 % 40 == 0) {
            this.o = a.ESCAPE;
            this.j = true;
        }
        long remaining = Epsilon.h().d().t().i().a(target);
        if (target != null && remaining > 1000 && a(target, 7.0d)) {
            class_2338 spot = c(target);
            if (spot != null) {
                if (aM_.field_1724.method_5707(class_243.method_24953(spot)) > 2.0d) {
                    a(spot);
                    return;
                } else {
                    C();
                    return;
                }
            }
            return;
        }
        if (remaining > 6000) {
            a(b(target));
            return;
        }
        double distSq = aM_.field_1724.method_33571().method_1025(class_243.method_24953(target));
        if (distSq <= 20.0d) {
            if (this.c.getOrDefault(target, 0).intValue() < (remaining >= 0 ? 1 : 3)) {
                if (a(target, remaining >= 0 ? 6 : 1)) {
                    this.c.merge(target, 1, (v0, v1) -> {
                        return Integer.sum(v0, v1);
                    });
                    return;
                }
                return;
            }
            return;
        }
        if (distSq > 10.0d) {
            M();
        }
        a(c(target));
    }

    private class_2338 b(class_2338 chest) {
        double angle = ((double) (aM_.field_1724.field_6012 / 40)) * 2.4000011930854526d;
        return new class_2338(c(chest.method_10263() + ((int) (Math.cos(angle) * 10.0d))), chest.method_10264(), d(chest.method_10260() + ((int) (Math.sin(angle) * 10.0d))));
    }

    private class_2338 I() {
        WardenESP esp = Epsilon.h().d().t().i();
        class_2338 best = null;
        long bestMs = 45000;
        for (class_2338 chest : esp.q()) {
            long remaining = esp.a(chest);
            if (remaining >= 0 && remaining < bestMs && f(chest) && !d(chest) && !e(chest)) {
                bestMs = remaining;
                best = chest;
            }
        }
        return best;
    }

    private class_2338 J() {
        WardenESP esp = Epsilon.h().d().t().i();
        class_2338 best = null;
        int bestTier = 99;
        double bestSq = 1.7976922776554316E308d;
        for (class_2338 chest : esp.q()) {
            if (f(chest) && !e(chest)) {
                double distSq = aM_.field_1724.method_33571().method_1025(class_243.method_24953(chest));
                long remaining = esp.a(chest);
                if (!d(chest) || (remaining < 0 && distSq <= 16.0d)) {
                    if (remaining >= 0 || this.c.getOrDefault(chest, 0).intValue() < 3) {
                        int tier = -1;
                        if (remaining < 0 && distSq <= 25.0d) {
                            tier = 0;
                        } else if (remaining >= 0 && remaining <= 5000 && distSq <= 144.0d) {
                            tier = 1;
                        } else if (remaining < 0 && distSq <= 144.0d) {
                            tier = 2;
                        } else if (remaining >= 0 && remaining <= 15000 && distSq <= 625.0d) {
                            tier = 3;
                        } else if (remaining < 0) {
                            tier = 4;
                        }
                        if (tier < 0) {
                            continue;
                        }
                        double up = class_243.method_24953(chest).field_1351 - aM_.field_1724.method_23320();
                        double dx = (((double) chest.method_10263()) + 0.5d) - aM_.field_1724.method_23317();
                        double dz = (((double) chest.method_10260()) + 0.5d) - aM_.field_1724.method_23321();
                        double weightedSq = (dx * dx) + (dz * dz) + (((double) (up > 0.0d ? 2 : 1)) * up * up);
                        if (tier < bestTier || (tier == bestTier && weightedSq < bestSq)) {
                            bestTier = tier;
                            bestSq = weightedSq;
                            best = chest;
                        }
                    }
                }
            }
        }
        return best;
    }

    private boolean b(double range) {
        for (class_1297 _e : aM_.field_1687.method_18112()) {
            if (!(_e instanceof class_1657 player)) continue;
            if (player != aM_.field_1724 && aM_.field_1724.method_5858(player) < range * range) {
                return true;
            }
        }
        return false;
    }

    private void a(class_476 screen) {
        if (L()) {
            C();
            return;
        }
        if (aM_.field_1724.field_6012 % 2 != 0) {
            return;
        }
        class_1735 slot = a(screen, false, stack -> {
            return (stack.method_7960() || b(stack)) ? false : true;
        });
        if (slot == null) {
            N();
        } else {
            a(screen, slot, 0, class_1713.field_7794);
        }
    }

    private class_2338 c(class_2338 chest) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx != 0 || dz != 0) {
                    class_2338 side = chest.method_10069(dx, 0, dz);
                    if (aM_.field_1687.method_8320(side).method_26215() && aM_.field_1687.method_8320(side.method_10084()).method_26215() && !aM_.field_1687.method_8320(side.method_10074()).method_26215() && a(side, chest)) {
                        return side;
                    }
                }
            }
        }
        if (aM_.field_1687.method_8320(chest.method_10084()).method_26215() && aM_.field_1687.method_8320(chest.method_10084().method_10084()).method_26215() && a(chest.method_10084(), chest)) {
            return chest.method_10084();
        }
        return null;
    }

    private boolean a(class_2338 from, class_2338 chest) {
        return a(class_243.method_24953(from).method_1031(0.0d, ((double) aM_.field_1724.method_18381(aM_.field_1724.method_18376())) - 0.5d, 0.0d), chest) != null;
    }

    private class_243 a(class_243 eye, class_2338 chest) {
        class_243 center = class_243.method_24953(chest);
        class_243 best = null;
        double bestSq = Double.MAX_VALUE;
        for (double dx = -0.3999999563044224d; dx <= 0.41000000193542635d; dx += 0.4000000009895358d) {
            for (double dy = -0.3999999563044224d; dy <= 0.41000000193542635d; dy += 0.4000000009895358d) {
                for (double dz = -0.3999999563044224d; dz <= 0.41000000193542635d; dz += 0.4000000009895358d) {
                    class_243 point = center.method_1031(dx, dy, dz);
                    double sq = point.method_1025(center);
                    if (sq < bestSq && aM_.field_1687.method_17742(new class_3959(eye, point, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, aM_.field_1724)).method_17777().equals(chest)) {
                        bestSq = sq;
                        best = point;
                    }
                }
            }
        }
        return best;
    }

    private boolean d(class_2338 pos) {
        for (class_2338 warden : this.d.keySet()) {
            if (warden.method_10262(pos) < 25.0d) {
                return true;
            }
        }
        return false;
    }

    private boolean e(class_2338 pos) {
        for (class_1297 _e : aM_.field_1687.method_18112()) {
            if (!(_e instanceof class_1657 player)) continue;
            if (player != aM_.field_1724 && player.method_19538().method_1025(class_243.method_24953(pos)) < 20.0d && Stream.of(class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166).anyMatch(slot -> {
                return player.method_6118(slot).method_7909() instanceof class_1738;
            })) {
                return true;
            }
        }
        return false;
    }

    private boolean a(class_2338 pos, double range) {
        for (class_1297 _e : aM_.field_1687.method_18112()) {
            if (!(_e instanceof class_1657 player)) continue;
            if (player != aM_.field_1724 && player.method_19538().method_1025(class_243.method_24953(pos)) < range * range) {
                return true;
            }
        }
        return false;
    }

    private boolean f(class_2338 chest) {
        return c(chest) != null;
    }

    private void K() {
        int slot = a(this::e);
        if (slot >= 0 && aM_.field_1724.field_6012 > 20) {
            Epsilon.h().d().v().k().a(slot);
        }
    }

    private int a(Predicate<class_1799> match) {
        for (int i = 0; i < 36; i++) {
            if (match.test(aM_.field_1724.method_31548().method_5438(i))) {
                return i;
            }
        }
        return -1;
    }

    private void a(boolean active, boolean hopper, a next) {
        if (!active) {
            if (N()) {
                this.o = next;
                return;
            }
            return;
        }
        class_437 class_437Var = aM_.field_1755;
        if (class_437Var instanceof class_476) {
            class_476 screen = (class_476) class_437Var;
            if (!hopper) {
                c(screen);
                return;
            } else {
                b(screen);
                return;
            }
        }
        a(f(hopper), 2);
    }

    private boolean a(class_2338 chest, int rate) {
        class_243 eye;
        class_243 aim;
        if (chest == null || (aM_.field_1755 instanceof class_476) || (aim = a((eye = aM_.field_1724.method_33571()), chest)) == null) {
            return false;
        }
        Rotation target = Rotation.a(eye, aim);
        float t = aM_.field_1724.field_6012 + aM_.method_61966().method_60637(false);
        float sw = (float) (((Math.sin(t * 0.31f) * 0.5d) + (Math.sin((t * 0.73f) + 1.1f) * 0.3000000317022817d) + (Math.sin((t * 1.7f) + 2.6f) * 0.1999999860971588d)) * 8.0d);
        Epsilon.h().d().k().a(new Rotation(target.c() + sw, MathUtil.b(target.d() + (sw / 4.0f), -90.0f, 90.0f)), 120.0f, 1, 1);
        if (aM_.field_1724.field_6012 % rate != 0 || Rotation.b().a(target) > 5.0d) {
            return false;
        }
        class_3965 hit = aM_.field_1687.method_17742(new class_3959(eye, aim, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, aM_.field_1724));
        if (!hit.method_17777().equals(chest)) {
            return false;
        }
        aM_.field_1761.method_2896(aM_.field_1724, class_1268.field_5808, hit);
        aM_.field_1724.method_6104(class_1268.field_5808);
        return true;
    }

    private boolean L() {
        return aM_.field_1724.method_18798().method_37268() > 0.002500001077917312d;
    }

    private void M() {
        if (aM_.field_1724.method_6047().method_7960()) {
            return;
        }
        for (int i = 0; i < 9; i++) {
            if (aM_.field_1724.method_31548().method_5438(i).method_7960()) {
                aM_.field_1724.method_31548().field_7545 = i;
                return;
            }
        }
        for (int i2 = 9; i2 < 36; i2++) {
            if (aM_.field_1724.method_31548().method_5438(i2).method_7960()) {
                if (aM_.field_1724.field_6012 % 10 >= 2 && L()) {
                    C();
                }
                if (aM_.field_1724.field_6012 % 10 == 4) {
                    Epsilon.h().d().v().a().a(aM_.field_1724.method_31548().field_7545, i2, 1);
                    return;
                }
                return;
            }
        }
    }

    private boolean N() {
        if ((aM_.field_1755 instanceof class_476) && aM_.field_1724.field_6012 % 2 == 0) {
            aM_.field_1724.method_7346();
        }
        return !(aM_.field_1755 instanceof class_476);
    }

    private void b(class_476 screen) {
        if (aM_.field_1724.field_6012 % 2 != 0) {
            return;
        }
        boolean keepPotion = false;
        boolean keepCarrot = false;
        int moved = 0;
        for (class_1735 slot : screen.method_17577().field_7761) {
            if (moved < 4) {
                class_1799 stack = slot.method_7677();
                if (slot.field_7871 == aM_.field_1724.method_31548() && !stack.method_7960() && (!this.e.c().booleanValue() || !f(stack))) {
                    if (!keepPotion && e(stack)) {
                        keepPotion = true;
                    } else if (keepCarrot || !stack.method_31574(class_1802.field_8071)) {
                        a(screen, slot, 0, class_1713.field_7794);
                        moved++;
                    } else {
                        keepCarrot = true;
                    }
                }
            } else {
                return;
            }
        }
    }

    private void c(class_476 screen) {
        if (aM_.field_1724.field_6012 % 2 != 0) {
            return;
        }
        class_1799 cursor = screen.method_17577().method_34255();
        Predicate<class_1799> same = s -> {
            return s.method_7960() || class_1799.method_31577(s, cursor);
        };
        if (!cursor.method_7960()) {
            if (!a(cursor)) {
                a(screen, a(screen, false, same), 0, class_1713.field_7790);
                return;
            } else {
                a(screen, a(screen, true, same), 1, class_1713.field_7790);
                return;
            }
        }
        a(screen, a(screen, false, this::a), 0, class_1713.field_7790);
    }

    private class_1735 a(class_476 screen, boolean player, Predicate<class_1799> match) {
        for (class_1735 slot : screen.method_17577().field_7761) {
            if ((slot.field_7871 == aM_.field_1724.method_31548()) == player && match.test(slot.method_7677())) {
                return slot;
            }
        }
        return null;
    }

    private void a(class_476 screen, class_1735 slot, int button, class_1713 type) {
        if (slot != null) {
            aM_.field_1761.method_2906(screen.method_17577().field_7763, slot.field_7874, button, type, aM_.field_1724);
        }
    }

    private boolean O() {
        class_476 class_476Var = (class_476) aM_.field_1755;
        if (class_476Var instanceof class_476) {
            class_476 screen = class_476Var;
            if (!screen.method_17577().method_34255().method_7960()) {
                return true;
            }
        }
        return false;
    }

    private boolean a(class_1799 stack) {
        return !stack.method_7960() && ((e(stack) && Q() < 1) || ((stack.method_31574(class_1802.field_8071) && InventoryUtil.a(class_1802.field_8071) < 3) || (this.e.c().booleanValue() && f(stack) && a(this::f) < 0)));
    }

    private boolean P() {
        return Q() < 1 || InventoryUtil.a(class_1802.field_8071) < 3 || (this.e.c().booleanValue() && a(this::f) < 0);
    }

    private int Q() {
        int total = 0;
        for (class_1799 stack : aM_.field_1724.method_31548().field_7547) {
            if (e(stack)) {
                total++;
            }
        }
        return total;
    }

    private boolean b(class_1799 stack) {
        if (this.g.l("Низкий")) {
            return false;
        }
        return d(stack) || (this.g.l("Высокий") && c(stack));
    }

    private boolean c(class_1799 stack) {
        class_1792 item = stack.method_7909();
        return (item instanceof class_1744) || (item instanceof class_1810) || (item instanceof class_1743) || stack.method_31574(class_1802.field_8233) || stack.method_31574(class_1802.field_38974) || stack.method_31574(class_1802.field_8864) || stack.method_31574(class_1802.field_8536) || stack.method_31574(class_1802.field_8347) || stack.method_31574(class_1802.field_8300) || stack.method_31574(class_1802.field_8503) || stack.method_31574(class_1802.field_8441) || stack.method_31574(class_1802.field_8149) || stack.method_31574(class_1802.field_22401) || stack.method_31574(class_1802.field_8814) || stack.method_31574(class_1802.field_8745) || stack.method_31574(class_1802.field_8815) || stack.method_31574(class_1802.field_8287) || stack.method_31574(class_1802.field_17515) || stack.method_31574(class_1802.field_8687) || stack.method_31574(class_1802.field_8479) || a(stack, "potion-popper") || stack.method_57826(class_9334.field_52175) || stack.method_31574(class_1802.field_8070) || stack.method_31574(class_1802.field_8613) || stack.method_31574(class_1802.field_8235) || stack.method_31574(class_1802.field_8510) || stack.method_31574(class_1802.field_16314) || stack.method_31574(class_1802.field_8657) || stack.method_31574(class_1802.field_8805) || stack.method_31574(class_1802.field_8058) || stack.method_31574(class_1802.field_8348) || stack.method_31574(class_1802.field_8285);
    }

    private boolean d(class_1799 stack) {
        class_1792 item = stack.method_7909();
        return (item instanceof class_1821) || (item instanceof class_1743) || (item instanceof class_1746) || ((item instanceof class_8052) && !stack.method_31574(class_1802.field_41946)) || stack.method_31574(class_1802.field_8894) || stack.method_31574(class_1802.field_8598) || stack.method_31574(class_1802.field_8547) || stack.method_31574(class_1802.field_8448) || stack.method_31574(class_1802.field_37523) || stack.method_31574(class_1802.field_28101) || stack.method_31574(class_1802.field_8466) || stack.method_31574(class_1802.field_38418) || stack.method_31574(class_1802.field_8323) || stack.method_31574(class_1802.field_20417) || stack.method_31574(class_1802.field_8711) || stack.method_31574(class_1802.field_8782) || stack.method_31574(class_1802.field_8261);
    }

    private boolean a(class_1799 stack, String id) {
        class_9279 data = (class_9279) stack.method_57824(class_9334.field_49628);
        return data != null && id.equals(data.method_57461().method_10562("PublicBukkitValues").method_10558("minecraft:ftid"));
    }

    private boolean e(class_1799 stack) {
        class_6880<class_1842> potion = (class_6880) ((class_1844) stack.method_57825(class_9334.field_49651, class_1844.field_49274)).comp_2378().orElse(null);
        return potion != null && (potion.equals(class_1847.field_8997) || potion.equals(class_1847.field_9000));
    }

    private boolean f(class_1799 stack) {
        if (stack.method_31574(class_1802.field_8574)) {
            for (class_1293 effect : ((class_1844) stack.method_57825(class_9334.field_49651, class_1844.field_49274)).method_57397()) {
                if (effect.method_5579().equals(class_1294.field_5904)) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    private class_2338 f(boolean hopper) {
        class_2338 origin = aM_.field_1724.method_24515();
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int dx = -4; dx <= 4; dx++) {
            for (int dy = -4; dy <= 4; dy++) {
                for (int dz = -4; dz <= 4; dz++) {
                    pos.method_10103(origin.method_10263() + dx, origin.method_10264() + dy, origin.method_10260() + dz);
                    if (aM_.field_1687.method_8320(pos).method_27852(class_2246.field_10034) && g((class_2338) pos) == hopper && aM_.field_1687.method_8320(pos.method_10084()).method_26215() && aM_.field_1687.method_17742(new class_3959(aM_.field_1724.method_33571(), class_243.method_24953(pos), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, aM_.field_1724)).method_17777().equals(pos)) {
                        return pos.method_10062();
                    }
                }
            }
        }
        return null;
    }

    private boolean g(class_2338 pos) {
        if (aM_.field_1687.method_8320(pos.method_10074()).method_27852(class_2246.field_10312)) {
            return true;
        }
        class_2680 state = aM_.field_1687.method_8320(pos);
        if (state.method_11654(class_2741.field_12506) != class_2745.field_12569) {
            for (class_2350 dir : class_2350.class_2353.field_11062) {
                class_2338 partner = pos.method_10093(dir);
                class_2680 ps = aM_.field_1687.method_8320(partner);
                if (ps.method_27852(class_2246.field_10034) && ps.method_11654(class_2741.field_12506) != class_2745.field_12569 && ps.method_11654(class_2741.field_12506) != state.method_11654(class_2741.field_12506) && ps.method_11654(class_2741.field_12481) == state.method_11654(class_2741.field_12481) && aM_.field_1687.method_8320(partner.method_10074()).method_27852(class_2246.field_10312)) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    private boolean R() {
        boolean keepPotion = false;
        boolean keepCarrot = false;
        for (class_1799 stack : aM_.field_1724.method_31548().field_7547) {
            if (!stack.method_7960() && (!this.e.c().booleanValue() || !f(stack))) {
                if (!keepPotion && e(stack)) {
                    keepPotion = true;
                } else {
                    if (keepCarrot || !stack.method_31574(class_1802.field_8071)) {
                        return true;
                    }
                    keepCarrot = true;
                }
            }
        }
        return false;
    }
}
