package aethereal.module.misc;

import aethereal.autobuy.AutoBuyEntry;
import aethereal.autobuy.AutoBuyProcessor;
import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;
import aethereal.core.Module;
import aethereal.util.ChatUtil;
import aethereal.util.MathUtil;
import aethereal.util.MoveUtil;
import aethereal.util.ServerUtil;

import aethereal.core.Category;
import aethereal.core.Client;
import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.core.ModuleRegister;
import aethereal.event.ContainerEvent;
import aethereal.event.PacketEvent;
import aethereal.event.TickEvent;
import aethereal.ui.screen.StationScreen;

import aethereal.setting.BooleanSetting;
import aethereal.setting.ButtonSetting;
import aethereal.util.CounterUtil;
import aethereal.util.DateUtils;
import it.unimi.dsi.fastutil.ints.Int2ObjectMaps;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.stream.Stream;
import lombok.Generated;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2649;
import net.minecraft.class_2767;
import net.minecraft.class_2813;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_3944;
import net.minecraft.class_465;
import net.minecraft.class_476;
import net.minecraft.class_7439;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import platform.inject.accessors.HandledScreenAccessor;

@ModuleRegister(a = "Auto Buy", b = "Автоматически скупает выбранные предметы по заданной цене", c = Category.Misc)
public class AutoBuy extends Module implements Interface {
    private int f;
    private int g;
    private class_1799 i;
    private boolean j;
    private boolean k;
    private final BooleanSetting b = new BooleanSetting("Авто-перевыставление вещей", false);
    private final ButtonSetting c = new ButtonSetting("Открыть редактор", () -> {
        aM_.method_1507(new StationScreen(class_2561.method_43470(""), 1));
    });
    private final List<class_1799> d = new ArrayList();
    private final CounterUtil e = new CounterUtil();
    private int h = -1;

    @Generated
    public boolean q() {
        return this.j;
    }

    @Generated
    public boolean r() {
        return this.k;
    }

    @Generated
    public void d(boolean status) {
        this.j = status;
    }

    @Generated
    public void e(boolean ah) {
        this.k = ah;
    }

    public AutoBuy() {
        a(this.c, this.b);
    }

    @EventTarget
    public void a(TickEvent event) {
        if (aM_.field_1724.field_6012 >= 220 && this.k && !(aM_.field_1755 instanceof class_476) && this.j && aM_.field_1724.field_6012 % 20 == 0) {
            aM_.field_1724.field_3944.method_45731("ah");
            this.k = false;
        }
        this.f++;
        this.g++;
        class_476 class_476Var = (class_476) aM_.field_1755;
        if (class_476Var instanceof class_476) {
            class_476 screen = class_476Var;
            if (this.j) {
                class_1703 handler = screen.method_17577();
                String title = screen.method_25440().getString().replaceAll("§.", "").toLowerCase().trim();
                boolean buy = aM_.field_1724.field_6012 % 2 == 0;
                boolean reissue = this.b.c().booleanValue() && this.e.a(DateUtils.b);
                if (title.contains("аукцион")) {
                    boolean found = false;
                    for (class_1735 slot : handler.field_7761.subList(0, Math.min(45, handler.field_7761.size()))) {
                        class_1799 stack = slot.method_7677();
                        class_9288 shulker = (class_9288) stack.method_57824(class_9334.field_49622);
                        AutoBuyEntry find = Epsilon.h().d().q().e().stream().filter(item -> {
                            if (item.l()) {
                                if (item.a(stack)) {
                                    if (ServerUtil.a.a(stack) > item.k() && ((long) ServerUtil.a.a(stack)) * ((long) Math.max(stack.method_7947(), 1)) <= ServerUtil.a.e()) {
                                        return true;
                                    }
                                } else if (shulker != null) {
                                    Stream<class_1799> streamMethod_57489 = shulker.method_57489();
                                    Objects.requireNonNull(item);
                                    if (streamMethod_57489.anyMatch(innerStack -> item.a(innerStack))) {
                                        if (ServerUtil.a.a(stack) > item.k()) {
                                        }
                                    }
                                }
                            }
                            return false;
                        }).findFirst().orElse(null);
                        if (find != null && buy) {
                            found = true;
                            this.i = stack.method_7972();
                            a(handler, slot.field_7874, class_1713.field_7794);
                            break;
                        }
                    }
                    if (!found && !reissue && this.h == handler.field_7763) {
                        a(handler, 49, MathUtil.a(0.0f, 100.0f) < 25.0f ? class_1713.field_7794 : class_1713.field_7790);
                        this.h = -1;
                    }
                } else if ((title.contains("подтверждение покупки") || title.contains("подозрительная цена!") || title.contains("подозрительная цена: ")) && buy) {
                    a(handler, 1, class_1713.field_7794);
                }
                if (this.b.c().booleanValue() && reissue) {
                    class_465<?> class_465Var = (class_465<?>) aM_.field_1755;
                    if (class_465Var instanceof class_465) {
                        class_465<?> handledScreen = class_465Var;
                        if ((handledScreen instanceof class_476) && !MoveUtil.a()) {
                            if (title.matches(".*а.*у.*к.*ц.*и.*о.*н.*")) {
                                if (aM_.field_1724.field_6012 % 10 == 0) {
                                    a(handledScreen.method_17577(), 46, class_1713.field_7790);
                                    this.g = 0;
                                }
                            } else if (title.matches(".*х.*р.*а.*н.*и.*л.*и.*щ.*е.*")) {
                                if (this.g % 20 == 10) {
                                    a(handledScreen.method_17577(), 52, class_1713.field_7790);
                                } else if (this.g % 20 == 0 && this.g > 0) {
                                    a(handledScreen.method_17577(), 46, class_1713.field_7790);
                                    this.e.b();
                                }
                            }
                            this.f = 0;
                        }
                    }
                }
            }
        }
    }

    @EventTarget
    public void a(PacketEvent event) {
        if (event.c()) {
            if (this.j) {
                class_2649 class_2649VarD = (class_2649) event.d();
                if (class_2649VarD instanceof class_2649) {
                    class_2649 s2CPacket = class_2649VarD;
                    if (s2CPacket.method_11441().size() == 90 && this.f >= 7) {
                        int anarchy = (int) (MathUtil.a(0.0f, 100.0f) <= 50.0f ? MathUtil.a(205.0f, 231.0f) : MathUtil.a(305.0f, 325.0f));
                        aM_.field_1724.field_3944.method_45730("an" + anarchy);
                        ChatUtil.a((Object) ("Обнаружили замедление аукциона, переходим на " + anarchy + " анархию"));
                        this.f = 0;
                        this.k = true;
                    }
                }
                class_7439 class_7439VarD = (class_7439) event.d();
                if (class_7439VarD instanceof class_7439) {
                    class_7439 s2CPacket2 = class_7439VarD;
                    if (this.i != null && s2CPacket2.comp_763().getString().contains("Вы успешно купили")) {
                        if (this.d.isEmpty() || !class_1799.method_7973((class_1799) this.d.getFirst(), this.i)) {
                            Client clientF = Epsilon.h().f();
                            Object[] objArr = new Object[2];
                            objArr[0] = "message";
                            Object[] objArr2 = new Object[3];
                            objArr2[0] = this.i.method_7964().getString() + (this.i.method_7947() > 1 ? " ×" + this.i.method_7947() : "");
                            objArr2[1] = String.format(Locale.US, "%,d", Integer.valueOf(ServerUtil.a.a(this.i)));
                            objArr2[2] = String.format(Locale.US, "%,d", Long.valueOf(ServerUtil.a.e()));
                            objArr[1] = "🛒 AutoBuy — Успешная покупка!\n\n📦 Предмет: %s\n💰 Цена: %s $\n💳 Баланс: %s $\n".formatted(objArr2);
                            clientF.a(false, "telegram", objArr);
                            ChatUtil.a((Object) ("Успешно куплен предмет &c" + this.i.method_7964().getString() + " &7за &c" + ServerUtil.a.a(this.i)));
                            this.d.addFirst(this.i);
                        }
                        this.i = null;
                    }
                }
            }
            class_3944 class_3944VarD = (class_3944) event.d();
            if (class_3944VarD instanceof class_3944) {
                class_3944 openScreenS2CPacket = class_3944VarD;
                if (!(aM_.field_1755 instanceof class_476)) {
                    this.f = 0;
                }
                this.h = openScreenS2CPacket.method_17592();
            }
            class_2767 class_2767VarD = (class_2767) event.d();
            if (class_2767VarD instanceof class_2767) {
                class_2767 s2CPacket3 = class_2767VarD;
                if (((class_3414) s2CPacket3.method_11894().comp_349()).comp_3319().method_12832().equals("block.note_block.basedrum")) {
                    this.h = aM_.field_1724.field_7512.field_7763;
                    event.a(true);
                }
            }
        }
    }

    @EventTarget
    public void a(ContainerEvent event) {
        if (event.h() == ContainerEvent.Phase.POST) {
            String title = event.b().method_25440().getString().replaceAll("§.", "").toLowerCase().trim();
            if (title.contains("аукцион")) {
                HandledScreenAccessor accessor = (HandledScreenAccessor) event.b();
                class_332 context = event.d();
                int count = accessor.getBackgroundHeight() / 18;
                int x = accessor.getX() - 22;
                int y = accessor.getY() + 3;
                int bottom = y + (count * 18);
                int[][] edges = {new int[]{x - 2, y, x + 20, bottom, -3750202}, new int[]{x, y - 2, x + 18, bottom + 2, -3750202}, new int[]{x - 1, y - 1, x + 19, y, -3750202}, new int[]{x - 1, bottom, x + 19, bottom + 1, -3750202}, new int[]{x, y - 2, x + 18, y - 1, -1}, new int[]{x - 1, y - 1, x, y, -1}, new int[]{x - 2, y, x - 1, bottom, -1}, new int[]{x, bottom + 1, x + 18, bottom + 2, -11184811}, new int[]{x + 18, bottom, x + 19, bottom + 1, -11184811}, new int[]{x + 19, y, x + 20, bottom, -11184811}};
                for (int[] edge : edges) {
                    context.method_25294(edge[0], edge[1], edge[2], edge[3], edge[4]);
                }
                for (int i = 0; i < count; i++) {
                    int slotY = y + (i * 18);
                    context.method_52706(class_1921::method_62277, class_2960.method_60656("container/slot"), x, slotY, 18, 18);
                    if (i < this.d.size()) {
                        class_1799 stack = this.d.get(i);
                        Epsilon.h().d().j().a(context, stack, x + 1, slotY + 1, 0, 1.0f, 1.0f, true);
                        if (MathUtil.a(event.f(), event.g(), x + 1, slotY + 1, 16.0f, 16.0f)) {
                            context.method_51740(class_1921.method_51785(), x + 1, slotY + 1, x + 17, slotY + 17, -2130706433, -2130706433, 0);
                            context.method_51446(aM_.field_1772, stack, event.f(), event.g());
                        }
                    }
                }
            }
        }
    }

    private void a(class_1703 handler, int slot, class_1713 action) {
        aM_.field_1724.field_3944.method_52787(new class_2813(handler.field_7763, handler.method_37421(), slot, 0, action, handler.method_34255().method_7972(), Int2ObjectMaps.emptyMap()));
        this.f = 0;
    }
}
