package aethereal.ui.element;

import aethereal.core.Epsilon;
import aethereal.core.InterfaceC0020Opcode;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.MathUtil;

import aethereal.render.Draw2DProcessor;

import aethereal.render.AnimationUtil;
import lombok.Generated;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class Button {
    private final AnimationUtil a = new AnimationUtil();
    private final float b;
    private final float c;
    private final String d;
    private final Runnable e;
    private float f;
    private float g;

    @Generated
    public AnimationUtil a() {
        return this.a;
    }

    @Generated
    public float b() {
        return this.b;
    }

    @Generated
    public float c() {
        return this.c;
    }

    @Generated
    public String d() {
        return this.d;
    }

    @Generated
    public Runnable e() {
        return this.e;
    }

    @Generated
    public float f() {
        return this.f;
    }

    @Generated
    public float g() {
        return this.g;
    }

    public Button(float width, float height, String label, Runnable action) {
        this.b = width;
        this.c = height;
        this.d = label;
        this.e = action;
    }

    public void a(float x, float y) {
        this.f = x;
        this.g = y;
    }

    public void a(class_332 context, int mouseX, int mouseY, float delta, float open) {
        this.a.a(this.e != null && MathUtil.a((double) mouseX, (double) mouseY, this.f, this.g, this.b, this.c));
        this.a.a(0.0f, 1.0f, 0.35f, EasingList.i, delta);
        float hover = Math.min(1.0f, this.a.c() / 0.9f);
        float scale = (0.85f + (0.15f * EasingList.s.ease(open))) * (1.0f + (0.03f * hover));
        class_4587 matrices = context.method_51448();
        float cx = this.f + (this.b / 2.0f);
        float cy = this.g + (this.c / 2.0f);
        matrices.method_22903();
        matrices.method_46416(cx, cy, 0.0f);
        matrices.method_22905(scale, scale, 1.0f);
        matrices.method_46416(-cx, -cy, 0.0f);
        Draw2DProcessor draw = Epsilon.h().d().i();
        draw.b(matrices, this.f, this.g, this.b, this.c, 8.0f, ColorUtil.a(11, 11, 13, InterfaceC0020Opcode.bN), open);
        draw.a(matrices, this.f, this.g, this.b, this.c, 8.0f, 0.5f, ColorUtil.a(255, 255, 255, (int) (hover * 20.0f * open)));
        if (this.d != null) {
            float time = (System.currentTimeMillis() % 3000) / 3000.0f;
            net.minecraft.class_5250 class_2561VarMethod_43470 = class_2561.method_43470("");
            for (int i = 0; i < this.d.length(); i++) {
                float wave = (float) ((Math.sin(((double) (time + ((i * 0.5f) / this.d.length()))) * 3.141592654293742d * 2.0d) * 0.5d) + 0.5d);
                int c = (int) (180.0f + (65.0f * wave * hover));
                class_2561VarMethod_43470.method_10852(class_2561.method_43470(String.valueOf(this.d.charAt(i))).method_10862(class_2583.field_24360.method_36139((c << 16) | (c << 8) | c)));
            }
            float labelW = Fonts.e.a(this.d, 8.0f);
            Fonts.e.a(matrices, class_2561VarMethod_43470, this.f + ((this.b - labelW) / 2.0f), this.g + ((this.c - 9.0f) / 2.0f), 8.0f, 0.0f, open);
        }
        matrices.method_22909();
    }
}
