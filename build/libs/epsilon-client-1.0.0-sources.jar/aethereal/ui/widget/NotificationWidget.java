package aethereal.ui.widget;

import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;
import aethereal.render.EasingList;
import aethereal.render.Fonts;

import aethereal.config.ThemeInfo;
import aethereal.core.GlobalEvent;
import aethereal.core.Interface;
import aethereal.event.BackendEvent;
import aethereal.event.DrawEvent;
import aethereal.event.PacketEvent;
import aethereal.notification.Notification;
import aethereal.ui.element.DragInfo;
import aethereal.ui.widget.Widget;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2775;
import net.minecraft.class_408;
import net.minecraft.class_746;
import net.minecraft.class_9334;
import aethereal.setting.BooleanSetting;

public class NotificationWidget extends Widget implements Interface {
    private final BooleanSetting f;
    private final BooleanSetting g;

    public NotificationWidget() {
        super(new DragInfo("Уведомления", 0.0f, 0.0f, 0.0f, 0.0f));
        this.f = new BooleanSetting("Оповещать о поднятии донат-предметов", true);
        this.g = new BooleanSetting("Обновления и уведомления друзей", true);
        j().a(this);
        j().a(1);
        a(this.g, this.f);
    }

    @Override
    public void a(GlobalEvent event) {
        d().a((aM_.field_1755 instanceof class_408) || !Epsilon.h().d().m().b().isEmpty());
        super.a(event);
    }

    @Override
    public void a(DrawEvent event) {
        float fA;
        d().a(0.0f, 1.0f, 0.3f, EasingList.g, event.g());
        float contentY = j().b();
        for (Notification notification : Epsilon.h().d().m().b()) {
            float animation = notification.a().c() * a();
            if (animation > 0.0f) {
                Object message = notification.c();
                if (message instanceof class_2561) {
                    class_2561 value = (class_2561) message;
                    fA = Fonts.e.a(value, this.e);
                } else {
                    fA = Fonts.e.a(String.valueOf(message), this.e);
                }
                float width = 17.5f + fA + 4.0f;
                float x = (aM_.method_22683().method_4486() - width) / 2.0f;
                int color = notification.e() == -1 ? Epsilon.h().d().o().a(ThemeInfo.PRIMARY).a() : notification.e();
                Object objD = notification.d();
                if (objD instanceof class_1799) {
                    class_1799 stack = (class_1799) objD;
                    a(event, x, contentY, stack, message, width, animation, color);
                } else {
                    a(event, x, contentY, (String) notification.d(), message, width, animation, color);
                }
                j().a(x);
                j().c(width);
                j().d(this.d);
                contentY += (this.d + 3.5f) * animation;
            }
        }
        super.a(event);
    }

    @Override
    public void a(PacketEvent event) {
        if (this.f.c().booleanValue() && event.c()) {
            class_2775 class_2775VarD = (class_2775) event.d();
            if (class_2775VarD instanceof class_2775) {
                class_2775 itemPickupAnimationS2CPacket = class_2775VarD;
                class_746 class_746VarMethod_8469 = (class_746) aM_.field_1687.method_8469(itemPickupAnimationS2CPacket.method_11912());
                if (class_746VarMethod_8469 instanceof class_1657) {
                    class_746 class_746Var = (class_746) (class_1657) class_746VarMethod_8469;
                    class_1542 class_1542VarMethod_8469 = (class_1542) aM_.field_1687.method_8469(itemPickupAnimationS2CPacket.method_11915());
                    if (class_1542VarMethod_8469 instanceof class_1542) {
                        class_1542 itemEntity = class_1542VarMethod_8469;
                        if (class_746Var != aM_.field_1724 && !itemEntity.method_6983().method_7964().getString().contains("Упс.") && ((itemEntity.method_6983().method_57826(class_9334.field_49631) && itemEntity.method_6983().method_57826(class_9334.field_49632)) || itemEntity.method_6983().method_31574(class_1802.field_8367))) {
                            Epsilon.h().d().m().a(new Notification(itemEntity.method_6983().method_7972(), class_746Var.method_5477().method_27661().method_27693(" подобрал ").method_10852(itemEntity.method_6983().method_7964()).method_27693(itemPickupAnimationS2CPacket.method_11913() > 1 ? " x" + itemPickupAnimationS2CPacket.method_11913() : ""), 1500));
                        }
                    }
                }
            }
        }
        super.a(event);
    }

    @Override
    public void a(BackendEvent event) {
        String message = event.d().a().a(event.d().c(), "message");
        if ("friend".equals(event.d().b()) && this.g.c().booleanValue() && message != null) {
            Epsilon.h().d().m().a(new Notification("o", message, 5000));
        }
        if ("application".equals(event.d().b()) && message != null) {
            Epsilon.h().d().m().a(new Notification("o", message, 15000));
        }
        super.a(event);
    }
}
