package aethereal.ui.widget;

import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;
import aethereal.core.InterfaceC0020Opcode;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.MathUtil;

import aethereal.config.ThemeInfo;
import aethereal.core.GlobalEvent;
import aethereal.core.Interface;
import aethereal.event.DrawEvent;
import aethereal.mixin.IStatusEffectInstance;
import aethereal.notification.Notification;
import aethereal.ui.element.DragInfo;
import aethereal.ui.widget.Widget;

import aethereal.setting.BooleanSetting;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2561;
import net.minecraft.class_408;
import net.minecraft.class_4081;
import org.joml.Vector4f;

public class PotionWidget extends Widget implements Interface {
    private final BooleanSetting f;
    private final class_1293 g;

    public PotionWidget() {
        super(new DragInfo("Зелья", 0.0f, 0.0f, 0.0f, 0.0f));
        this.f = new BooleanSetting("Боковое отображение", false);
        this.g = new class_1293(class_1294.field_5904, 1200, 0);
        j().a(this);
        a(this.f);
    }

    @Override
    public void a(DrawEvent event) {
        d().a(0.0f, 1.0f, 0.3f, EasingList.g, event.g());
        Iterator<class_1293> it = k().iterator();
        while (it.hasNext()) {
            ((IStatusEffectInstance) (Object) it.next()).getAnimation().a(0.0f, 1.0f, 0.3f, EasingList.g, event.g());
        }
        if (this.f.c().booleanValue()) {
            d(event);
        } else {
            c(event);
        }
        j().a(this.f.c().booleanValue() ? 2 : 0);
    }

    private void c(DrawEvent event) {
        float x = j().a();
        float y = j().b();
        float targetWidth = 14.5f + Fonts.e.a("Potion-list", this.e) + 5.0f + 2.0f;
        float contentY = y + this.d + 3.0f;
        boolean active = false;
        Iterator<class_1293> it = k().iterator();
        while (it.hasNext()) {
            IStatusEffectInstance iStatusEffectInstance = (IStatusEffectInstance) (Object) it.next();
            if (iStatusEffectInstance.getAnimation().c() > 0.0f) {
                active = true;
                String name = class_2561.method_43471(((class_1291) iStatusEffectInstance.getEffectType().comp_349()).method_5567()).getString() + " " + (iStatusEffectInstance.getAmplifier() + 1);
                targetWidth = Math.max(targetWidth, 19.0f + Fonts.e.a(name, 6.5f) + 8.0f + Fonts.e.a(iStatusEffectInstance.getDuration() > 1000000 ? "∞" : ((iStatusEffectInstance.getDuration() / 20) / 60) + ":" + String.format("%02d", Integer.valueOf((iStatusEffectInstance.getDuration() / 20) % 60)), 6.5f) + 5.0f + 2.0f);
            }
        }
        float width = MathUtil.c(j().f(), targetWidth, 0.5f);
        j().c(width);
        if (a() > 0.0f) {
            a(event, "E", "Potion-list", width, a());
        }
        Iterator<class_1293> it2 = k().iterator();
        while (it2.hasNext()) {
            IStatusEffectInstance iStatusEffectInstance2 = (IStatusEffectInstance) (Object) it2.next();
            float animation = iStatusEffectInstance2.getAnimation().c() * a();
            if (animation > 0.0f) {
                String name2 = class_2561.method_43471(((class_1291) iStatusEffectInstance2.getEffectType().comp_349()).method_5567()).getString() + " " + (iStatusEffectInstance2.getAmplifier() + 1);
                int seconds = iStatusEffectInstance2.getDuration() / 20;
                String duration = iStatusEffectInstance2.getDuration() > 1000000 ? "∞" : (seconds / 60) + ":" + String.format("%02d", Integer.valueOf(seconds % 60));
                float offsetX = (-8.0f) * (1.0f - animation);
                float offsetY = -(1.0f - animation);
                float drawY = contentY + offsetY;
                float durationWidth = Fonts.e.a(duration, 6.5f);
                float textY = (drawY + ((11.5f - Fonts.e.a(6.5f)) / 2.0f)) - 0.5f;
                a(event, x + offsetX, drawY, width, 11.5f, false, animation);
                a(event, x + offsetX + 15.0f, drawY, 11.5f, animation);
                event.e().a(event.i(), aM_.method_18505().method_18663(iStatusEffectInstance2.getEffectType()), x + offsetX + 5.0f, drawY + 2.0f, 0.0f, 0.4f, animation);
                Fonts.e.a(event.h(), name2, x + offsetX + 19.0f, textY, 6.5f, ColorUtil.a(((class_1291) iStatusEffectInstance2.getEffectType().comp_349()).method_18792() == class_4081.field_18272 ? ColorUtil.a(255, InterfaceC0020Opcode.cG, InterfaceC0020Opcode.cG, 255) : -1, animation));
                Fonts.e.a(event.h(), duration, ((((x + offsetX) + width) - 5.0f) - durationWidth) - 1.0f, textY, 6.5f, ColorUtil.a(-1, 0.55f * animation));
                contentY += 13.5f * animation;
            }
        }
        j().d(active ? (contentY - y) - 2.0f : this.d);
        super.a(event);
    }

    private void d(DrawEvent event) {
        int primary = Epsilon.h().d().o().a(ThemeInfo.PRIMARY).a();
        int visibleCount = 0;
        Iterator<class_1293> it = k().iterator();
        while (it.hasNext()) {
            if (((IStatusEffectInstance) (Object) it.next()).getAnimation().c() > 0.0f) {
                visibleCount++;
            }
        }
        float posY = (aM_.method_22683().method_4502() - ((visibleCount * 26.0f) + ((visibleCount - 1) * 2.0f))) / 2.0f;
        float contentY = posY;
        float maxWidth = 0.0f;
        Iterator<class_1293> it2 = k().iterator();
        while (it2.hasNext()) {
            IStatusEffectInstance iStatusEffectInstance = (IStatusEffectInstance) (Object) it2.next();
            float animation = iStatusEffectInstance.getAnimation().c() * a();
            if (animation > 0.0f) {
                boolean harmful = ((class_1291) iStatusEffectInstance.getEffectType().comp_349()).method_18792() == class_4081.field_18272;
                String name = class_2561.method_43471(((class_1291) iStatusEffectInstance.getEffectType().comp_349()).method_5567()).getString() + " " + (iStatusEffectInstance.getAmplifier() + 1);
                int seconds = iStatusEffectInstance.getDuration() / 20;
                String duration = iStatusEffectInstance.getDuration() > 1000000 ? "∞" : (seconds / 60) + ":" + String.format("%02d", Integer.valueOf(seconds % 60));
                float textWidth = Math.max(Fonts.e.a(name, 7.0f), Fonts.e.a(duration, 6.0f));
                float width = 18.5f + textWidth + 8.0f;
                float drawX = 3.0f - (width * (1.0f - animation));
                float textX = drawX + 13.5f + 6.0f;
                a(event, drawX, contentY, width, 24.0f, true, animation);
                event.e().a(event.i(), aM_.method_18505().method_18663(iStatusEffectInstance.getEffectType()), drawX + 3.5f, contentY + 5.75f, 0.0f, 0.6944444f, animation);
                Fonts.e.a(event.h(), name, textX, contentY + 3.5f, 7.0f, ColorUtil.a(harmful ? ColorUtil.a(215, 76, 76, 255) : -1, animation));
                Fonts.e.a(event.h(), duration, textX, contentY + 13.0f, 6.0f, ColorUtil.a(-1, 0.55f * animation));
                int initialDuration = iStatusEffectInstance.getInitialDuration();
                float progress = initialDuration <= 0 ? 1.0f : Math.min(1.0f, iStatusEffectInstance.getDuration() / initialDuration);
                int accent = harmful ? ColorUtil.a(215, 76, 76, 255) : primary;
                event.d().a(event.h(), drawX + 2.0f, (contentY + 24.0f) - 1.5f, width - 4.0f, 1.5f, new Vector4f(0.0f, 0.0f, 1.0f, 1.0f), ColorUtil.a(accent, 0.15f * animation));
                event.d().a(event.h(), drawX + 2.0f, (contentY + 24.0f) - 1.5f, (width - 4.0f) * progress, 1.5f, new Vector4f(0.0f, 0.0f, 1.0f, 1.0f), ColorUtil.a(accent, animation));
                maxWidth = Math.max(maxWidth, width);
                contentY += 28.0f * animation;
            }
        }
        j().a(3.0f);
        j().b(posY);
        j().c(maxWidth);
        j().d((contentY - posY) - 2.0f);
        super.a(event);
    }

    @Override
    public void a(GlobalEvent event) {
        boolean visible = aM_.field_1755 instanceof class_408;
        for (class_1293 effect : k()) {
            if (!effect.method_5579().equals(class_1294.field_5925)) {
                ((IStatusEffectInstance) effect).getAnimation().a(effect == this.g ? aM_.field_1755 instanceof class_408 : effect.method_5584() > 20);
                if (((IStatusEffectInstance) effect).getAnimation().c() > 0.0d) {
                    visible = true;
                }
                if (effect != this.g && effect.method_5584() == 100 && (effect.method_5579().equals(class_1294.field_5910) || effect.method_5579().equals(class_1294.field_5904) || effect.method_5579().equals(class_1294.field_5914) || effect.method_5579().equals(class_1294.field_5905))) {
                    Epsilon.h().d().m().a(new Notification("E", class_2561.method_43470("Эффект ").method_10852(class_2561.method_43471(((class_1291) effect.method_5579().comp_349()).method_5567()).method_27693(" " + (effect.method_5578() + 1)).method_27694(style -> {
                        return style.method_36139(Epsilon.h().d().o().a(ThemeInfo.PRIMARY).a());
                    })).method_10852(class_2561.method_43470(" заканчивается")), 2500));
                }
            }
        }
        d().a(visible);
        super.a(event);
    }

    private List<class_1293> k() {
        List<class_1293> effects = new ArrayList<>((Collection<? extends class_1293>) aM_.field_1724.method_6026());
        boolean empty = effects.stream().allMatch(effect -> {
            return effect.method_5579().equals(class_1294.field_5925);
        });
        if (this.f.c().booleanValue() && empty && ((aM_.field_1755 instanceof class_408) || ((IStatusEffectInstance) (Object) this.g).getAnimation().c() > 0.0f)) {
            effects.add(this.g);
        }
        effects.sort(Comparator.comparingInt(effect2 -> {
            if (effect2.method_5579().equals(class_1294.field_5910)) {
                return 0;
            }
            return effect2.method_5579().equals(class_1294.field_5911) ? 1 : 2;
        }));
        return effects;
    }
}
