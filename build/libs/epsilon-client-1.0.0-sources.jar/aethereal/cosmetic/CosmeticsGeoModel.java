package aethereal.cosmetic;

import net.minecraft.class_2960;
import software.bernie.geckolib.animation.Animation;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoRenderer;

public class CosmeticsGeoModel extends GeoModel<Cosmetic> {
    private final Cosmetic cosmetic;

    public CosmeticsGeoModel(Cosmetic cosmetic) {
        this.cosmetic = cosmetic;
    }

    @Override
    public class_2960 getModelResource(Cosmetic cosmetic, GeoRenderer<Cosmetic> renderer) {
        return null;
    }

    @Override
    public class_2960 getTextureResource(Cosmetic cosmetic, GeoRenderer<Cosmetic> renderer) {
        return cosmetic.getImage();
    }

    @Override
    public class_2960 getAnimationResource(Cosmetic cosmetic) {
        return null;
    }

    @Override
    public BakedGeoModel getBakedModel(class_2960 resource) {
        BakedGeoModel model = this.cosmetic.getBakedModel();
        getAnimationProcessor().setActiveModel(model);
        return model;
    }

    @Override
    public Animation getAnimation(Cosmetic animatable, String name) {
        if (this.cosmetic.getBakedAnimations() == null) {
            return null;
        }
        return this.cosmetic.getBakedAnimations().getAnimation(name);
    }
}
