package aethereal.cosmetic;

import aethereal.cosmetic.Cosmetic;

import java.util.function.Function;
import net.minecraft.class_4587;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_7833;

public enum CosmeticsCategory {
    f1((class_591 model) -> {
        return model.field_3391;
    }),
    f2((class_591 model2) -> {
        return model2.field_3391;
    }),
    f3_((class_591 model3) -> {
        return model3.field_3398;
    }),
    f4((class_591 model4) -> {
        return model4.field_3398;
    }),
    f5((class_591 model5) -> {
        return model5.field_3391;
    }),
    f6((class_591 model6) -> {
        return model6.field_3391;
    });

    private final Function<class_591, class_630> part;

    CosmeticsCategory(Function<class_591, class_630> part) {
        this.part = part;
    }

    public void transform(class_4587 matrices, class_591 model, Cosmetic cosmetic) {
        this.part.apply(model).method_22703(matrices);
        matrices.method_22907(class_7833.field_40718.rotationDegrees(180.0f));
        matrices.method_22905(cosmetic.getScale(), cosmetic.getScale(), cosmetic.getScale());
        matrices.method_46416(cosmetic.getOffset().x, cosmetic.getOffset().y, cosmetic.getOffset().z());
    }
}
