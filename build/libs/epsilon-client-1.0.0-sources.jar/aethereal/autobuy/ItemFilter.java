package aethereal.autobuy;


import net.minecraft.class_1799;

public interface ItemFilter {
    boolean a(class_1799 class_1799Var);
}
