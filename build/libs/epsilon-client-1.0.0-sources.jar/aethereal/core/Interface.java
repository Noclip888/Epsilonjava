package aethereal.core;








import static aethereal.core.Interface.aM_;

import net.minecraft.class_310;

public interface Interface {
    public static final class_310 aM_ = class_310.method_1551();
}
