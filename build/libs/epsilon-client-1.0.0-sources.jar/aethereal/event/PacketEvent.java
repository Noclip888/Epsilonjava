package aethereal.event;

import aethereal.core.Event;
import aethereal.core.IEvent;

import lombok.Generated;
import net.minecraft.class_2596;

public class PacketEvent extends Event implements IEvent {
    public enum Type {
        SEND,
        RECEIVE
    }

    @Generated
    public class_2596<?> d() {
        return this.packet;
    }

    @Generated
    public Type e() {
        return this.type;
    }

    private final class_2596<?> packet;
    private final Type type;

    public PacketEvent(class_2596<?> packet, Type type) {
        this.packet = packet;
        this.type = type;
    }

    public boolean b() {
        return this.type == Type.SEND;
    }

    public boolean c() {
        return this.type == Type.RECEIVE;
    }
}
