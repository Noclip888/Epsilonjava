package aethereal.mixin;


import aethereal.render.AnimationUtil;
import net.minecraft.class_1291;
import net.minecraft.class_6880;

public interface IStatusEffectInstance {
    AnimationUtil getAnimation();

    int getInitialDuration();

    void setInitialDuration(int i);

    int getDuration();

    int getAmplifier();

    class_6880<class_1291> getEffectType();
}
