package aethereal.handler;

import aethereal.handler.Handler_2;
import aethereal.ui.shader.GradientUtil;
import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;
import aethereal.util.ChatUtil;
import aethereal.util.MathUtil;

import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.event.ClickEvent;
import aethereal.event.ContainerEvent;
import aethereal.event.TickEvent;
import aethereal.handler.BaseHandler;

import it.unimi.dsi.fastutil.ints.Int2ObjectMaps;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.Generated;
import net.minecraft.class_1109;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_476;
import net.minecraft.class_5250;
import platform.inject.accessors.HandledScreenAccessor;

@Handler_2
public class ANFindHandler extends BaseHandler implements Interface {
    private final List<a> b = List.of(new a("Команды х1"), new a("Команды х2"), new a("Команды х3"), new a("Команды х5"), new a("Команды х10"));
    private boolean c;
    private boolean d;
    private Phase e;
    private int f;

    enum Phase {
        SELECT_MODE,
        SELECT_TYPE,
        COLLECT
    }

    @EventTarget
    public void a(ContainerEvent event) {
        this.c = false;
        if (event.h() == ContainerEvent.Phase.POST) {
            if (event.b().method_25440().getString().contains("☬ Выберите режим:") || event.b().method_25440().getString().contains("☬ Выберите тип режима:")) {
                HandledScreenAccessor screen = (HandledScreenAccessor) event.b();
                float x = (screen.getX() + screen.getBackgroundWidth()) - 17;
                float y = screen.getY() + 5;
                this.c = MathUtil.a(event.f(), event.g(), x, y, 10.0f, 10.0f);
                Epsilon.h().d().i().a(event.d().method_51448(), class_2960.method_60655("epsilon", this.c ? "pictures/minecraft/join_button_hovered.png" : "pictures/minecraft/join_button.png"), x, y, 10.0f, 10.0f, 0.0f, -1);
                if (this.c) {
                    event.d().method_51434(event.b().method_64506(), List.of(class_2561.method_30163("Авто-поиск анархии с наименьшим онлайном")), event.f(), event.g());
                }
            }
        }
    }

    @EventTarget
    public void a(ClickEvent event) {
        if (event.b() && this.c) {
            class_465<?> class_465Var = (class_465<?>) aM_.field_1755;
            if (class_465Var instanceof class_465) {
                class_465<?> screen = class_465Var;
                if (screen.method_25440().getString().contains("☬ Выберите режим:") || screen.method_25440().getString().contains("☬ Выберите тип режима:")) {
                    this.d = !this.d;
                    if (this.d) {
                        this.e = Phase.SELECT_MODE;
                        this.f = 0;
                        this.b.forEach((v0) -> {
                            v0.a();
                        });
                    }
                    aM_.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0f));
                }
            }
        }
    }

    @EventTarget
    public void a(TickEvent event) {
        if (this.d) {
            class_437 class_437Var = aM_.field_1755;
            if (class_437Var instanceof class_476) {
                class_476 screen = (class_476) class_437Var;
                a mode = this.b.get(this.f);
                switch (this.e) {
                    case SELECT_MODE:
                        if (a(screen, "Анархия 1.21.11")) {
                            this.e = Phase.SELECT_TYPE;
                        }
                        break;
                    case SELECT_TYPE:
                        if (a(screen, mode.a)) {
                            this.e = Phase.COLLECT;
                        }
                        break;
                    case COLLECT:
                        a(screen, mode);
                        break;
                }
            }
            this.d = false;
        }
    }

    private void a(class_476 screen, a mode) {
        boolean selected = false;
        int bestOnline = Integer.MAX_VALUE;
        String bestServer = null;
        for (class_1735 slot : screen.method_17577().field_7761) {
            String name = slot.method_7677().method_7964().getString();
            if (slot.method_7677().method_7958() && name.contains(mode.a)) {
                selected = true;
            }
            if (name.contains("Анархия-")) {
                for (class_2561 line : slot.method_7677().method_7950(class_1792.class_9635.field_51353, aM_.field_1724, class_1836.field_41070)) {
                    Matcher matcher = Pattern.compile("Онлайн режима: (\\d+)").matcher(line.getString());
                    if (matcher.find()) {
                        int online = Integer.parseInt(matcher.group(1));
                        if (online >= bestOnline) {
                            break;
                        }
                        bestOnline = online;
                        bestServer = name.replaceAll("§.", "");
                        break;
                    }
                }
            }
        }
        if (selected && bestServer != null) {
            mode.c = bestOnline;
            mode.b = bestServer;
            int i = this.f + 1;
            this.f = i;
            if (i >= this.b.size()) {
                a();
            } else {
                this.e = Phase.SELECT_TYPE;
            }
        }
    }

    private void a() {
        this.d = false;
        this.b.stream().filter(mode -> {
            return mode.b != null;
        }).min(Comparator.comparingInt(mode2 -> {
            return mode2.c;
        })).ifPresent(best -> {
            String anarchy = best.b.replace("»", "").replace("Анархия-", "").trim();
            if (!anarchy.isEmpty()) {
                class_5250 hover = GradientUtil.a("Минимальный онлайн по командам:\n", -7620097, -11503416, 1, 5.0f);
                this.b.stream().filter(mode3 -> {
                    return mode3.b != null;
                }).forEach(mode4 -> {
                    hover.method_10852(class_2561.method_43470("§7• §f" + mode4.a.replace("Команды ", "") + ": " + mode4.b.trim() + " — " + mode4.c + " игроков\n"));
                });
                ChatUtil.a(class_2561.method_43470("§a✔ §7Успешно подключился к анархии §a#" + anarchy + "§7, с онлайном §a" + best.c + "§7 — ").method_10852(ChatUtil.a((Object) "§c[Подробнее]", (class_2561) hover)));
                aM_.field_1724.field_3944.method_52787(new class_2815(aM_.field_1724.field_7512.field_7763));
                aM_.field_1724.field_3944.method_45730("an" + anarchy);
            }
        });
    }

    private boolean a(class_476 screen, String contains) {
        for (class_1735 slot : screen.method_17577().field_7761) {
            if (slot.method_7677().method_7964().getString().contains(contains)) {
                aM_.field_1724.field_3944.method_52787(new class_2813(screen.method_17577().field_7763, screen.method_17577().method_37421(), slot.field_7874, 0, class_1713.field_7790, screen.method_17577().method_34255().method_7972(), Int2ObjectMaps.emptyMap()));
                return true;
            }
        }
        return false;
    }

    public static class a {
        final String a;
        String b;
        int c;

        @Generated
        public String b() {
            return this.a;
        }

        @Generated
        public String c() {
            return this.b;
        }

        @Generated
        public int d() {
            return this.c;
        }

        public a(String title) {
            this.a = title;
        }

        public void a() {
            this.b = null;
            this.c = -1;
        }
    }
}
