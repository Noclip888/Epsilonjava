package aethereal.command;

import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.util.ChatUtil;

import aethereal.command.BaseCommand;
import aethereal.command.Command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2828;

@Command(a = "vclip")
public class VClipCommand extends BaseCommand {
    @Override
    public void a(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(a("up").executes(context -> {
            float offset = a(true);
            if (offset != 0.0f) {
                a(offset);
                ChatUtil.a((Object) "Вы были успешно подняты по Y");
                return 1;
            }
            return 1;
        })).then(a("down").executes(context2 -> {
            float offset = a(false);
            if (offset != 0.0f) {
                a(offset);
                ChatUtil.a((Object) "Вы были успешно опущены по Y");
                return 1;
            }
            return 1;
        })).then(f("число").executes(context3 -> {
            float offset = c(context3, "число");
            a(offset);
            ChatUtil.a((Object) ("Вы были успешно перемещены на " + offset + " по Y"));
            return 1;
        })).executes(context4 -> {
            ChatUtil.a((Object) "Использование: .vclip <число|up|down>");
            return 1;
        });
    }

    private void a(float yOffset) {
        double x = aM_.field_1724.method_23317();
        double y = aM_.field_1724.method_23318() + ((double) yOffset);
        double z = aM_.field_1724.method_23321();
        aM_.field_1724.field_3944.method_52787(new class_2828.class_2829(x, y, z, aM_.field_1724.method_24828(), aM_.field_1724.field_5976));
        aM_.field_1724.method_5814(x, y, z);
    }

    private float a(boolean up) {
        class_2338 playerPos = aM_.field_1724.method_24515();
        int startY = up ? 25 : -1;
        int endY = up ? 255 : -255;
        int step = up ? 1 : -1;
        int i = startY;
        while (true) {
            int offset = i;
            if (offset != endY) {
                class_2338 targetPos = playerPos.method_10069(0, offset, 0);
                class_2338 nextPos = playerPos.method_10069(0, offset + step, 0);
                if (aM_.field_1687.method_8320(targetPos).method_26215() && aM_.field_1687.method_8320(nextPos).method_26215()) {
                    return offset + (up ? 1.0f : -1.0f);
                }
                if (up || !aM_.field_1687.method_8320(targetPos).method_27852(class_2246.field_9987)) {
                    i = offset + step;
                } else {
                    ChatUtil.a((Object) (String.valueOf(class_124.field_1080) + "Телепортация в данное место невозможно"));
                    return 0.0f;
                }
            } else {
                return 0.0f;
            }
        }
    }
}
