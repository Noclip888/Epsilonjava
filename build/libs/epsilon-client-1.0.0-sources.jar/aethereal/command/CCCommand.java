package aethereal.command;

import aethereal.friend.FriendConstructor;
import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;
import aethereal.util.ServerUtil;

import aethereal.command.BaseCommand;
import aethereal.command.Command;
import aethereal.core.EventTarget;
import aethereal.event.TickEvent;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import net.minecraft.class_640;

@Command(a = "ccc")
public class CCCommand extends BaseCommand {
    private int c;

    @Override
    public void a(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            if (ServerUtil.a.a() || ServerUtil.d.a()) {
                StringBuilder name = new StringBuilder();
                for (int i = 0; i < 3 + ((int) (Math.random() * 3.0d)); i++) {
                    name.append("абвгдежзийклмнопрстуфхцчшщъыьэюяАБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt((int) (Math.random() * ((double) "абвгдежзийклмнопрстуфхцчшщъыьэюяАБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".length()))));
                }
                aM_.field_1724.field_3944.method_45729("/clan create " + String.valueOf(name));
                this.c = aM_.field_1724.field_6012 + 2;
                return 1;
            }
            return 1;
        });
    }

    @EventTarget
    public void a(TickEvent eventTick) {
        if (this.c >= aM_.field_1724.field_6012) {
            for (FriendConstructor constructor : Epsilon.h().d().e().e()) {
                class_640 entry = (class_640) aM_.field_1724.field_3944.method_2880().stream().filter(listEntry -> {
                    return listEntry.method_2966().getName().equalsIgnoreCase(constructor.a());
                }).findFirst().orElse(null);
                if (entry != null && !constructor.a().equals(aM_.method_1548().method_1676())) {
                    aM_.field_1724.field_3944.method_45729("/clan invite " + constructor.a());
                }
            }
            this.c = -3;
        }
    }
}
