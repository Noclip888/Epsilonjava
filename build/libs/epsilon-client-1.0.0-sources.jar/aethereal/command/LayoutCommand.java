package aethereal.command;

import aethereal.core.Interface;

import platform.inject.accessors.SlotAccessor;
import static aethereal.core.Interface.aM_;
import aethereal.core.Epsilon;
import aethereal.util.ChatUtil;

import aethereal.command.BaseCommand;
import aethereal.command.Command;
import aethereal.core.EventTarget;
import aethereal.event.TickEvent;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import lombok.Generated;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2172;
import net.minecraft.class_2371;
import net.minecraft.class_2815;

@Command(a = "layout")
public class LayoutCommand extends BaseCommand {
    private final List<a> c = new ArrayList();
    private final List<a> d = new ArrayList();
    private int e;

    @Generated
    public List<a> c() {
        return this.c;
    }

    private void d() {
        Epsilon.h().d().t().b("default");
    }

    private void a(List<a> layout) {
        this.d.clear();
        this.d.addAll(layout);
        this.e = 0;
    }

    @Override
    public void a(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(a("save").executes(context -> {
            ChatUtil.a((Object) "Использование: .layout save <название>");
            return 1;
        }).then(d("название").executes(context2 -> {
            String name = a((CommandContext<class_2172>) context2, "название");
            List<a> layouts = this.c;
            layouts.removeIf(layout -> {
                return layout.a().equalsIgnoreCase(name);
            });
            for (class_1735 slot : aM_.field_1724.field_7498.field_7761) {
                if (slot.field_7871 == aM_.field_1724.method_31548() && !slot.method_7677().method_7960()) {
                    layouts.add(new a(name, slot.method_7677().method_7972(), slot.field_7874));
                }
            }
            d();
            ChatUtil.a((Object) ("Раскладка &c" + name + " &7сохранена."));
            return 1;
        }))).then(a("load").executes(context3 -> {
            ChatUtil.a((Object) "Использование: .layout load <название>");
            return 1;
        }).then(d("название").suggests(a(this::c, (v0) -> {
            return v0.a();
        })).executes(context4 -> {
            String name = a((CommandContext<class_2172>) context4, "название");
            List<a> target = this.c.stream().filter(layout -> {
                return layout.a().equalsIgnoreCase(name);
            }).toList();
            if (target.isEmpty()) {
                ChatUtil.a((Object) ("Раскладка &c" + name + " &7не найдена"));
                return 1;
            }
            a(target);
            return 1;
        }))).then(a("remove").executes(context5 -> {
            ChatUtil.a((Object) "Использование: .layout remove <название>");
            return 1;
        }).then(d("название").suggests(a(this::c, (v0) -> {
            return v0.a();
        })).executes(context6 -> {
            String name = a((CommandContext<class_2172>) context6, "название");
            List<a> layouts = this.c;
            if (layouts.stream().noneMatch(layout -> {
                return layout.a().equalsIgnoreCase(name);
            })) {
                ChatUtil.a((Object) ("Раскладка &c" + name + " &7не найдена"));
                return 1;
            }
            layouts.removeIf(layout2 -> {
                return layout2.a().equalsIgnoreCase(name);
            });
            d();
            ChatUtil.a((Object) ("Раскладка &c" + name + " &7удалена"));
            return 1;
        }))).then(a("list").executes(context7 -> {
            List<a> layouts = this.c;
            if (layouts.isEmpty()) {
                ChatUtil.a((Object) "Список раскладок пуст.");
                return 1;
            }
            ChatUtil.a((Object) "Сохраненные раскладки:");
            layouts.stream().map((v0) -> {
                return v0.a();
            }).distinct().forEach(name -> {
                ChatUtil.a((Object) ("— &c" + name));
            });
            return 1;
        })).then(a("clear").executes(context8 -> {
            this.c.clear();
            d();
            ChatUtil.a((Object) "Раскладки очищены.");
            return 1;
        })).executes(context9 -> {
            ChatUtil.a((Object) "Использование: .layout <save|load|remove|list|clear> <название>");
            return 1;
        });
    }

    @EventTarget
    public void a(TickEvent event) {
        if (!this.d.isEmpty()) {
            int i = this.e;
            this.e = i - 1;
            if (i > 1) {
                return;
            }
            this.e = 2;
            class_2371 class_2371Var = aM_.field_1724.field_7498.field_7761;
            List<String> missing = new ArrayList<>();
            for (a info : this.d) {
                class_1735 target = (class_1735) class_2371Var.get(info.c());
                class_1792 item = info.b().method_7909();
                if (target.method_7677().method_7909() != item) {
                    @SuppressWarnings("unchecked")
                    List<class_1735> slotList = (List<class_1735>) (List<?>) class_2371Var;
                    class_1735 source = slotList.stream()
                            .filter(slot -> ((platform.inject.accessors.SlotAccessor) slot).getInventory() == aM_.field_1724.method_31548())
                            .filter(slot2 -> slot2.method_7677().method_7909() == item)
                            .filter(slot3 -> this.d.stream().noneMatch(other -> other.c() == slot3.field_7874 && other.b().method_7909() == slot3.method_7677().method_7909()))
                            .findFirst().orElse(null);
                    if (source != null) {
                        int hotbar = (source.field_7874 == 36 || target.field_7874 == 36) ? (source.field_7874 == 37 || target.field_7874 == 37) ? 2 : 1 : 0;
                        aM_.field_1761.method_2906(aM_.field_1724.field_7498.field_7763, source.field_7874, hotbar, class_1713.field_7791, aM_.field_1724);
                        aM_.field_1761.method_2906(aM_.field_1724.field_7498.field_7763, target.field_7874, hotbar, class_1713.field_7791, aM_.field_1724);
                        aM_.field_1761.method_2906(aM_.field_1724.field_7498.field_7763, source.field_7874, hotbar, class_1713.field_7791, aM_.field_1724);
                        if (this.d.stream().noneMatch(other -> {
                            return ((class_1735) class_2371Var.get(other.c())).method_7677().method_7909() != other.b().method_7909();
                        })) {
                            aM_.field_1724.field_3944.method_52787(new class_2815(aM_.field_1724.field_7498.field_7763));
                            this.d.clear();
                            return;
                        }
                        return;
                    }
                    String name = info.b().method_7964().getString();
                    if (!missing.contains(name)) {
                        missing.add(name);
                    }
                }
            }
            if (missing.isEmpty()) {
                ChatUtil.a((Object) "Раскладка разложена.");
            } else {
                ChatUtil.a((Object) "Раскладка разложена, не хватило:");
                Iterator<String> it = missing.iterator();
                while (it.hasNext()) {
                    ChatUtil.a((Object) ("- &c" + it.next()));
                }
            }
            this.d.clear();
        }
    }

    public static class a {
        private final String a;
        private final class_1799 b;
        private final int c;

        @Generated
        public a(String name, class_1799 stack, int slotId) {
            this.a = name;
            this.b = stack;
            this.c = slotId;
        }

        @Generated
        public String a() {
            return this.a;
        }

        @Generated
        public class_1799 b() {
            return this.b;
        }

        @Generated
        public int c() {
            return this.c;
        }
    }
}
