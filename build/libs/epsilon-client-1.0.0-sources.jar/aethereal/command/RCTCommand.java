package aethereal.command;

import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.util.ServerUtil;

import aethereal.command.BaseCommand;
import aethereal.command.Command;
import aethereal.core.EventTarget;
import aethereal.event.TickEvent;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import lombok.Generated;
import net.minecraft.class_2172;

@Command(a = "rct")
public class RCTCommand extends BaseCommand {
    private int c = -1;

    @Generated
    public void b(int anarchy) {
        this.c = anarchy;
    }

    @Generated
    public int f() {
        return this.c;
    }

    @Override
    public void a(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            c();
            return 1;
        }).then(e("номер").executes(context2 -> {
            a(b((CommandContext<class_2172>) context2, "номер"));
            return 1;
        }));
    }

    public void c() {
        a(0);
    }

    public void a(int number) {
        this.c = number;
    }

    public void d() {
        this.c = -1;
    }

    public boolean e() {
        return this.c >= 0;
    }

    @EventTarget
    public void a(TickEvent eventTick) {
        int iB;
        if (e()) {
            if (ServerUtil.a.a()) {
                iB = ServerUtil.a.d();
            } else {
                iB = ServerUtil.d.a() ? ServerUtil.d.b() : -1;
            }
            int anarchy = iB;
            if (anarchy == -1 && this.c > 0) {
                if ((ServerUtil.a.a() || ServerUtil.d.a()) && aM_.field_1724.field_6012 % 20 == 0) {
                    aM_.field_1724.field_3944.method_45730("an" + this.c);
                    d();
                    return;
                }
                return;
            }
            if (aM_.field_1724.field_6012 % 2 == 0) {
                if (anarchy == -1) {
                    b(-1);
                    return;
                }
                if (this.c == 0) {
                    b(anarchy);
                }
                aM_.field_1724.field_3944.method_45730("hub");
            }
        }
    }
}
